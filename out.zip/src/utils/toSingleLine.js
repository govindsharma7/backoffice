module.exports = function(str) {
  return str.replace(/\s+/g, ' ').trim();
};
