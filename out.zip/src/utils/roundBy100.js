module.exports = function(value) {
  return Math.round( value / 100 ) * 100;
};
