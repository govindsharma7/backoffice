const Invoice = require('./invoice');
const RentalAttachment = require('./rentalAttachment');

module.exports = {
  Invoice,
  RentalAttachment,
};
