require("source-map-support").install();
module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 82);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const config = __webpack_require__(2);

module.exports = {
  TRASH_SEGMENTS: [{
    name: 'Trashed',
    scope: 'trashed'
  }, {
    name: 'Draft',
    scope: 'draft'
  }],
  TRASH_SCOPES: {
    trashed: {
      where: {
        deletedAt: { $not: null }
      },
      paranoid: false
    },
    draft: {
      where: {
        //        deletedAt: { $not: null },
        status: 'draft'
      }
      //      paranoid: false,
    }
  },

  // UNTRASHED_SCOPE: {
  //   untrashed: {
  //     where : { $or: [{
  //       deletedAt: { $not: null },
  //       status : 'draft',
  //     }, {
  //       deletedAt: null,
  //     }] },
  //     paranoid: false,
  //   },
  // },

  UNAVAILABLE_DATE: new Date(1E14),

  DATETIME_FORMAT: 'YYYY-MM-DD HH:mm:ss.SSSZ',

  LEASE_DURATION: '6',

  INVOICENINJA_URL: `${config.INVOICENINJA_PROTOCOL || 'http'}://${config.INVOICENINJA_HOST}`,

  BASIC_PACK: 'basic',
  COMFORT_PACK: 'comfort',
  PRIVILEGE_PACK: 'privilege',
  PACK_PRICES: {
    lyon: {
      basic: 59000,
      comfort: 79000,
      privilege: 99000
    },
    montpellier: {
      basic: 49000,
      comfort: 69000,
      privilege: 89000
    },
    paris: {
      basic: 89000,
      comfort: 119000,
      privilege: 149000
    }
  },
  ROOM_SWITCH_PRICES: {
    privilege: 0,
    comfort: 19000,
    basic: 29000
  },
  DEPOSIT_PRICES: {
    lyon: 70000,
    paris: 90000,
    montpellier: 50000
  },

  SPECIAL_CHECKIN_PRICES: {
    lyon: 7900,
    montpellier: 7900,
    paris: 12900
  },

  SERVICE_FEES: {
    1: 5000, // 1 room
    2: 4000, // 2 rooms
    default: 3000 // 3 or more rooms
  },

  CHECKIN_DURATION: 30,
  CHECKOUT_DURATION: 60,

  LATE_NOTICE_FEES: {
    '0-9days': 67900,
    '10-19days': 47900,
    '20-29days': 27900
  },

  LATE_FEES: 1000,

  DEPOSIT_REFUND_DELAYS: {
    basic: 60,
    comfort: 40,
    privilege: 20
  },

  UNCASHED_DEPOSIT_FEE: 2900,

  TWO_OCCUPANTS_FEES: 9000,

  AGENCY_ADDRESSES: {
    lyon: '16 rue de Condé 69002 Lyon',
    montpellier: '4 rue Paul Lacroix, 34070 Montpellier',
    paris: '42 rue de la Pompe, 75116 Paris'
  },

  SUPPORT_EMAIL: 'support@chez-nestor.com',

  RENT_COEFS: {
    '01-01': 0.95, // January
    '01-02': 0.96,
    '01-03': 0.95,
    '01-04': 0.96,
    '01-05': 0.95,
    '01-06': 0.96,
    '01-07': 0.95,
    '01-08': 0.96,
    '01-09': 0.95,
    '01-10': 0.96,
    '01-11': 0.95,
    '01-12': 0.96,
    '01-13': 0.95,
    '01-14': 0.96,
    '01-15': 0.95,
    '01-16': 0.94,
    '01-17': 0.93,
    '01-18': 0.92,
    '01-19': 0.91,
    '01-20': 0.90,
    '01-21': 0.89,
    '01-22': 0.88,
    '01-23': 0.87,
    '01-24': 0.86,
    '01-25': 0.85,
    '01-26': 0.86,
    '01-27': 0.85,
    '01-28': 0.86,
    '01-29': 0.85,
    '01-30': 0.86,
    '01-31': 0.85,
    '02-01': 0.86, // February
    '02-02': 0.85,
    '02-03': 0.86,
    '02-04': 0.85,
    '02-05': 0.85,
    '02-06': 0.84,
    '02-07': 0.84,
    '02-08': 0.83,
    '02-09': 0.83,
    '02-10': 0.82,
    '02-11': 0.82,
    '02-12': 0.81,
    '02-13': 0.81,
    '02-14': 0.80,
    '02-15': 0.80,
    '02-16': 0.79,
    '02-17': 0.79,
    '02-18': 0.78,
    '02-19': 0.78,
    '02-20': 0.77,
    '02-21': 0.77,
    '02-22': 0.76,
    '02-23': 0.76,
    '02-24': 0.75,
    '02-25': 0.76,
    '02-26': 0.75,
    '02-27': 0.76,
    '02-28': 0.75,
    '02-29': 0.76,
    '03-01': 0.76, // March
    '03-02': 0.75,
    '03-03': 0.76,
    '03-04': 0.75,
    '03-05': 0.76,
    '03-06': 0.75,
    '03-07': 0.76,
    '03-08': 0.75,
    '03-09': 0.76,
    '03-10': 0.75,
    '03-11': 0.76,
    '03-12': 0.75,
    '03-13': 0.76,
    '03-14': 0.75,
    '03-15': 0.76,
    '03-16': 0.75,
    '03-17': 0.76,
    '03-18': 0.75,
    '03-19': 0.76,
    '03-20': 0.75,
    '03-21': 0.76,
    '03-22': 0.75,
    '03-23': 0.76,
    '03-24': 0.75,
    '03-25': 0.76,
    '03-26': 0.75,
    '03-27': 0.76,
    '03-28': 0.75,
    '03-29': 0.76,
    '03-30': 0.75,
    '03-31': 0.76,
    '04-01': 0.75, // April
    '04-02': 0.76,
    '04-03': 0.75,
    '04-04': 0.76,
    '04-05': 0.75,
    '04-06': 0.76,
    '04-07': 0.75,
    '04-08': 0.76,
    '04-09': 0.75,
    '04-10': 0.76,
    '04-11': 0.75,
    '04-12': 0.76,
    '04-13': 0.75,
    '04-14': 0.76,
    '04-15': 0.75,
    '04-16': 0.76,
    '04-17': 0.75,
    '04-18': 0.76,
    '04-19': 0.75,
    '04-20': 0.76,
    '04-21': 0.75,
    '04-22': 0.76,
    '04-23': 0.75,
    '04-24': 0.76,
    '04-25': 0.75,
    '04-26': 0.76,
    '04-27': 0.75,
    '04-28': 0.76,
    '04-29': 0.75,
    '04-30': 0.76,
    '05-01': 0.75, // May
    '05-02': 0.76,
    '05-03': 0.75,
    '05-04': 0.76,
    '05-05': 0.75,
    '05-06': 0.76,
    '05-07': 0.75,
    '05-08': 0.76,
    '05-09': 0.75,
    '05-10': 0.76,
    '05-11': 0.75,
    '05-12': 0.76,
    '05-13': 0.75,
    '05-14': 0.76,
    '05-15': 0.75,
    '05-16': 0.76,
    '05-17': 0.75,
    '05-18': 0.76,
    '05-19': 0.75,
    '05-20': 0.76,
    '05-21': 0.76,
    '05-22': 0.76,
    '05-23': 0.77,
    '05-24': 0.77,
    '05-25': 0.77,
    '05-26': 0.78,
    '05-27': 0.78,
    '05-28': 0.78,
    '05-29': 0.79,
    '05-30': 0.79,
    '05-31': 0.79,
    '06-01': 0.80, // June
    '06-02': 0.80,
    '06-03': 0.80,
    '06-04': 0.81,
    '06-05': 0.81,
    '06-06': 0.81,
    '06-07': 0.82,
    '06-08': 0.82,
    '06-09': 0.82,
    '06-10': 0.83,
    '06-11': 0.83,
    '06-12': 0.83,
    '06-13': 0.84,
    '06-14': 0.84,
    '06-15': 0.84,
    '06-16': 0.85,
    '06-17': 0.85,
    '06-18': 0.85,
    '06-19': 0.86,
    '06-20': 0.86,
    '06-21': 0.86,
    '06-22': 0.87,
    '06-23': 0.87,
    '06-24': 0.87,
    '06-25': 0.88,
    '06-26': 0.88,
    '06-27': 0.88,
    '06-28': 0.89,
    '06-29': 0.89,
    '06-30': 0.89,
    '07-01': 0.90, // July
    '07-02': 0.90,
    '07-03': 0.90,
    '07-04': 0.91,
    '07-05': 0.91,
    '07-06': 0.91,
    '07-07': 0.92,
    '07-08': 0.92,
    '07-09': 0.92,
    '07-10': 0.93,
    '07-11': 0.93,
    '07-12': 0.93,
    '07-13': 0.94,
    '07-14': 0.94,
    '07-15': 0.94,
    '07-16': 0.95,
    '07-17': 0.95,
    '07-18': 0.95,
    '07-19': 0.96,
    '07-20': 0.96,
    '07-21': 0.96,
    '07-22': 0.97,
    '07-23': 0.97,
    '07-24': 0.97,
    '07-25': 0.98,
    '07-26': 0.98,
    '07-27': 0.98,
    '07-28': 0.99,
    '07-29': 0.99,
    '07-30': 0.99,
    '07-31': 1,
    '08-01': 1, // August
    '08-02': 1,
    '08-03': 1,
    '08-04': 1,
    '08-05': 1,
    '08-06': 1,
    '08-07': 1,
    '08-08': 1,
    '08-09': 1,
    '08-10': 1,
    '08-11': 1.01,
    '08-12': 1.01,
    '08-13': 1.02,
    '08-14': 1.02,
    '08-15': 1.03,
    '08-16': 1.03,
    '08-17': 1.04,
    '08-18': 1.04,
    '08-19': 1.05,
    '08-20': 1.05,
    '08-21': 1.06,
    '08-22': 1.06,
    '08-23': 1.07,
    '08-24': 1.07,
    '08-25': 1.08,
    '08-26': 1.08,
    '08-27': 1.09,
    '08-28': 1.09,
    '08-29': 1.1,
    '08-30': 1.1,
    '08-31': 1.1,
    '09-01': 1.1, // September
    '09-02': 1.1,
    '09-03': 1.1,
    '09-04': 1.1,
    '09-05': 1.1,
    '09-06': 1.1,
    '09-07': 1.1,
    '09-08': 1.1,
    '09-09': 1.1,
    '09-10': 1.1,
    '09-11': 1.1,
    '09-12': 1.1,
    '09-13': 1.1,
    '09-14': 1.1,
    '09-15': 1.1,
    '09-16': 1.09,
    '09-17': 1.09,
    '09-18': 1.08,
    '09-19': 1.08,
    '09-20': 1.07,
    '09-21': 1.07,
    '09-22': 1.07,
    '09-23': 1.06,
    '09-24': 1.06,
    '09-25': 1.05,
    '09-26': 1.05,
    '09-27': 1.04,
    '09-28': 1.04,
    '09-29': 1.03,
    '09-30': 1.03,
    '10-01': 1.02, // October
    '10-02': 1.02,
    '10-03': 1.01,
    '10-04': 1.01,
    '10-05': 1,
    '10-06': 1,
    '10-07': 1,
    '10-08': 1,
    '10-09': 1,
    '10-10': 1,
    '10-11': 1,
    '10-12': 1,
    '10-13': 1,
    '10-14': 1,
    '10-15': 1,
    '10-16': 1,
    '10-17': 1,
    '10-18': 1,
    '10-19': 1,
    '10-20': 1,
    '10-21': 1,
    '10-22': 1,
    '10-23': 1,
    '10-24': 1,
    '10-25': 1,
    '10-26': 1,
    '10-27': 1,
    '10-28': 1,
    '10-29': 1,
    '10-30': 1,
    '10-31': 1,
    '11-01': 1, // November
    '11-02': 0.99,
    '11-03': 0.99,
    '11-04': 0.98,
    '11-05': 0.98,
    '11-06': 0.97,
    '11-07': 0.97,
    '11-08': 0.96,
    '11-09': 0.96,
    '11-10': 0.95,
    '11-11': 0.95,
    '11-12': 0.94,
    '11-13': 0.94,
    '11-14': 0.93,
    '11-15': 0.93,
    '11-16': 0.92,
    '11-17': 0.92,
    '11-18': 0.91,
    '11-19': 0.91,
    '11-20': 0.90,
    '11-21': 0.91,
    '11-22': 0.90,
    '11-23': 0.91,
    '11-24': 0.90,
    '11-25': 0.91,
    '11-26': 0.90,
    '11-27': 0.91,
    '11-28': 0.90,
    '11-29': 0.91,
    '11-30': 0.90,
    '12-01': 0.91, // December
    '12-02': 0.90,
    '12-03': 0.91,
    '12-04': 0.90,
    '12-05': 0.91,
    '12-06': 0.90,
    '12-07': 0.91,
    '12-08': 0.90,
    '12-09': 0.91,
    '12-10': 0.90,
    '12-11': 0.91,
    '12-12': 0.90,
    '12-13': 0.91,
    '12-14': 0.90,
    '12-15': 0.90,
    '12-16': 0.91,
    '12-17': 0.92,
    '12-18': 0.93,
    '12-19': 0.94,
    '12-20': 0.95,
    '12-21': 0.96,
    '12-22': 0.95,
    '12-23': 0.96,
    '12-24': 0.95,
    '12-25': 0.96,
    '12-26': 0.95,
    '12-27': 0.96,
    '12-28': 0.95,
    '12-29': 0.96,
    '12-30': 0.95,
    '12-31': 0.96
  }
};

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("bluebird");

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(101);

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const stripIndent = __webpack_require__(109);
const addInternalRelationshipRoute = __webpack_require__(110);
const addRestoreAndDestroyRoutes = __webpack_require__(111);
const calculatedPropsMemoizer = __webpack_require__(112);
const createSuccessHandler = __webpack_require__(113);
const roundBy100 = __webpack_require__(57);
const findOrCreateSuccessHandler = __webpack_require__(114);
const {
  getCheckinPrice,
  getCheckoutPrice
} = __webpack_require__(115);
const getPackPrice = __webpack_require__(117);
const getPeriodCoef = __webpack_require__(118);
const getPeriodPrice = __webpack_require__(119);
const getServiceFees = __webpack_require__(120);
const {
  getCheckinEndDate,
  getCheckoutEndDate
} = __webpack_require__(121);
const getLateNoticeFees = __webpack_require__(122);
const getLeaseEndDate = __webpack_require__(123);
const getRoomSwitchPrice = __webpack_require__(124);
const isHoliday = __webpack_require__(58);
const isValidPhoneNumber = __webpack_require__(125);
const logAndSend = __webpack_require__(33);
const parseDBDate = __webpack_require__(126);
const toSingleLine = __webpack_require__(56);
const wrapHookPromise = __webpack_require__(127);
const serializeHousemate = __webpack_require__(128);

module.exports = {
  addInternalRelationshipRoute,
  addRestoreAndDestroyRoutes,
  calculatedPropsMemoizer,
  createSuccessHandler,
  roundBy100,
  findOrCreateSuccessHandler,
  getCheckinPrice,
  getCheckoutPrice,
  getPackPrice,
  getPeriodCoef,
  getPeriodPrice,
  getServiceFees,
  getCheckinEndDate,
  getCheckoutEndDate,
  getLateNoticeFees,
  getLeaseEndDate,
  getRoomSwitchPrice,
  isHoliday,
  isValidPhoneNumber,
  logAndSend,
  parseDBDate,
  toSingleLine,
  stripIndent,
  wrapHookPromise,
  serializeHousemate
};

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("date-fns");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("forest-express-sequelize");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

module.exports = isArray;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

var freeGlobal = __webpack_require__(45);

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

module.exports = root;


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (req, res, next) {
  req.user = true;
  next();
};

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsNative = __webpack_require__(131),
    getValue = __webpack_require__(134);

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

module.exports = getNative;


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

var toString = __webpack_require__(40),
    upperFirst = __webpack_require__(191);

/**
 * Converts the first character of `string` to upper case and the remaining
 * to lower case.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to capitalize.
 * @returns {string} Returns the capitalized string.
 * @example
 *
 * _.capitalize('FRED');
 * // => 'Fred'
 */
function capitalize(string) {
  return upperFirst(toString(string).toLowerCase());
}

module.exports = capitalize;


/***/ }),
/* 11 */
/***/ (function(module, exports) {

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return value != null && (type == 'object' || type == 'function');
}

module.exports = isObject;


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeKeys = __webpack_require__(44),
    baseKeys = __webpack_require__(98),
    isArrayLike = __webpack_require__(16);

/**
 * Creates an array of the own enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects. See the
 * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * for more details.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keys(new Foo);
 * // => ['a', 'b'] (iteration order is not guaranteed)
 *
 * _.keys('hi');
 * // => ['0', '1']
 */
function keys(object) {
  return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
}

module.exports = keys;


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(14),
    getRawTag = __webpack_require__(92),
    objectToString = __webpack_require__(93);

/** `Object#toString` result references. */
var nullTag = '[object Null]',
    undefinedTag = '[object Undefined]';

/** Built-in value references. */
var symToStringTag = Symbol ? Symbol.toStringTag : undefined;

/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
function baseGetTag(value) {
  if (value == null) {
    return value === undefined ? undefinedTag : nullTag;
  }
  return (symToStringTag && symToStringTag in Object(value))
    ? getRawTag(value)
    : objectToString(value);
}

module.exports = baseGetTag;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(7);

/** Built-in value references. */
var Symbol = root.Symbol;

module.exports = Symbol;


/***/ }),
/* 15 */
/***/ (function(module, exports) {

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return value != null && typeof value == 'object';
}

module.exports = isObjectLike;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

var isFunction = __webpack_require__(51),
    isLength = __webpack_require__(31);

/**
 * Checks if `value` is array-like. A value is considered array-like if it's
 * not a function and has a `value.length` that's an integer greater than or
 * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
 * @example
 *
 * _.isArrayLike([1, 2, 3]);
 * // => true
 *
 * _.isArrayLike(document.body.children);
 * // => true
 *
 * _.isArrayLike('abc');
 * // => true
 *
 * _.isArrayLike(_.noop);
 * // => false
 */
function isArrayLike(value) {
  return value != null && isLength(value.length) && !isFunction(value);
}

module.exports = isArrayLike;


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

var baseMatches = __webpack_require__(137),
    baseMatchesProperty = __webpack_require__(180),
    identity = __webpack_require__(73),
    isArray = __webpack_require__(6),
    property = __webpack_require__(188);

/**
 * The base implementation of `_.iteratee`.
 *
 * @private
 * @param {*} [value=_.identity] The value to convert to an iteratee.
 * @returns {Function} Returns the iteratee.
 */
function baseIteratee(value) {
  // Don't store the `typeof` result in a variable to avoid a JIT bug in Safari 9.
  // See https://bugs.webkit.org/show_bug.cgi?id=156034 for more details.
  if (typeof value == 'function') {
    return value;
  }
  if (value == null) {
    return identity;
  }
  if (typeof value == 'object') {
    return isArray(value)
      ? baseMatchesProperty(value[0], value[1])
      : baseMatches(value);
  }
  return property(value);
}

module.exports = baseIteratee;


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

var isSymbol = __webpack_require__(26);

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

module.exports = toKey;


/***/ }),
/* 19 */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */
function arrayMap(array, iteratee) {
  var index = -1,
      length = array == null ? 0 : array.length,
      result = Array(length);

  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }
  return result;
}

module.exports = arrayMap;


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const AWS = __webpack_require__(107);
const Promise = __webpack_require__(1);
const FormData = __webpack_require__(108);
const {
  AWS_ACCESS_KEY_ID,
  AWS_SECRET_ACCESS_KEY,
  AWS_REGION,
  IMAGE_OPTIM_KEY,
  AWS_BUCKET_PICTURES
} = __webpack_require__(2);
const fetch = __webpack_require__(32);

AWS.config.update({
  accessKeyId: AWS_ACCESS_KEY_ID,
  secretAccessKey: AWS_SECRET_ACCESS_KEY,
  region: AWS_REGION,
  s3ForcePathStyle: true
});
// Use bluebird Promises, instead of native ones
AWS.config.setPromisesDependency(Promise);

function uploadFile(bucket, data) {
  const s3Bucket = new AWS.S3({ params: { Bucket: bucket } });

  return s3Bucket.upload(data).promise().then(result => {
    return result.Location;
  });
}

function deleteFile(bucket, data) {
  const s3Bucket = new AWS.S3({ params: { Bucket: bucket } });

  return s3Bucket.deleteObject(data).promise().then(() => {
    return true;
  });
}

const rBase64Image = /^data:image\/\w+;base64,/;
const picturesBucket = new AWS.S3({ params: { Bucket: AWS_BUCKET_PICTURES } });

function uploadPicture({ id, url }) {
  let body;
  let buffer;

  if (rBase64Image.test(url)) {
    body = new FormData();
    buffer = Buffer.from(url.replace(rBase64Image, ''), 'base64');
    body.append('file', buffer, { filename: 'pic.jpg' });
  }

  return fetch(`https://im2.io/${IMAGE_OPTIM_KEY}/1920x1080,fit${body ? '' : `/${url}`}`, {
    method: 'post',
    body
  }).then(response => {
    if (response.status >= 400) {
      throw new Error(response.statusText);
    }

    return response.buffer();
  }).then(Body => {
    return picturesBucket.upload({
      Key: id,
      Body,
      ACL: 'public-read',
      ContentType: 'image/jpeg'
    }).promise();
  }).then(({ Location }) => {
    return Location;
  });
}

// This function is used to make sure we have access to the pictures bucket
function pingService() {
  return picturesBucket.headBucket().promise();
}

/* Following code is deprecated as we're switching to SendInBlue to send
 * emails and SMS
 */
// const sns = new AWS.SNS({
//   apiVersion: AWS_SNS_API_VERSION,
//   accessKeyId: AWS_SNS_ACCESS_KEY_ID,
//   secretAccessKey: AWS_SNS_SECRET_ACCESS_KEY,
//   region: AWS_REGION,
// });
//
// const defaultMessageAttributes = {
// /* MonthlySpendLimit could be usefull if we want to
//   limit sms cost each month
//
//   MonthlySpendLimit: {
//     DataType: 'Number',
//     StringValue: '30'
//   },
// */
//   DefaultSenderID: {
//     DataType: 'String',
//     /* required */
//     StringValue: 'ChezNestor',
//   },
//   DefaultSMSType: {
//     DataType: 'String',
//     StringValue: 'Transactional',
//   },
//   DeliveryStatusIAMRole: {
//     DataType: 'String',
//     StringValue: config.AWS_SNS_Delivery_Status_IAM_Role,
//   },
// };
//
// function sendSms(phoneNumbers, text, date = new Date()) {
//   return sns
//     .createTopic({
//       Name: `DATE_${D.format(date, 'YYYY-MM-DD')}_TIME_${D.format(date, 'HH-mm-ss')}`,
//     }).promise()
//     .then((data) => {
//       return Promise.all([
//         data.TopicArn, // Pass this on to next steps
//         Promise.filter(phoneNumbers, (number) => {
//           /* eslint-disable promise/no-nesting */
//           return sns
//             .checkIfPhoneNumberIsOptedOut({ phoneNumber: number }).promise()
//             .then((phoneNumber) => {
//               return !phoneNumber.isOptedOut;
//             })
//             .catch((error) => {
//               console.error(error);
//               return false;
//             });
//           /* eslint-enable promise/no-nesting */
//         }),
//       ]);
//     })
//     .tap(([TopicArn, validNumbers]) => {
//       return Promise.map(validNumbers, (number) => {
//         return sns.subscribe({
//           Protocol: 'sms',
//           Endpoint: number,
//           TopicArn,
//         }).promise();
//       });
//     })
//     .then(([TopicArn]) => {
//       return sns.publish({
//         Message: text,
//         MessageAttributes: defaultMessageAttributes,
//         TopicArn,
//       }).promise();
//     });
// }

module.exports = {
  // sendSms,
  uploadFile,
  deleteFile,
  uploadPicture,
  pingService
};

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

var listCacheClear = __webpack_require__(139),
    listCacheDelete = __webpack_require__(140),
    listCacheGet = __webpack_require__(141),
    listCacheHas = __webpack_require__(142),
    listCacheSet = __webpack_require__(143);

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

module.exports = ListCache;


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

var eq = __webpack_require__(34);

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

module.exports = assocIndexOf;


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9);

/* Built-in method references that are verified to be native. */
var nativeCreate = getNative(Object, 'create');

module.exports = nativeCreate;


/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

var isKeyable = __webpack_require__(157);

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

module.exports = getMapData;


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

var isArray = __webpack_require__(6),
    isKey = __webpack_require__(39),
    stringToPath = __webpack_require__(182),
    toString = __webpack_require__(40);

/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @param {Object} [object] The object to query keys on.
 * @returns {Array} Returns the cast property path array.
 */
function castPath(value, object) {
  if (isArray(value)) {
    return value;
  }
  return isKey(value, object) ? [value] : stringToPath(toString(value));
}

module.exports = castPath;


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(13),
    isObjectLike = __webpack_require__(15);

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && baseGetTag(value) == symbolTag);
}

module.exports = isSymbol;


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {

const path = __webpack_require__(203);
const Payline = __webpack_require__(75);
const config = __webpack_require__(2);

const payline = new Payline(config.PAYLINE_MERCHANT_ID, config.PAYLINE_ACCESS_KEY, config.PAYLINE_CONTRACT_NUMBER, config.PAYLINE_HOMOLOGATION === true ? undefined : path.resolve(__dirname, 'WebPaymentAPI-v4-production.wsdl'));

payline.pingService = function () {
  return payline.getWallet(123456).catch(error => {
    if (error.code !== '02532') {
      throw error;
    }
    console.error(error);
  });
};

module.exports = payline;
/* WEBPACK VAR INJECTION */}.call(exports, "/"))

/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

var baseValues = __webpack_require__(89),
    keys = __webpack_require__(12);

/**
 * Creates an array of the own enumerable string keyed property values of `object`.
 *
 * **Note:** Non-object values are coerced to objects.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property values.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.values(new Foo);
 * // => [1, 2] (iteration order is not guaranteed)
 *
 * _.values('hi');
 * // => ['h', 'i']
 */
function values(object) {
  return object == null ? [] : baseValues(object, keys(object));
}

module.exports = values;


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsArguments = __webpack_require__(91),
    isObjectLike = __webpack_require__(15);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Built-in value references. */
var propertyIsEnumerable = objectProto.propertyIsEnumerable;

/**
 * Checks if `value` is likely an `arguments` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 *  else `false`.
 * @example
 *
 * _.isArguments(function() { return arguments; }());
 * // => true
 *
 * _.isArguments([1, 2, 3]);
 * // => false
 */
var isArguments = baseIsArguments(function() { return arguments; }()) ? baseIsArguments : function(value) {
  return isObjectLike(value) && hasOwnProperty.call(value, 'callee') &&
    !propertyIsEnumerable.call(value, 'callee');
};

module.exports = isArguments;


/***/ }),
/* 30 */
/***/ (function(module, exports) {

/** Used as references for various `Number` constants. */
var MAX_SAFE_INTEGER = 9007199254740991;

/** Used to detect unsigned integer values. */
var reIsUint = /^(?:0|[1-9]\d*)$/;

/**
 * Checks if `value` is a valid array-like index.
 *
 * @private
 * @param {*} value The value to check.
 * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
 * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
 */
function isIndex(value, length) {
  length = length == null ? MAX_SAFE_INTEGER : length;
  return !!length &&
    (typeof value == 'number' || reIsUint.test(value)) &&
    (value > -1 && value % 1 == 0 && value < length);
}

module.exports = isIndex;


/***/ }),
/* 31 */
/***/ (function(module, exports) {

/** Used as references for various `Number` constants. */
var MAX_SAFE_INTEGER = 9007199254740991;

/**
 * Checks if `value` is a valid array-like length.
 *
 * **Note:** This method is loosely based on
 * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
 * @example
 *
 * _.isLength(3);
 * // => true
 *
 * _.isLength(Number.MIN_VALUE);
 * // => false
 *
 * _.isLength(Infinity);
 * // => false
 *
 * _.isLength('3');
 * // => false
 */
function isLength(value) {
  return typeof value == 'number' &&
    value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
}

module.exports = isLength;


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const fetch = __webpack_require__(54);
const Promise = __webpack_require__(1);

fetch.Promise = Promise;

module.exports = fetch;

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (res) {
  return function (error) {
    console.error(error);
    return res.status(400).send({
      // Payline errors have a longMessage or shortMessage instead of a message :-/
      error: error.longMessage || error.shortMessage || error.message
    });
  };
};

/***/ }),
/* 34 */
/***/ (function(module, exports) {

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

module.exports = eq;


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9),
    root = __webpack_require__(7);

/* Built-in method references that are verified to be native. */
var Map = getNative(root, 'Map');

module.exports = Map;


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

var mapCacheClear = __webpack_require__(149),
    mapCacheDelete = __webpack_require__(156),
    mapCacheGet = __webpack_require__(158),
    mapCacheHas = __webpack_require__(159),
    mapCacheSet = __webpack_require__(160);

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

module.exports = MapCache;


/***/ }),
/* 37 */
/***/ (function(module, exports) {

/**
 * Appends the elements of `values` to `array`.
 *
 * @private
 * @param {Array} array The array to modify.
 * @param {Array} values The values to append.
 * @returns {Array} Returns `array`.
 */
function arrayPush(array, values) {
  var index = -1,
      length = values.length,
      offset = array.length;

  while (++index < length) {
    array[offset + index] = values[index];
  }
  return array;
}

module.exports = arrayPush;


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

var castPath = __webpack_require__(25),
    toKey = __webpack_require__(18);

/**
 * The base implementation of `_.get` without support for default values.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @returns {*} Returns the resolved value.
 */
function baseGet(object, path) {
  path = castPath(path, object);

  var index = 0,
      length = path.length;

  while (object != null && index < length) {
    object = object[toKey(path[index++])];
  }
  return (index && index == length) ? object : undefined;
}

module.exports = baseGet;


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

var isArray = __webpack_require__(6),
    isSymbol = __webpack_require__(26);

/** Used to match property names within property paths. */
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    reIsPlainProp = /^\w*$/;

/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == 'number' || type == 'symbol' || type == 'boolean' ||
      value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
    (object != null && value in Object(object));
}

module.exports = isKey;


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

var baseToString = __webpack_require__(185);

/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */
function toString(value) {
  return value == null ? '' : baseToString(value);
}

module.exports = toString;


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Swagger = __webpack_require__(200);
const Deasync = __webpack_require__(201);
const config = __webpack_require__(2);
const spec = __webpack_require__(202);

let Ninja;

/* eslint-disable promise/catch-or-return, promise/always-return */
new Swagger({
  spec,
  usePromise: true,
  authorizations: {
    'api_key': new Swagger.ApiKeyAuthorization('X-Ninja-Token', config.INVOICENINJA_API_KEY, 'header')
  }
})
// Override the host hardcoded in the spec.
.then(ninja => {
  Ninja = ninja;
  Ninja.setSchemes([config.INVOICENINJA_PROTOCOL || 'http']);
  Ninja.setHost(config.INVOICENINJA_HOST);
  Ninja.INVOICE_STATUS_PAID = 6;
  Ninja.INVOICE_STATUS_PARTIAL = 5;
  Ninja.INVOICE_STATUS_DRAFT = 1;
});

// Swagger client initialization is async :thumbs-down:. Fix that!
/* eslint-disable no-unmodified-loop-condition */
while (!Ninja) {
  Deasync.sleep(1);
}

module.exports = Ninja;

/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const SendinBlueApi = __webpack_require__(230);
const capitalize = __webpack_require__(10);
const D = __webpack_require__(4);
const fr = __webpack_require__(231);
const config = __webpack_require__(2);
const {
  SUPPORT_EMAIL,
  SPECIAL_CHECKIN_PRICES,
  AGENCY_ADDRESSES,
  DEPOSIT_PRICES
} = __webpack_require__(0);
const {
  NODE_ENV,
  SENDINBLUE_TEMPLATE_IDS,
  SENDINBLUE_LIST_IDS,
  WEBSITE_URL
} = __webpack_require__(2);

SendinBlueApi.ApiClient.instance.authentications['api-key'].apiKey = config.SENDINBLUE_API_KEY;

const _ = { capitalize };
const SMTPApi = new SendinBlueApi.SMTPApi();
const ContactsApi = new SendinBlueApi.ContactsApi();
const defaults = { replyTo: SUPPORT_EMAIL };

function serializeClient(client) {
  return {
    FIRSTNAME: client.firstName,
    LASTNAME: client.lastName,
    SMS: client.phoneNumber === null ? null : client.phoneNumber
  };
}

function sendEmail(id, data = {}) {
  const options = Object.assign({}, defaults, data, NODE_ENV !== 'production' ? { emailTo: ['vquesnel@chez-nestor.com'] } : {});

  if (options.emailTo.length > 0) {
    return SMTPApi.sendTemplate(id, options).then(() => {
      return true;
    });
  }

  return true;
}

function getContact(email) {
  return ContactsApi.getContactInfo(email);
}

function createContact(email, { client, listIds }) {
  return ContactsApi.createContact({
    // In any environment but production, we always replace the email domain
    // with our own, to make sure we never send an email to a real client
    email: email.replace(/@(.*)\.[^.]+$/, NODE_ENV === 'production' ? '$&' : '_$1@chez-nestor.com'),
    attributes: serializeClient(client),
    listIds: listIds === null ? [SENDINBLUE_LIST_IDS.prospects[client.preferredLanguage]] : listIds
  });
}

function updateContact(email, { listIds, unlinkListIds, client }) {
  const params = {
    listIds,
    unlinkListIds
  };

  if (client != null) {
    params.attributes = serializeClient(client);
  }

  return ContactsApi.updateContact(email, params);
}

function sendWelcomeEmail(renting) {
  return SendinBlueApi.sendEmail(SENDINBLUE_TEMPLATE_IDS.welcome[renting.Client.preferredLanguage], serializeWelcomeEmail(renting));
}

function serializeWelcomeEmail(renting) {
  const { Client, Room: { Apartment }, Room } = renting;
  const { name, addressStreet, addressZip, addressCity } = Apartment;
  const isStudio = name.split(' ').splice(-1)[0] === 'studio';
  const roomNumber = Room.reference.slice(-1);

  return {
    emailTo: [Client.email],
    attributes: {
      APARTMENT: `${addressStreet}, ${_.capitalize(addressCity)}, ${addressZip}`,
      FIRSTNAME: _.capitalize(Client.firstName),
      BOOKINGDATE: D.format(renting.bookingDate, 'DD/MM/YYYY'),
      RENT: renting.price / 100 + renting.serviceFees / 100,
      EMAIL: Client.email,
      DEPOSIT: DEPOSIT_PRICES[addressCity] / 100,
      ADDRESSAGENCY: AGENCY_ADDRESSES[addressCity],
      SPECIALCHECKIN: SPECIAL_CHECKIN_PRICES[addressCity] / 100,
      ROOM: renting.Client.preferredLanguage === 'en' ? isStudio ? 'our studio<b>' : `bedroom nº<b>${roomNumber}` : isStudio ? 'l\'appartement entier<b>' : `la chambre nº<b>${roomNumber}`
    }
  };
}

function sendRentReminder(order, amount) {
  const { Client } = order;

  return sendEmail(SENDINBLUE_TEMPLATE_IDS.dueDate[Client.preferredLanguage], {
    emailTo: [Client.email],
    attributes: {
      FIRSTNAME: Client.firstName,
      MONTH: Client.preferredLanguage === 'en' ? D.format(order.dueDate, 'MMMM') : D.format(order.dueDate, 'MMMM', { locale: fr }),
      AMOUNT: amount / 100,
      LINK: `${WEBSITE_URL}/${Client.preferredLanguage}/payment/${order.id}`
    }
  });
}

function pingService() {
  return new SendinBlueApi.AccountApi().getAccount();
}

module.exports = {
  sendEmail,
  updateContact,
  createContact,
  getContact,
  serializeClient,
  sendWelcomeEmail,
  sendRentReminder,
  pingService
};

/***/ }),
/* 43 */
/***/ (function(module, exports) {

module.exports = require("body-parser");

/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

var baseTimes = __webpack_require__(90),
    isArguments = __webpack_require__(29),
    isArray = __webpack_require__(6),
    isBuffer = __webpack_require__(46),
    isIndex = __webpack_require__(30),
    isTypedArray = __webpack_require__(48);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Creates an array of the enumerable property names of the array-like `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @param {boolean} inherited Specify returning inherited property names.
 * @returns {Array} Returns the array of property names.
 */
function arrayLikeKeys(value, inherited) {
  var isArr = isArray(value),
      isArg = !isArr && isArguments(value),
      isBuff = !isArr && !isArg && isBuffer(value),
      isType = !isArr && !isArg && !isBuff && isTypedArray(value),
      skipIndexes = isArr || isArg || isBuff || isType,
      result = skipIndexes ? baseTimes(value.length, String) : [],
      length = result.length;

  for (var key in value) {
    if ((inherited || hasOwnProperty.call(value, key)) &&
        !(skipIndexes && (
           // Safari 9 has enumerable `arguments.length` in strict mode.
           key == 'length' ||
           // Node.js 0.10 has enumerable non-index properties on buffers.
           (isBuff && (key == 'offset' || key == 'parent')) ||
           // PhantomJS 2 has enumerable non-index properties on typed arrays.
           (isType && (key == 'buffer' || key == 'byteLength' || key == 'byteOffset')) ||
           // Skip index properties.
           isIndex(key, length)
        ))) {
      result.push(key);
    }
  }
  return result;
}

module.exports = arrayLikeKeys;


/***/ }),
/* 45 */
/***/ (function(module, exports) {

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

module.exports = freeGlobal;


/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module) {var root = __webpack_require__(7),
    stubFalse = __webpack_require__(94);

/** Detect free variable `exports`. */
var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Built-in value references. */
var Buffer = moduleExports ? root.Buffer : undefined;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined;

/**
 * Checks if `value` is a buffer.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
 * @example
 *
 * _.isBuffer(new Buffer(2));
 * // => true
 *
 * _.isBuffer(new Uint8Array(2));
 * // => false
 */
var isBuffer = nativeIsBuffer || stubFalse;

module.exports = isBuffer;

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(47)(module)))

/***/ }),
/* 47 */
/***/ (function(module, exports) {

module.exports = function(module) {
	if(!module.webpackPolyfill) {
		module.deprecate = function() {};
		module.paths = [];
		// module.parent = undefined by default
		if(!module.children) module.children = [];
		Object.defineProperty(module, "loaded", {
			enumerable: true,
			get: function() {
				return module.l;
			}
		});
		Object.defineProperty(module, "id", {
			enumerable: true,
			get: function() {
				return module.i;
			}
		});
		module.webpackPolyfill = 1;
	}
	return module;
};


/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsTypedArray = __webpack_require__(95),
    baseUnary = __webpack_require__(96),
    nodeUtil = __webpack_require__(97);

/* Node.js helper references. */
var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;

/**
 * Checks if `value` is classified as a typed array.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 * @example
 *
 * _.isTypedArray(new Uint8Array);
 * // => true
 *
 * _.isTypedArray([]);
 * // => false
 */
var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;

module.exports = isTypedArray;


/***/ }),
/* 49 */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Checks if `value` is likely a prototype object.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
 */
function isPrototype(value) {
  var Ctor = value && value.constructor,
      proto = (typeof Ctor == 'function' && Ctor.prototype) || objectProto;

  return value === proto;
}

module.exports = isPrototype;


/***/ }),
/* 50 */
/***/ (function(module, exports) {

/**
 * Creates a unary function that invokes `func` with its argument transformed.
 *
 * @private
 * @param {Function} func The function to wrap.
 * @param {Function} transform The argument transform.
 * @returns {Function} Returns the new function.
 */
function overArg(func, transform) {
  return function(arg) {
    return func(transform(arg));
  };
}

module.exports = overArg;


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(13),
    isObject = __webpack_require__(11);

/** `Object#toString` result references. */
var asyncTag = '[object AsyncFunction]',
    funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    proxyTag = '[object Proxy]';

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  if (!isObject(value)) {
    return false;
  }
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 9 which returns 'object' for typed arrays and other constructors.
  var tag = baseGetTag(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}

module.exports = isFunction;


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Sequelize = __webpack_require__(102);
const config = __webpack_require__(2);
const apartment = __webpack_require__(103);
const client = __webpack_require__(130);
const credit = __webpack_require__(236);
const event = __webpack_require__(238);
const metadata = __webpack_require__(242);
const order = __webpack_require__(243);
const orderItem = __webpack_require__(248);
const payment = __webpack_require__(252);
const picture = __webpack_require__(255);
const product = __webpack_require__(258);
const renting = __webpack_require__(260);
const room = __webpack_require__(278);
const setting = __webpack_require__(282);
const term = __webpack_require__(284);

const sequelize = new Sequelize(config.SEQUELIZE_DATABASE, config.SEQUELIZE_USERNAME, config.SEQUELIZE_PASSWORD, {
  host: config.SEQUELIZE_HOST,
  dialect: config.SEQUELIZE_DIALECT,
  // this file is used when dialect is sqlite
  storage: config.SEQUELIZE_HOST,
  // WTF Sequelize??
  define: {
    freezeTableName: true
  },
  benchmark: true
});

// Load the models manually (loading the directory isn't webpack friendly)
const db = {
  Apartment: apartment(sequelize, Sequelize.DataTypes),
  Client: client(sequelize, Sequelize.DataTypes),
  Credit: credit(sequelize, Sequelize.DataTypes),
  Event: event(sequelize, Sequelize.DataTypes),
  Metadata: metadata(sequelize, Sequelize.DataTypes),
  Order: order(sequelize, Sequelize.DataTypes),
  OrderItem: orderItem(sequelize, Sequelize.DataTypes),
  Payment: payment(sequelize, Sequelize.DataTypes),
  Picture: picture(sequelize, Sequelize.DataTypes),
  Product: product(sequelize, Sequelize.DataTypes),
  Renting: renting(sequelize, Sequelize.DataTypes),
  Room: room(sequelize, Sequelize.DataTypes),
  Setting: setting(sequelize, Sequelize.DataTypes),
  Term: term(sequelize, Sequelize.DataTypes)
};

// When querying a specific record by its id, remove the default paranoid scope
sequelize.addHook('beforeFind', options => {
  if (options.where && Object.keys(options.where).join() === 'id' && typeof options.where.id === 'string') {
    options.paranoid = false;
  }

  return true;
});

Object.keys(db).forEach(function (modelName) {
  if ('associate' in db[modelName]) {
    db[modelName].associate(db);
  }

  if ('hooks' in db[modelName]) {
    db[modelName].hooks(db, db[modelName]);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const urlencode = __webpack_require__(104);
const { GOOGLE_MAPS_API_KEY } = __webpack_require__(2);
const fetch = __webpack_require__(32);

const endpoint = 'https://maps.googleapis.com/maps/api/geocode/json';

function geocode(address) {
  return fetch(`${endpoint}?address=${urlencode(address)}&key=${GOOGLE_MAPS_API_KEY}`).then(res => {
    return res.json();
  }).then(json => {
    return json.results[0].geometry.location;
  });
}

geocode.pingService = function () {
  return geocode('16 Rue de Condé, 69007, Lyon');
};

module.exports = geocode;

/***/ }),
/* 54 */
/***/ (function(module, exports) {

module.exports = require("node-fetch");

/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports.restoreSuccessHandler = function (res, subject) {
    res.status(200).send({ success: `${subject} successfully restored` });
};

module.exports.destroySuccessHandler = function (res, subject) {
    res.status(200).send({ success: `${subject} successfully destroyed` });
};

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (str) {
  return str.replace(/\s+/g, ' ').trim();
};

/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (value) {
  return Math.round(value / 100) * 100;
};

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const holidays = __webpack_require__(116);

module.exports = function isHoliday(date) {
  const sDate = date.toISOString();

  for (let holiday of holidays) {
    if (sDate < holiday.end && sDate > holiday.start) {
      return true;
    }

    if (sDate < holiday.start) {
      return false;
    }
  }

  return false;
};

/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

var baseAssignValue = __webpack_require__(60),
    baseForOwn = __webpack_require__(63),
    baseIteratee = __webpack_require__(17);

/**
 * The opposite of `_.mapValues`; this method creates an object with the
 * same values as `object` and keys generated by running each own enumerable
 * string keyed property of `object` thru `iteratee`. The iteratee is invoked
 * with three arguments: (value, key, object).
 *
 * @static
 * @memberOf _
 * @since 3.8.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @returns {Object} Returns the new mapped object.
 * @see _.mapValues
 * @example
 *
 * _.mapKeys({ 'a': 1, 'b': 2 }, function(value, key) {
 *   return key + value;
 * });
 * // => { 'a1': 1, 'b2': 2 }
 */
function mapKeys(object, iteratee) {
  var result = {};
  iteratee = baseIteratee(iteratee, 3);

  baseForOwn(object, function(value, key, object) {
    baseAssignValue(result, iteratee(value, key, object), value);
  });
  return result;
}

module.exports = mapKeys;


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

var defineProperty = __webpack_require__(61);

/**
 * The base implementation of `assignValue` and `assignMergeValue` without
 * value checks.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function baseAssignValue(object, key, value) {
  if (key == '__proto__' && defineProperty) {
    defineProperty(object, key, {
      'configurable': true,
      'enumerable': true,
      'value': value,
      'writable': true
    });
  } else {
    object[key] = value;
  }
}

module.exports = baseAssignValue;


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9);

var defineProperty = (function() {
  try {
    var func = getNative(Object, 'defineProperty');
    func({}, '', {});
    return func;
  } catch (e) {}
}());

module.exports = defineProperty;


/***/ }),
/* 62 */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var funcProto = Function.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to convert.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

module.exports = toSource;


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

var baseFor = __webpack_require__(135),
    keys = __webpack_require__(12);

/**
 * The base implementation of `_.forOwn` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Object} Returns `object`.
 */
function baseForOwn(object, iteratee) {
  return object && baseFor(object, iteratee, keys);
}

module.exports = baseForOwn;


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

var ListCache = __webpack_require__(21),
    stackClear = __webpack_require__(144),
    stackDelete = __webpack_require__(145),
    stackGet = __webpack_require__(146),
    stackHas = __webpack_require__(147),
    stackSet = __webpack_require__(148);

/**
 * Creates a stack cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Stack(entries) {
  var data = this.__data__ = new ListCache(entries);
  this.size = data.size;
}

// Add methods to `Stack`.
Stack.prototype.clear = stackClear;
Stack.prototype['delete'] = stackDelete;
Stack.prototype.get = stackGet;
Stack.prototype.has = stackHas;
Stack.prototype.set = stackSet;

module.exports = Stack;


/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsEqualDeep = __webpack_require__(161),
    isObjectLike = __webpack_require__(15);

/**
 * The base implementation of `_.isEqual` which supports partial comparisons
 * and tracks traversed objects.
 *
 * @private
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @param {boolean} bitmask The bitmask flags.
 *  1 - Unordered comparison
 *  2 - Partial comparison
 * @param {Function} [customizer] The function to customize comparisons.
 * @param {Object} [stack] Tracks traversed `value` and `other` objects.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 */
function baseIsEqual(value, other, bitmask, customizer, stack) {
  if (value === other) {
    return true;
  }
  if (value == null || other == null || (!isObjectLike(value) && !isObjectLike(other))) {
    return value !== value && other !== other;
  }
  return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
}

module.exports = baseIsEqual;


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

var SetCache = __webpack_require__(162),
    arraySome = __webpack_require__(165),
    cacheHas = __webpack_require__(166);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/**
 * A specialized version of `baseIsEqualDeep` for arrays with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Array} array The array to compare.
 * @param {Array} other The other array to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `array` and `other` objects.
 * @returns {boolean} Returns `true` if the arrays are equivalent, else `false`.
 */
function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
      arrLength = array.length,
      othLength = other.length;

  if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
    return false;
  }
  // Assume cyclic values are equal.
  var stacked = stack.get(array);
  if (stacked && stack.get(other)) {
    return stacked == other;
  }
  var index = -1,
      result = true,
      seen = (bitmask & COMPARE_UNORDERED_FLAG) ? new SetCache : undefined;

  stack.set(array, other);
  stack.set(other, array);

  // Ignore non-index properties.
  while (++index < arrLength) {
    var arrValue = array[index],
        othValue = other[index];

    if (customizer) {
      var compared = isPartial
        ? customizer(othValue, arrValue, index, other, array, stack)
        : customizer(arrValue, othValue, index, array, other, stack);
    }
    if (compared !== undefined) {
      if (compared) {
        continue;
      }
      result = false;
      break;
    }
    // Recursively compare arrays (susceptible to call stack limits).
    if (seen) {
      if (!arraySome(other, function(othValue, othIndex) {
            if (!cacheHas(seen, othIndex) &&
                (arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
              return seen.push(othIndex);
            }
          })) {
        result = false;
        break;
      }
    } else if (!(
          arrValue === othValue ||
            equalFunc(arrValue, othValue, bitmask, customizer, stack)
        )) {
      result = false;
      break;
    }
  }
  stack['delete'](array);
  stack['delete'](other);
  return result;
}

module.exports = equalArrays;


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

var arrayPush = __webpack_require__(37),
    isArray = __webpack_require__(6);

/**
 * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
 * `keysFunc` and `symbolsFunc` to get the enumerable property names and
 * symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @param {Function} symbolsFunc The function to get the symbols of `object`.
 * @returns {Array} Returns the array of property names and symbols.
 */
function baseGetAllKeys(object, keysFunc, symbolsFunc) {
  var result = keysFunc(object);
  return isArray(object) ? result : arrayPush(result, symbolsFunc(object));
}

module.exports = baseGetAllKeys;


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

var arrayFilter = __webpack_require__(173),
    stubArray = __webpack_require__(69);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Built-in value references. */
var propertyIsEnumerable = objectProto.propertyIsEnumerable;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeGetSymbols = Object.getOwnPropertySymbols;

/**
 * Creates an array of the own enumerable symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of symbols.
 */
var getSymbols = !nativeGetSymbols ? stubArray : function(object) {
  if (object == null) {
    return [];
  }
  object = Object(object);
  return arrayFilter(nativeGetSymbols(object), function(symbol) {
    return propertyIsEnumerable.call(object, symbol);
  });
};

module.exports = getSymbols;


/***/ }),
/* 69 */
/***/ (function(module, exports) {

/**
 * This method returns a new empty array.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {Array} Returns the new empty array.
 * @example
 *
 * var arrays = _.times(2, _.stubArray);
 *
 * console.log(arrays);
 * // => [[], []]
 *
 * console.log(arrays[0] === arrays[1]);
 * // => false
 */
function stubArray() {
  return [];
}

module.exports = stubArray;


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(11);

/**
 * Checks if `value` is suitable for strict equality comparisons, i.e. `===`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` if suitable for strict
 *  equality comparisons, else `false`.
 */
function isStrictComparable(value) {
  return value === value && !isObject(value);
}

module.exports = isStrictComparable;


/***/ }),
/* 71 */
/***/ (function(module, exports) {

/**
 * A specialized version of `matchesProperty` for source values suitable
 * for strict equality comparisons, i.e. `===`.
 *
 * @private
 * @param {string} key The key of the property to get.
 * @param {*} srcValue The value to match.
 * @returns {Function} Returns the new spec function.
 */
function matchesStrictComparable(key, srcValue) {
  return function(object) {
    if (object == null) {
      return false;
    }
    return object[key] === srcValue &&
      (srcValue !== undefined || (key in Object(object)));
  };
}

module.exports = matchesStrictComparable;


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

var baseHasIn = __webpack_require__(186),
    hasPath = __webpack_require__(187);

/**
 * Checks if `path` is a direct or inherited property of `object`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 * @example
 *
 * var object = _.create({ 'a': _.create({ 'b': 2 }) });
 *
 * _.hasIn(object, 'a');
 * // => true
 *
 * _.hasIn(object, 'a.b');
 * // => true
 *
 * _.hasIn(object, ['a', 'b']);
 * // => true
 *
 * _.hasIn(object, 'b');
 * // => false
 */
function hasIn(object, path) {
  return object != null && hasPath(object, path, baseHasIn);
}

module.exports = hasIn;


/***/ }),
/* 73 */
/***/ (function(module, exports) {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

module.exports = identity;


/***/ }),
/* 74 */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsVarRange = '\\ufe0e\\ufe0f';

/** Used to compose unicode capture groups. */
var rsZWJ = '\\u200d';

/** Used to detect strings with [zero-width joiners or code points from the astral planes](http://eev.ee/blog/2015/09/12/dark-corners-of-unicode/). */
var reHasUnicode = RegExp('[' + rsZWJ + rsAstralRange  + rsComboRange + rsVarRange + ']');

/**
 * Checks if `string` contains Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a symbol is found, else `false`.
 */
function hasUnicode(string) {
  return reHasUnicode.test(string);
}

module.exports = hasUnicode;


/***/ }),
/* 75 */
/***/ (function(module, exports) {

module.exports = require("payline");

/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

var rng = __webpack_require__(217);
var bytesToUuid = __webpack_require__(219);

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof(options) == 'string') {
    buf = options == 'binary' ? new Array(16) : null;
    options = null;
  }
  options = options || {};

  var rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = (rnds[6] & 0x0f) | 0x40;
  rnds[8] = (rnds[8] & 0x3f) | 0x80;

  // Copy bytes to buffer, if provided
  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || bytesToUuid(rnds);
}

module.exports = v4;


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(38),
    baseSet = __webpack_require__(221),
    castPath = __webpack_require__(25);

/**
 * The base implementation of  `_.pickBy` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The source object.
 * @param {string[]} paths The property paths to pick.
 * @param {Function} predicate The function invoked per property.
 * @returns {Object} Returns the new object.
 */
function basePickBy(object, paths, predicate) {
  var index = -1,
      length = paths.length,
      result = {};

  while (++index < length) {
    var path = paths[index],
        value = baseGet(object, path);

    if (predicate(value, path)) {
      baseSet(result, castPath(path, object), value);
    }
  }
  return result;
}

module.exports = basePickBy;


/***/ }),
/* 78 */
/***/ (function(module, exports) {

module.exports = require("googleapis");

/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { Chromeless } = __webpack_require__(246);
const {
  NODE_ENV,
  CHROMELESS_ENDPOINT,
  CHROMELESS_SESSION_KEY,
  WEBSITE_URL
} = __webpack_require__(2);

function connect() {
  return new Chromeless(NODE_ENV === 'development' ? undefined : {
    remote: {
      endpointUrl: CHROMELESS_ENDPOINT,
      apiKey: CHROMELESS_SESSION_KEY
    }
  });
}

function invoiceAsPdf(orderId, lang) {
  const chromeless = connect();

  return chromeless.goto(`${WEBSITE_URL}/${lang}/invoice/${orderId}`).wait('div.invoice-content').pdf().then(pdf => {
    chromeless.end();

    return pdf;
  });
}

function pingService() {
  return connect().goto('https://www.google.com').await('body').end();
}

module.exports = {
  invoiceAsPdf,
  pingService
};

/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const config = __webpack_require__(2);

module.exports = function checkToken(req, res, next) {
  if ('secret_token' in req.query && req.query.secret_token === config.REST_API_SECRET) {
    req.user = true;
  }
  next();
};

/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const WebmergeApi = __webpack_require__(261).WebMergePromiseAPI;
const Promise = __webpack_require__(1);
const capitalize = __webpack_require__(10);
const values = __webpack_require__(28);
const D = __webpack_require__(4);
const Utils = __webpack_require__(3);
const config = __webpack_require__(2);
const {
  LEASE_DURATION,
  DEPOSIT_PRICES
} = __webpack_require__(0);

const _ = { capitalize, values };

const webmerge = new WebmergeApi(config.WEBMERGE_API_KEY, config.WEBMERGE_SECRET, Promise);

function serializeLease(renting) {
  const { Client, Terms, Room } = renting;
  const { Apartment } = Room;
  const { name, addressStreet, addressZip, addressCity } = Apartment;
  const bookingDate = renting.bookingDate || new Date();
  const identity = JSON.parse(Client.Metadata[0].value);
  const fullAddress = _.values(identity.address).filter(Boolean).join(', ');
  const birthDate = _.values(identity.birthDate).join('/');
  const roomNumber = name.split(' ').splice(-1)[0] === 'studio' ? 'l\'appartement entier' : `la chambre privée nº${Room.reference.slice(-1)}`;
  const depositOption = !Terms[0] || Terms[0] && Terms[0].name === 'cash' ? 'd\'encaissement du montant' : 'de non encaissement du chèque';
  let packLevel;

  switch (renting.get('comfortLevel')) {
    case 'comfort':
      packLevel = 'Confort';
      break;
    case 'privilege':
      packLevel = 'Privilège';
      break;
    default:
      packLevel = 'Basique';
      break;
  }

  return Promise.resolve({
    fullName: `${Client.firstName} ${Client.lastName.toUpperCase()}`,
    fullAddress,
    birthDate,
    birthPlace: Utils.toSingleLine(`
      ${identity.birthPlace.first}
      (${_.capitalize(identity.birthCountryFr)})
    `),
    nationality: identity.nationalityFr,
    rent: renting.price / 100,
    serviceFees: renting.serviceFees / 100,
    deposit: DEPOSIT_PRICES[addressCity] / 100,
    depositOption,
    packLevel,
    roomNumber,
    roomFloorArea: Room.floorArea,
    floorArea: Apartment.floorArea,
    address: `${addressStreet}, ${_.capitalize(addressCity)}, ${addressZip}`,
    floor: Apartment.floor === 0 ? 'rez-de-chausée' : Apartment.floor,
    bookingDate: D.format(bookingDate, 'DD/MM/YYYY'),
    endDate: D.format(D.addMonths(D.subDays(bookingDate, 1), LEASE_DURATION), 'DD/MM/YYYY'),
    email: Client.email
  });
}

function mergeLease(data) {
  return webmerge.mergeDocument(config.WEBMERGE_DOCUMENT_ID, config.WEBMERGE_DOCUMENT_KEY, data, config.NODE_ENV !== 'production' // webmerge's test environment switch
  );
}

function pingService() {
  return webmerge.getDocument(config.WEBMERGE_DOCUMENT_ID);
}

module.exports = {
  serializeLease,
  mergeLease,
  pingService
};

/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(83);


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/* eslint-disable no-console */
const http = __webpack_require__(84);
const app = __webpack_require__(85);

/*
 * Initialize server
 */
const port = normalizePort(process.env.PORT || '3000');

app.set('port', port);
const server = http.createServer(app);

/*
 * Load models
 */
server.listen(port, function () {
  console.log(`Express server listening on port ${server.address().port}`);
});
server.on('error', onError);
server.on('listening', onListening);

/*
 * Utils
 */
function normalizePort(val) {
  const port = parseInt(val, 10);

  if (isNaN(port)) {
    return val;
  }

  if (port >= 0) {
    return port;
  }

  return false;
}

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  const bind = typeof port === 'string' ? `Pipe ${port}` : `Port ${port}`;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(`${bind} requires elevated privileges`);
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(`${bind} is already in use`);
      process.exit(1);
      break;
    default:
      throw error;
  }
}

function onListening() {
  const addr = server.address();
  const bind = typeof addr === 'string' ? `pipe ${addr}` : `port ${addr.port}`;

  console.log(`Listening on ${bind}`);
}

/***/ }),
/* 84 */
/***/ (function(module, exports) {

module.exports = require("http");

/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Express = __webpack_require__(86);
const Jwt = __webpack_require__(87);
const Cors = __webpack_require__(88);
const BodyParser = __webpack_require__(43);
const Liana = __webpack_require__(5);
const values = __webpack_require__(28);
const cookieParser = __webpack_require__(100);
const config = __webpack_require__(2);
const models = __webpack_require__(52);
const routes = __webpack_require__(286);
const checkToken = __webpack_require__(80);
const smartCollections = __webpack_require__(287);

const parentApp = Express();
const app = Express();
const { Schemas } = Liana;
const _ = { values };

/*
 * Middleware that will handle our custom Forest routes
 */
app.use(cookieParser());

// JWT authentication
app.use(Jwt({
  secret: config.FOREST_AUTH_SECRET,
  credentialsRequired: false,
  getToken(request) {
    if (request.cookies && request.cookies.authorized && request.cookies.authorized.split(' ')[0] === 'Bearer') {
      return request.cookies.authorized.split(' ')[1];
    }
    if (request.headers && request.headers.authorization && request.headers.authorization.split(' ')[0] === 'Bearer') {
      return request.headers.authorization.split(' ')[1];
    }
    if (request.query && request.query.sessionToken) {
      return request.query.sessionToken;
    }
    return null;
  }
}));

// Token authentication
app.use(checkToken);

// CORS
app.use(Cors({
  origin: [/^http:\/\/0\.0\.0\.0:/, /^http:\/\/127\.0\.0\.1:/, /^http:\/\/localhost:/, /\.forestadmin\.com$/, /\.chez-nestor\.com$/],
  allowedHeaders: ['Authorization', 'X-Requested-With', 'Content-Type', 'Access-Control-Allow-Origin', 'Access-Control-Allow-Credentials', 'Set-Cookie'],
  credentials: true
}));

// Mime type
app.use(BodyParser.json({ limit: '10mb' }));

_.values(models).forEach(function (model) {
  if ('routes' in model) {
    model.routes(app, models, model);
  }
});

// Register non-model-specific routes (e.g. ping and login)
routes(app);

parentApp.use(app);

// - Hijack Schemas.perform to load Liana collections ourselves
//   → definitely prevent forest-express from trapping our errors, YAY!
// - Hijack integrator.defineCollections to throw before apimap updates
//   → prevent deploys from overwriting production layout, YAY!
Schemas._perform = Schemas.perform;
Schemas.perform = function (Implementation, integrator) {
  // Hijack integrator.defineCollections
  integrator._defineCollections = integrator.defineCollections;
  integrator.defineCollections = function () {
    integrator._defineCollections.apply(integrator, arguments);
    if (config.NODE_ENV === 'production') {
      throw new Error('You shall not pass!');
    }
  };

  return Schemas._perform.apply(Schemas, arguments).tap(() => {
    // load collections for models
    Object.keys(models).forEach(modelName => {
      if ('collection' in models[modelName]) {
        Liana.collection(modelName, models[modelName].collection(models));
      }
    });
    // load smart collections
    Object.keys(smartCollections).forEach(name => {
      Liana.collection(name, smartCollections[name](models));
    });
  });
};

/*
 * Forest middleware
 */
parentApp.use(Liana.init({
  sequelize: models.sequelize,
  envSecret: config.FOREST_ENV_SECRET,
  authSecret: config.FOREST_AUTH_SECRET
}));

// This hook is currently useless
Object.keys(models).forEach(function (modelName) {
  if ('afterLianaInit' in models[modelName]) {
    models[modelName].afterLianaInit(parentApp, models, models[modelName]);
  }
});

module.exports = parentApp;

/***/ }),
/* 86 */
/***/ (function(module, exports) {

module.exports = require("express");

/***/ }),
/* 87 */
/***/ (function(module, exports) {

module.exports = require("express-jwt");

/***/ }),
/* 88 */
/***/ (function(module, exports) {

module.exports = require("cors");

/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

var arrayMap = __webpack_require__(19);

/**
 * The base implementation of `_.values` and `_.valuesIn` which creates an
 * array of `object` property values corresponding to the property names
 * of `props`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array} props The property names to get values for.
 * @returns {Object} Returns the array of property values.
 */
function baseValues(object, props) {
  return arrayMap(props, function(key) {
    return object[key];
  });
}

module.exports = baseValues;


/***/ }),
/* 90 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.times` without support for iteratee shorthands
 * or max array length checks.
 *
 * @private
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 */
function baseTimes(n, iteratee) {
  var index = -1,
      result = Array(n);

  while (++index < n) {
    result[index] = iteratee(index);
  }
  return result;
}

module.exports = baseTimes;


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(13),
    isObjectLike = __webpack_require__(15);

/** `Object#toString` result references. */
var argsTag = '[object Arguments]';

/**
 * The base implementation of `_.isArguments`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 */
function baseIsArguments(value) {
  return isObjectLike(value) && baseGetTag(value) == argsTag;
}

module.exports = baseIsArguments;


/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(14);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/** Built-in value references. */
var symToStringTag = Symbol ? Symbol.toStringTag : undefined;

/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */
function getRawTag(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag),
      tag = value[symToStringTag];

  try {
    value[symToStringTag] = undefined;
    var unmasked = true;
  } catch (e) {}

  var result = nativeObjectToString.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag] = tag;
    } else {
      delete value[symToStringTag];
    }
  }
  return result;
}

module.exports = getRawTag;


/***/ }),
/* 93 */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */
function objectToString(value) {
  return nativeObjectToString.call(value);
}

module.exports = objectToString;


/***/ }),
/* 94 */
/***/ (function(module, exports) {

/**
 * This method returns `false`.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {boolean} Returns `false`.
 * @example
 *
 * _.times(2, _.stubFalse);
 * // => [false, false]
 */
function stubFalse() {
  return false;
}

module.exports = stubFalse;


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(13),
    isLength = __webpack_require__(31),
    isObjectLike = __webpack_require__(15);

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
    arrayTag = '[object Array]',
    boolTag = '[object Boolean]',
    dateTag = '[object Date]',
    errorTag = '[object Error]',
    funcTag = '[object Function]',
    mapTag = '[object Map]',
    numberTag = '[object Number]',
    objectTag = '[object Object]',
    regexpTag = '[object RegExp]',
    setTag = '[object Set]',
    stringTag = '[object String]',
    weakMapTag = '[object WeakMap]';

var arrayBufferTag = '[object ArrayBuffer]',
    dataViewTag = '[object DataView]',
    float32Tag = '[object Float32Array]',
    float64Tag = '[object Float64Array]',
    int8Tag = '[object Int8Array]',
    int16Tag = '[object Int16Array]',
    int32Tag = '[object Int32Array]',
    uint8Tag = '[object Uint8Array]',
    uint8ClampedTag = '[object Uint8ClampedArray]',
    uint16Tag = '[object Uint16Array]',
    uint32Tag = '[object Uint32Array]';

/** Used to identify `toStringTag` values of typed arrays. */
var typedArrayTags = {};
typedArrayTags[float32Tag] = typedArrayTags[float64Tag] =
typedArrayTags[int8Tag] = typedArrayTags[int16Tag] =
typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] =
typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] =
typedArrayTags[uint32Tag] = true;
typedArrayTags[argsTag] = typedArrayTags[arrayTag] =
typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] =
typedArrayTags[dataViewTag] = typedArrayTags[dateTag] =
typedArrayTags[errorTag] = typedArrayTags[funcTag] =
typedArrayTags[mapTag] = typedArrayTags[numberTag] =
typedArrayTags[objectTag] = typedArrayTags[regexpTag] =
typedArrayTags[setTag] = typedArrayTags[stringTag] =
typedArrayTags[weakMapTag] = false;

/**
 * The base implementation of `_.isTypedArray` without Node.js optimizations.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 */
function baseIsTypedArray(value) {
  return isObjectLike(value) &&
    isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
}

module.exports = baseIsTypedArray;


/***/ }),
/* 96 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.unary` without support for storing metadata.
 *
 * @private
 * @param {Function} func The function to cap arguments for.
 * @returns {Function} Returns the new capped function.
 */
function baseUnary(func) {
  return function(value) {
    return func(value);
  };
}

module.exports = baseUnary;


/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module) {var freeGlobal = __webpack_require__(45);

/** Detect free variable `exports`. */
var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Detect free variable `process` from Node.js. */
var freeProcess = moduleExports && freeGlobal.process;

/** Used to access faster Node.js helpers. */
var nodeUtil = (function() {
  try {
    return freeProcess && freeProcess.binding && freeProcess.binding('util');
  } catch (e) {}
}());

module.exports = nodeUtil;

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(47)(module)))

/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

var isPrototype = __webpack_require__(49),
    nativeKeys = __webpack_require__(99);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function baseKeys(object) {
  if (!isPrototype(object)) {
    return nativeKeys(object);
  }
  var result = [];
  for (var key in Object(object)) {
    if (hasOwnProperty.call(object, key) && key != 'constructor') {
      result.push(key);
    }
  }
  return result;
}

module.exports = baseKeys;


/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

var overArg = __webpack_require__(50);

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeKeys = overArg(Object.keys, Object);

module.exports = nativeKeys;


/***/ }),
/* 100 */
/***/ (function(module, exports) {

module.exports = require("cookie-parser");

/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// ## USAGE:
// To get this to work in production, you need to set NODE_ENV on your server,
// Values defined as function will be executed at the end of this script and
// immediatly replaced by their return value.

const common = {
  // The API secret to use any method of the backoffice REST API
  REST_API_SECRET: "saBehciNeiOLtuaHehciNeiPaL",
  REST_API_URL: "http://localhost:3000",
  WEBSITE_URL: "http://localhost:8080",

  INVOICENINJA_HOST: "payment-dev.chez-nestor.com",
  INVOICENINJA_API_KEY: "rKJcq5iHl7Dt0jahBXRUrjAc8LHYOAgm",
  INVOICENINJA_PROTOCOL: "http",

  GOOGLE_TYPE: "service_account",
  GOOGLE_PROJECT_ID: "i-backbone-167710",
  GOOGLE_PRIVATE_KEY_ID: "f8b12e04acd32182484841b5cfdb4094f555fdc8",
  GOOGLE_PRIVATE_KEY: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCBk/QbENOEZ5m8\ns9ygzT2BR1h7NUvgskQFD7tb3TlsD80bTTyoH3Ft7477gbk6nOiHnzgggJoUbEPi\njf96OIoEhRJO8gBJkQL2yt62jnBClq44Av0mDQO9XECK3UDjTxsjsmVMGoPX0LID\n7H6tXKxIXXHqOed6WmohXS/aoxk7N/zlPudEDXyLAYyPrY90SOtIvbgOVhbh1GZQ\nlgUHqVv95M8QHLb9eFnAkhlVah2aEWEJomroDWhoWpC1vwUbsXIc5TBDAcMEic/I\nH2CRWN1zlPd0g0lNQPyHdggJs3XGNjigMdDhKI9Jwmz27wIXQucXpg4gszqo7QRQ\nsS1oX+6nAgMBAAECggEAIjeJrGQDFuGsrTHpvuSzqyHF8bMfOFSataNz3ExMz4ZU\nqTL6I4M6Fse9wBh/a0Tn+nhG//41sdLtEjRhFEs91ve03/fzr3mFiNoFebufVVYo\n502Sv6uMI0LrIEBQ1DWdew2uxivySNkpSPP4d5sTO4DBhhKIV7zsbacH7fpHvWUp\nSDEppcNXwqMU9V8giYpB/C/z1qhqbbx73SwZudQ2VWV5Te9QBRCBXN8JDtA9YN+c\nZqySXIpNwdQDKHnzXoAXX415L+VaaYWj4GmOfKVWDYkMPPHywxW15+xs2aPPN4bf\nEvqZ4hbZPoQ7k1Clte/5XPcICk/dQvyCTu0a0XrFkQKBgQC2OMhk1GRNH0eGGHet\ndDY+tAWUHZmKLBCLA5ZWtpLu9yX21ZyPyF9pjlz4dVunHQX0BFLzKNtzX22ey/IX\nmA3Hth4lNCBTNW2YmDr7rTCjqNoPtwmm9PKGsZRa7qbroTllHKUVYQXDANOpUe5p\nThJlBtU6/0/k3+hD7l5omfqcOwKBgQC2CqfFZzbnrV0TJqYhTXSyV+w9SSmkuxtB\nyehaxPkxgcNj8Cx1IQfrpjRy8lIml5jxM+wTd2lsw41IHfjkwBb18AKlcU1jZmDN\ngh4Z8vtdR/opXCq8KE/7665OE8p2oMzM+k8nLh17huRCmdhvRPLc7/DZvNRi2Wl/\nzuE5ke4MhQKBgQC0QNVSkJsrgx6gcoGoboXeXvwJuYIRoWc37HOCEZallovScRov\nTRm89BvZl1XzqI0kBkb7zFXQ+fwZEkvHtR0kim2lhbvYM8jXIvdt0LOFoVkcJIcC\nxdlHDlDf5qXt/o0lDUHsNQ6bCK1YF/kL6DPgBfNWKgqhMDC1Sg3P0UmL0wKBgQCh\nBo3fFOzBRF3HWfGsFaq7MwDaOURn3cY/jI1G9WOEQkeGuGVq+lvaO7u7TdQTJRf5\njDcwBPmxZs0rVK/cEHp+894zYCTXXzETuBxOUdu9aLTFLyzyISqXKaOWlvUJuDVQ\nv72SZ71WjjyNGS8VRcUaX/gJcnngMnaawnIBja8nTQKBgGvwAAHIrw7l6GoNOAOq\nYKLwDF7DBeZepWo6y0AKYMdY41GDqJPe0l3AmmurgcmmSU3Q7JUMgzn3AhxWQfmk\nsuthmYnM8E3uEQQZWSeKyhCChKiafPzve8+eeitF/EEUG3bID2DGKJw6Aov19abN\n11iF+1CnrYANJi2W36Vgpjbg\n-----END PRIVATE KEY-----\n",
  GOOGLE_CLIENT_EMAIL: "backoffice-to-calendar-sync@i-backbone-167710.iam.gserviceaccount.com",
  GOOGLE_CLIENT_ID: "100489238668389599488",
  GOOGLE_AUTH_URI: "https://accounts.google.com/o/oauth2/auth",
  GOOGLE_TOKEN_URI: "https://accounts.google.com/o/oauth2/token",
  GOOGLE_auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  GOOGLE_client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/backoffice-to-calendar-sync%40i-backbone-167710.iam.gserviceaccount.com",

  GOOGLE_CALENDAR_IDS: {
    "lyon": "c2521aboec124smjfcnh6shngk@group.calendar.google.com",
    "montpellier": "lsv6pnk52pbu355ft1h9mssbcg@group.calendar.google.com",
    "paris": "782t4o6j03g58upqfr9egf8uk4@group.calendar.google.com",
    "refund-deposit": "0e7sgvoldas3bi80vcvfld5u64@group.calendar.google.com"
  },

  GOOGLE_MAPS_API_KEY: "AIzaSyAQsTqO1dLsnGxoPPpXTsQ2BGndRfkcnRI",
  GOOGLE_TRANSLATE_API_KEY: "AIzaSyA3lXwSdwFK_UpnXLiCVSku-WN5q9XkLgM",

  // Payline "homologation" config
  // PAYLINE_HOMOLOGATION: true,
  // PAYLINE_MERCHANT_ID: "49148860991508",
  // PAYLINE_ACCESS_KEY: "q90PRbz8ogRnAxN1ckLP",
  // PAYLINE_CONTRACT_NUMBER: "1234567",

  PAYLINE_MERCHANT_ID: "77969542256044",
  PAYLINE_ACCESS_KEY: "pIC4LyvCNPcuvAyPsmrz",
  PAYLINE_CONTRACT_NUMBER: "4326159",

  SMTP_HOST: "email-smtp.eu-west-1.amazonaws.com",
  SMTP_USER: "AKIAI65E4H3GSBABXW4A",
  SMTP_PASSWORD: "AtkBZq6uw1G8l7rQwUisTErV+hVe/esK8Gm91obt+Cp+",

  // Claudia-Lambda user
  //AWS_ACCESS_KEY_ID: "AKIAIYA3ANKXHZ7Z6OYA",
  //AWS_SECRET_ACCESS_KEY: "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",

  // up-user user
  AWS_ACCESS_KEY_ID: "AKIAIMIPWNCVILODSSTQ",
  AWS_SECRET_ACCESS_KEY: "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",

  AWS_REGION: 'eu-west-1',
  AWS_IOT_HOST: 'a2njrgj6xer46n.iot.eu-west-1.amazonaws.com', // used by chromeless
  AWS_BUCKET_PICTURES: 'pictures-staging.chez-nestor.com',

  WEBMERGE_DOCUMENT_ID: 90942,
  WEBMERGE_DOCUMENT_KEY: "rzyitr",
  WEBMERGE_API_KEY: 'VUE9BC4PC7QQ7PIR7ZAEX66WNRJQ',
  WEBMERGE_SECRET: 'AKVW6ZV7',

  IMAGE_OPTIM_KEY: 'kbckdsfkwh',

  CHROMELESS_SESSION_KEY: 'TYpmHRKJy613OS8fCJsGf4yijAehYlx42bRfNDT4',
  CHROMELESS_ENDPOINT: 'https://1zx7ig1u12.execute-api.eu-west-1.amazonaws.com/dev/',

  SENDINBLUE_API_KEY: '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',
  SENDINBLUE_TEMPLATE_IDS: {
    welcome: { fr: 7, en: 6 },
    deposit: { fr: 4, en: 5 },
    newHousemate: { fr: 3, en: 2 },
    rentInvoice: 19,
    unpaidRent: { fr: 21, en: 14 },
    lateFees: { fr: 20, en: 15 },
    dueDate: { fr: 22, en: 23 }
  },
  SENDINBLUE_LIST_IDS: {
    lyon: { fr: 15, en: 16, all: 14 },
    montpellier: { fr: 17, en: 18, all: 13 },
    paris: { fr: 20, en: 19, all: 12 },
    prospects: { fr: 21, en: 27 },
    archived: 25,
    en: 9,
    fr: 8
  }
};

const environments = {
  test: {
    FOREST_ENV_SECRET: "4b49375e9d9fa8ecccbe042ea76e595feb62b0cb94e0040ad2c601c063dbc46d",
    FOREST_AUTH_SECRET: "LaPieNicheHautLOieNicheBas",

    SEQUELIZE_DIALECT: "sqlite",
    SEQUELIZE_HOST: ":memory:", // switch that back to a path if you want to inspect the db
    SEQUELIZE_DATABASE: "test",
    SEQUELIZE_USERNAME: "admin",
    SEQUELIZE_PASSWORD: "pass",

    INVOICENINJA_HOST: "localhost:8000",
    INVOICENINJA_API_KEY: "fnbttrwkvsvt77gsfuiqqfnkizumf1vg",
    INVOICENINJA_PROTOCOL: "http",

    BLUEBIRD_DEBUG: 1
  },

  development: {
    FOREST_ENV_SECRET: "4b49375e9d9fa8ecccbe042ea76e595feb62b0cb94e0040ad2c601c063dbc46d",
    FOREST_AUTH_SECRET: "LaPieNicheHautLOieNicheBas",
    FOREST_RENDERING_ID: 7713,

    SEQUELIZE_DIALECT: "sqlite",
    SEQUELIZE_HOST: ".dev.sqlite",
    SEQUELIZE_DATABASE: "development",
    SEQUELIZE_USERNAME: "admin",
    SEQUELIZE_PASSWORD: "pass",

    BLUEBIRD_DEBUG: 1,

    SENDINBLUE_TEMPLATE_IDS: {
      welcome: {
        fr: 7,
        en: 6
      },
      deposit: {
        fr: 4,
        en: 5
      },
      newHousemate: {
        fr: 3,
        en: 2
      },
      rentInvoice: 1,
      unpaidRent: {
        fr: 21,
        en: 14
      },
      lateFees: {
        fr: 20,
        en: 15
      },
      dueDate: {
        fr: 22,
        en: 23
      }
    }
  },

  staging: {
    REST_API_URL: "https://ucyldwzph9.execute-api.eu-west-1.amazonaws.com/staging",
    WEBSITE_URL: "http://staging.chez-nestor.com",

    FOREST_ENV_SECRET: "44a8838419044fdb4c91b2b245817cb7f5c95e272b1f4b607a4299fe0880712d",
    FOREST_AUTH_SECRET: "LaPieNicheHautLOieNicheBasStaging",
    FOREST_RENDERING_ID: 11552,

    SEQUELIZE_DIALECT: "mysql",
    SEQUELIZE_HOST: "maria-m4large-ireland-1.cv9cmkgusndr.eu-west-1.rds.amazonaws.com",
    SEQUELIZE_DATABASE: "backoffice-staging",
    SEQUELIZE_USERNAME: "root",
    SEQUELIZE_PASSWORD: "LaPieNicheHaut",

    // Claudia config
    lambda: {
      role: "chez-nestor_com-executor",
      name: "chez-nestor-stag_com",
      region: "eu-west-1",
      runtime: "nodejs6.10",
      memory: "384"
    },
    api: {
      id: "7789dwm2t3",
      url: "https://7789dwm2t3.execute-api.eu-west-1.amazonaws.com/latest"
    }
  },

  production: {
    REST_API_URL: "https://ucyldwzph9.execute-api.eu-west-1.amazonaws.com/production",
    WEBSITE_URL: "http://beta.chez-nestor.com",

    FOREST_ENV_SECRET: "77e0eb9873c4b1669f7e3a21f82754a50b5046dafb9f05298270efd2d763b887",
    FOREST_AUTH_SECRET: "LaPieNicheHautLOieNicheBasProduction",
    FOREST_RENDERING_ID: 11539,

    SEQUELIZE_DIALECT: "mysql",
    SEQUELIZE_HOST: "maria-m4large-ireland-1.cv9cmkgusndr.eu-west-1.rds.amazonaws.com",
    SEQUELIZE_DATABASE: "backoffice",
    SEQUELIZE_USERNAME: "root",
    SEQUELIZE_PASSWORD: "LaPieNicheHaut",

    INVOICENINJA_HOST: "payment.chez-nestor.com",
    INVOICENINJA_API_KEY: "rKJcq5iHl7Dt0jahBXRUrjAc8LHYOAgm",
    INVOICENINJA_PROTOCOL: "https",

    PAYLINE_MERCHANT_ID: "77969542256044",
    PAYLINE_ACCESS_KEY: "pIC4LyvCNPcuvAyPsmrz",
    PAYLINE_CONTRACT_NUMBER: "4326159",

    SENDINBLUE_API_KEY: "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",

    GOOGLE_CALENDAR_IDS: {
      "montpellier": "b9qrdqj6baqcb1l7ur83ea7vd8@group.calendar.google.com",
      "paris": "df1250ldd1pnlaemlcj2i52oj0@group.calendar.google.com",
      "lyon": "bqmqk8sasnotnmfs2tbph8c5dg@group.calendar.google.com",
      "refund-deposit": "49v95402prlc7ug6m5o2nj0ls8@group.calendar.google.com"
    },

    AWS_BUCKET_PICTURES: 'pictures.chez-nestor.com',

    // Claudia config
    lambda: {
      role: "chez-nestor_com-executor",
      name: "chez-nestor_com",
      region: "eu-west-1",
      runtime: "nodejs6.10",
      memory: "384"
    },
    api: {
      id: "scqg8r1bs4",
      url: "https://scqg8r1bs4.execute-api.eu-west-1.amazonaws.com/latest"
    }
  }
};

// Set common values as default values to the selected env
const NODE_ENV = undefined || 'development';
let env = Object.assign({ NODE_ENV }, common, environments[NODE_ENV]);

// log env to the console if used with `> node .env.js --log`
// (be careful with that, your secrets could appear in your travis build logs!)
if (process.argv[2] === '--log') {
  console.log(JSON.stringify(env));
}

module.exports = env;

/***/ }),
/* 102 */
/***/ (function(module, exports) {

module.exports = require("sequelize");

/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Geocode = __webpack_require__(53);
const { TRASH_SCOPES } = __webpack_require__(0);
const collection = __webpack_require__(105);
const routes = __webpack_require__(106);
const hooks = __webpack_require__(129);

module.exports = (sequelize, DataTypes) => {
  const Apartment = sequelize.define('Apartment', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    reference: {
      type: DataTypes.STRING,
      unique: true
    },
    name: DataTypes.STRING,
    addressStreet: DataTypes.STRING,
    addressZip: DataTypes.STRING,
    addressCity: DataTypes.ENUM('lyon', 'montpellier', 'paris'),
    addressCountry: DataTypes.ENUM('france'),
    code: DataTypes.STRING,
    floor: DataTypes.INTEGER,
    roomCount: {
      type: DataTypes.INTEGER,
      required: true,
      allowNull: false
    },
    latLng: DataTypes.STRING,
    floorArea: DataTypes.FLOAT,
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      defaultValue: 'active'
      // required: true,
      // allowNull: false,
    },
    district: DataTypes.STRING
  }, {
    paranoid: true,
    scopes: Object.assign({
      lyon: {
        where: {
          addressCity: 'lyon'
        }
      },
      paris: {
        where: {
          addressCity: 'paris'
        }
      },
      montpellier: {
        where: {
          addressCity: 'montpellier'
        }
      }
    }, TRASH_SCOPES)
  });
  const { models } = sequelize;

  Apartment.associate = () => {
    Apartment.hasMany(models.Room);
    Apartment.hasMany(models.Picture, {
      foreignKey: 'PicturableId',
      constraints: false,
      scope: { picturable: 'Apartment' }
    });
    Apartment.hasMany(models.Term, {
      foreignKey: 'TermableId',
      constraints: false,
      scope: { termable: 'Apartment' }
    });

    Apartment.addScope('_roomCount', {
      attributes: { include: [[sequelize.fn('count', sequelize.col('Rooms.id')), '_roomCount']] },
      include: [{
        model: models.Room,
        attributes: []
      }],
      group: ['Apartment.id']
    });
  };

  Apartment.prototype.calculateLatLng = function (addressValues = this.dataValues) {
    return Geocode([addressValues.addressStreet, addressValues.addressZip, addressValues.addressCountry].join(',')).then(({ lat, lng }) => {
      this.set('latLng', `${lat},${lng}`);
      return this;
    });
  };

  Apartment.collection = collection;
  Apartment.routes = routes;
  Apartment.hooks = hooks;

  return Apartment;
};

/***/ }),
/* 104 */
/***/ (function(module, exports) {

module.exports = require("urlencode");

/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SEGMENTS } = __webpack_require__(0);

module.exports = function ({ Picture }) {
  return {
    fields: [{
      field: 'current-clients',
      type: ['String'],
      reference: 'Client.id'
    }, {
      field: 'cover picture',
      type: 'String',
      get(object) {
        return Picture.findOne({
          where: {
            PicturableId: object.id
          }
        }).then(picture => {
          return picture ? picture.url : null;
        });
      }
    }],
    actions: [{
      name: 'Restore Apartment'
    }, {
      name: 'Destroy Apartment'
    }, {
      name: 'Maintenance Period',
      fields: [{
        field: 'from',
        type: 'Date',
        isRequired: true
      }, {
        field: 'to',
        type: 'Date'
      }]
    }],
    segments: TRASH_SEGMENTS.concat([{
      name: 'Lyon',
      scope: 'lyon'
    }, {
      name: 'Montpellier',
      scope: 'montpellier'
    }, {
      name: 'Paris',
      scope: 'paris'
    }])
  };
};

/***/ }),
/* 106 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const bodyParser = __webpack_require__(43);
const Liana = __webpack_require__(5);
const Aws = __webpack_require__(20);
const Utils = __webpack_require__(3);

module.exports = function (app, models, Apartment) {
  const LEA = Liana.ensureAuthenticated;
  let urlencodedParser = bodyParser.urlencoded({ extended: true });

  app.post('/forest/actions/send-sms', urlencodedParser, LEA, (req, res) => {
    const { values, ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (!ids || ids.length > 1) {
        throw new Error('You have to select one apartment');
      }
      return models.Client.scope('currentApartment').findAll({ where: { '$Rentings->Room.ApartmentId$': ids } });
    }).tap(clients => {
      return Aws.sendSms(clients.map(client => {
        return client.phoneNumber;
      }).filter(Boolean), // filter-out falsy values
      values.bodySms);
    }).then(clients => {
      return res.status(200).send({
        success: `SMS successfully sent to ${clients.length} clients!`
      });
    }).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/maintenance-period', LEA, (req, res) => {
    const { values, ids } = req.body.data.attributes;

    const where = req.body.data.attributes['collection_name'] === 'Apartment' ? { ApartmentId: { $in: ids } } : { id: { $in: ids } };

    return models.Room.scope('availableAt').findAll({ where }).filter(room => {
      return room.checkAvailability(new Date(values.from));
    }).map(room => {
      return room.createMaintenancePeriod(values);
    }).then(Utils.createSuccessHandler(res, 'Maintenance period')).catch(Utils.logAndSend(res));
  });

  Utils.addInternalRelationshipRoute({
    app,
    sourceModel: Apartment,
    associatedModel: models.Client,
    routeName: 'current-clients',
    scope: 'currentApartment',
    where: req => {
      return {
        '$Rentings->Room.ApartmentId$': req.params.recordId,
        '$Rentings.bookingDate$': { $lte: new Date() }
      };
    }
  });

  Utils.addRestoreAndDestroyRoutes(app, Apartment);
};

/***/ }),
/* 107 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 108 */
/***/ (function(module, exports) {

module.exports = require("form-data");

/***/ }),
/* 109 */
/***/ (function(module, exports) {

module.exports = require("strip-indent");

/***/ }),
/* 110 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Liana = __webpack_require__(5);
const logAndSend = __webpack_require__(33);

const LEA = Liana.ensureAuthenticated;
const Serializer = Liana.ResourceSerializer;

module.exports = function ({ app, sourceModel, associatedModel, routeName, scope, where }) {
  return app.get(`/forest/${sourceModel.name}/:recordId/relationships/${routeName}`, LEA, (req, res) => {
    associatedModel.scope(scope).findAll(where && { where: where(req) }).then(records => {
      return new Serializer(Liana, associatedModel, records, {}, {
        count: records.length
      }).perform();
    }).then(result => {
      return res.send(result);
    }).catch(logAndSend(res));
  });
};

/***/ }),
/* 111 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const Liana = __webpack_require__(5);
const logAndSend = __webpack_require__(33);
const {
  restoreSuccessHandler,
  destroySuccessHandler
} = __webpack_require__(55);

function restore(instances) {
  return Promise.all(instances.filter(instance => {
    return instance.deletedAt != null;
  }).map(instance => {
    return instance.set('status', 'active').restore();
  })).then(filterInstances => {
    return filterInstances.length;
  });
}

function destroy(instances) {
  return Promise.all(instances.filter(instance => {
    return instance.deletedAt != null;
  }).map(instance => {
    return instance.destroy({ force: true });
  })).then(filterInstances => {
    return filterInstances.length;
  });
}

module.exports = function (app, Model) {
  const LEA = Liana.ensureAuthenticated;
  const name = Model.name.toLocaleLowerCase();

  app.post(`/forest/actions/restore-${name}`, LEA, (req, res) => {
    Model.findAll({
      where: { id: { $in: req.body.data.attributes.ids } },
      paranoid: false
    }).then(instances => {
      return restore(instances);
    }).then(value => {
      return restoreSuccessHandler(res, `${value} ${Model.name}s`);
    }).catch(logAndSend(res));
  });

  app.post(`/forest/actions/destroy-${name}`, LEA, (req, res) => {
    Model.findAll({
      where: { id: { $in: req.body.data.attributes.ids } },
      paranoid: false
    }).then(instances => {
      return destroy(instances);
    }).then(value => {
      return destroySuccessHandler(res, `${value} ${Model.name}s`);
    }).catch(logAndSend(res));
  });
};

/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/* eslint-disable no-invalid-this */
function calculatedPropsMemoizer(Model) {
  this.Model = Model;
  this.cache = new WeakMap();
}
/* eslint-enable no-invalid-this */

// #getCalculatedProps with a WeakMap cache
calculatedPropsMemoizer.prototype.getCalculatedProps = function (object) {
  // It seems sometimes object isn't an Model instance
  if (!('dataValues' in object)) {
    return this.Model.findById(object.id).then(instance => {
      return this.getCalculatedProps(instance);
    });
  }

  if (this.cache.has(object)) {
    return this.cache.get(object);
  }

  const promise = object.getCalculatedProps();

  this.cache.set(object, promise);

  return promise;
};

module.exports = calculatedPropsMemoizer;

/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const toSingleLine = __webpack_require__(56);

module.exports = function (res, subject) {
  return result => {
    const count = Array.isArray(result) ? result.length : 1;

    res.status(200).send({ success: toSingleLine(`\
      ${count} ${subject}${count > 1 ? 's' : ''}\
      ${count > 0 ? ' successfully' : ''} created`) });
  };
};

/***/ }),
/* 114 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (res, subject) {
  return ([, isCreated]) => {
    if (!isCreated) {
      throw new Error(`${subject} already exists.`);
    }

    res.status(200).send({ success: `${subject} successfully created.` });
  };
};

/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const D = __webpack_require__(4);
const {
  BASIC_PACK,
  PRIVILEGE_PACK,
  SPECIAL_CHECKIN_PRICES
} = __webpack_require__(0);
const isHoliday = __webpack_require__(58);

function isWorkingHours(date) {
  const startOfDay = D.startOfDay(date);

  return D.isWithinRange(date, D.addHours(startOfDay, 9), D.addHours(startOfDay, 18));
}

function isSpecialDate(date) {
  return D.isWeekend(date) || !isWorkingHours(date) || isHoliday(date);
}

module.exports.getCheckinPrice = function (date, level, city) {
  if (level === BASIC_PACK && isSpecialDate(date)) {
    return Promise.resolve(SPECIAL_CHECKIN_PRICES[city]);
  }

  return Promise.resolve(0);
};

module.exports.getCheckoutPrice = function (date, level, city) {
  if (level !== PRIVILEGE_PACK && isSpecialDate(date)) {
    return Promise.resolve(SPECIAL_CHECKIN_PRICES[city]);
  }

  return Promise.resolve(0);
};

/***/ }),
/* 116 */
/***/ (function(module, exports) {

module.exports = [{"date":"2017-01-01 00:00:00","start":"2016-12-31T23:00:00.000Z","end":"2017-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2017-04-17 00:00:00","start":"2017-04-16T22:00:00.000Z","end":"2017-04-17T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2017-05-01 00:00:00","start":"2017-04-30T22:00:00.000Z","end":"2017-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2017-05-08 00:00:00","start":"2017-05-07T22:00:00.000Z","end":"2017-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2017-05-25 00:00:00","start":"2017-05-24T22:00:00.000Z","end":"2017-05-25T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2017-06-04 00:00:00","start":"2017-06-03T22:00:00.000Z","end":"2017-06-04T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2017-06-05 00:00:00","start":"2017-06-04T22:00:00.000Z","end":"2017-06-05T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2017-07-14 00:00:00","start":"2017-07-13T22:00:00.000Z","end":"2017-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2017-08-15 00:00:00","start":"2017-08-14T22:00:00.000Z","end":"2017-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2017-11-01 00:00:00","start":"2017-10-31T23:00:00.000Z","end":"2017-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2017-11-11 00:00:00","start":"2017-11-10T23:00:00.000Z","end":"2017-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2017-12-25 00:00:00","start":"2017-12-24T23:00:00.000Z","end":"2017-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2018-01-01 00:00:00","start":"2017-12-31T23:00:00.000Z","end":"2018-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2018-04-02 00:00:00","start":"2018-04-01T22:00:00.000Z","end":"2018-04-02T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2018-05-01 00:00:00","start":"2018-04-30T22:00:00.000Z","end":"2018-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2018-05-08 00:00:00","start":"2018-05-07T22:00:00.000Z","end":"2018-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2018-05-10 00:00:00","start":"2018-05-09T22:00:00.000Z","end":"2018-05-10T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2018-05-20 00:00:00","start":"2018-05-19T22:00:00.000Z","end":"2018-05-20T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2018-05-21 00:00:00","start":"2018-05-20T22:00:00.000Z","end":"2018-05-21T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2018-07-14 00:00:00","start":"2018-07-13T22:00:00.000Z","end":"2018-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2018-08-15 00:00:00","start":"2018-08-14T22:00:00.000Z","end":"2018-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2018-11-01 00:00:00","start":"2018-10-31T23:00:00.000Z","end":"2018-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2018-11-11 00:00:00","start":"2018-11-10T23:00:00.000Z","end":"2018-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2018-12-25 00:00:00","start":"2018-12-24T23:00:00.000Z","end":"2018-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2019-01-01 00:00:00","start":"2018-12-31T23:00:00.000Z","end":"2019-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2019-04-22 00:00:00","start":"2019-04-21T22:00:00.000Z","end":"2019-04-22T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2019-05-01 00:00:00","start":"2019-04-30T22:00:00.000Z","end":"2019-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2019-05-08 00:00:00","start":"2019-05-07T22:00:00.000Z","end":"2019-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2019-05-30 00:00:00","start":"2019-05-29T22:00:00.000Z","end":"2019-05-30T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2019-06-09 00:00:00","start":"2019-06-08T22:00:00.000Z","end":"2019-06-09T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2019-06-10 00:00:00","start":"2019-06-09T22:00:00.000Z","end":"2019-06-10T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2019-07-14 00:00:00","start":"2019-07-13T22:00:00.000Z","end":"2019-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2019-08-15 00:00:00","start":"2019-08-14T22:00:00.000Z","end":"2019-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2019-11-01 00:00:00","start":"2019-10-31T23:00:00.000Z","end":"2019-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2019-11-11 00:00:00","start":"2019-11-10T23:00:00.000Z","end":"2019-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2019-12-25 00:00:00","start":"2019-12-24T23:00:00.000Z","end":"2019-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2020-01-01 00:00:00","start":"2019-12-31T23:00:00.000Z","end":"2020-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2020-04-13 00:00:00","start":"2020-04-12T22:00:00.000Z","end":"2020-04-13T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2020-05-01 00:00:00","start":"2020-04-30T22:00:00.000Z","end":"2020-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2020-05-08 00:00:00","start":"2020-05-07T22:00:00.000Z","end":"2020-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2020-05-21 00:00:00","start":"2020-05-20T22:00:00.000Z","end":"2020-05-21T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2020-05-31 00:00:00","start":"2020-05-30T22:00:00.000Z","end":"2020-05-31T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2020-06-01 00:00:00","start":"2020-05-31T22:00:00.000Z","end":"2020-06-01T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2020-07-14 00:00:00","start":"2020-07-13T22:00:00.000Z","end":"2020-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2020-08-15 00:00:00","start":"2020-08-14T22:00:00.000Z","end":"2020-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2020-11-01 00:00:00","start":"2020-10-31T23:00:00.000Z","end":"2020-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2020-11-11 00:00:00","start":"2020-11-10T23:00:00.000Z","end":"2020-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2020-12-25 00:00:00","start":"2020-12-24T23:00:00.000Z","end":"2020-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2021-01-01 00:00:00","start":"2020-12-31T23:00:00.000Z","end":"2021-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2021-04-05 00:00:00","start":"2021-04-04T22:00:00.000Z","end":"2021-04-05T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2021-05-01 00:00:00","start":"2021-04-30T22:00:00.000Z","end":"2021-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2021-05-08 00:00:00","start":"2021-05-07T22:00:00.000Z","end":"2021-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2021-05-13 00:00:00","start":"2021-05-12T22:00:00.000Z","end":"2021-05-13T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2021-05-23 00:00:00","start":"2021-05-22T22:00:00.000Z","end":"2021-05-23T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2021-05-24 00:00:00","start":"2021-05-23T22:00:00.000Z","end":"2021-05-24T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2021-07-14 00:00:00","start":"2021-07-13T22:00:00.000Z","end":"2021-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2021-08-15 00:00:00","start":"2021-08-14T22:00:00.000Z","end":"2021-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2021-11-01 00:00:00","start":"2021-10-31T23:00:00.000Z","end":"2021-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2021-11-11 00:00:00","start":"2021-11-10T23:00:00.000Z","end":"2021-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2021-12-25 00:00:00","start":"2021-12-24T23:00:00.000Z","end":"2021-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2022-01-01 00:00:00","start":"2021-12-31T23:00:00.000Z","end":"2022-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2022-04-18 00:00:00","start":"2022-04-17T22:00:00.000Z","end":"2022-04-18T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2022-05-01 00:00:00","start":"2022-04-30T22:00:00.000Z","end":"2022-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2022-05-08 00:00:00","start":"2022-05-07T22:00:00.000Z","end":"2022-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2022-05-26 00:00:00","start":"2022-05-25T22:00:00.000Z","end":"2022-05-26T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2022-06-05 00:00:00","start":"2022-06-04T22:00:00.000Z","end":"2022-06-05T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2022-06-06 00:00:00","start":"2022-06-05T22:00:00.000Z","end":"2022-06-06T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2022-07-14 00:00:00","start":"2022-07-13T22:00:00.000Z","end":"2022-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2022-08-15 00:00:00","start":"2022-08-14T22:00:00.000Z","end":"2022-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2022-11-01 00:00:00","start":"2022-10-31T23:00:00.000Z","end":"2022-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2022-11-11 00:00:00","start":"2022-11-10T23:00:00.000Z","end":"2022-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2022-12-25 00:00:00","start":"2022-12-24T23:00:00.000Z","end":"2022-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2023-01-01 00:00:00","start":"2022-12-31T23:00:00.000Z","end":"2023-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2023-04-10 00:00:00","start":"2023-04-09T22:00:00.000Z","end":"2023-04-10T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2023-05-01 00:00:00","start":"2023-04-30T22:00:00.000Z","end":"2023-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2023-05-08 00:00:00","start":"2023-05-07T22:00:00.000Z","end":"2023-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2023-05-18 00:00:00","start":"2023-05-17T22:00:00.000Z","end":"2023-05-18T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2023-05-28 00:00:00","start":"2023-05-27T22:00:00.000Z","end":"2023-05-28T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2023-05-29 00:00:00","start":"2023-05-28T22:00:00.000Z","end":"2023-05-29T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2023-07-14 00:00:00","start":"2023-07-13T22:00:00.000Z","end":"2023-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2023-08-15 00:00:00","start":"2023-08-14T22:00:00.000Z","end":"2023-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2023-11-01 00:00:00","start":"2023-10-31T23:00:00.000Z","end":"2023-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2023-11-11 00:00:00","start":"2023-11-10T23:00:00.000Z","end":"2023-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2023-12-25 00:00:00","start":"2023-12-24T23:00:00.000Z","end":"2023-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2024-01-01 00:00:00","start":"2023-12-31T23:00:00.000Z","end":"2024-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2024-04-01 00:00:00","start":"2024-03-31T22:00:00.000Z","end":"2024-04-01T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2024-05-01 00:00:00","start":"2024-04-30T22:00:00.000Z","end":"2024-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2024-05-08 00:00:00","start":"2024-05-07T22:00:00.000Z","end":"2024-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2024-05-09 00:00:00","start":"2024-05-08T22:00:00.000Z","end":"2024-05-09T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2024-05-19 00:00:00","start":"2024-05-18T22:00:00.000Z","end":"2024-05-19T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2024-05-20 00:00:00","start":"2024-05-19T22:00:00.000Z","end":"2024-05-20T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2024-07-14 00:00:00","start":"2024-07-13T22:00:00.000Z","end":"2024-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2024-08-15 00:00:00","start":"2024-08-14T22:00:00.000Z","end":"2024-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2024-11-01 00:00:00","start":"2024-10-31T23:00:00.000Z","end":"2024-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2024-11-11 00:00:00","start":"2024-11-10T23:00:00.000Z","end":"2024-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2024-12-25 00:00:00","start":"2024-12-24T23:00:00.000Z","end":"2024-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2025-01-01 00:00:00","start":"2024-12-31T23:00:00.000Z","end":"2025-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2025-04-21 00:00:00","start":"2025-04-20T22:00:00.000Z","end":"2025-04-21T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2025-05-01 00:00:00","start":"2025-04-30T22:00:00.000Z","end":"2025-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2025-05-08 00:00:00","start":"2025-05-07T22:00:00.000Z","end":"2025-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2025-05-29 00:00:00","start":"2025-05-28T22:00:00.000Z","end":"2025-05-29T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2025-06-08 00:00:00","start":"2025-06-07T22:00:00.000Z","end":"2025-06-08T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2025-06-09 00:00:00","start":"2025-06-08T22:00:00.000Z","end":"2025-06-09T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2025-07-14 00:00:00","start":"2025-07-13T22:00:00.000Z","end":"2025-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2025-08-15 00:00:00","start":"2025-08-14T22:00:00.000Z","end":"2025-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2025-11-01 00:00:00","start":"2025-10-31T23:00:00.000Z","end":"2025-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2025-11-11 00:00:00","start":"2025-11-10T23:00:00.000Z","end":"2025-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2025-12-25 00:00:00","start":"2025-12-24T23:00:00.000Z","end":"2025-12-25T23:00:00.000Z","name":"Noël","type":"public"},{"date":"2026-01-01 00:00:00","start":"2025-12-31T23:00:00.000Z","end":"2026-01-01T23:00:00.000Z","name":"Nouvel An","type":"public"},{"date":"2026-04-06 00:00:00","start":"2026-04-05T22:00:00.000Z","end":"2026-04-06T22:00:00.000Z","name":"Lundi de Pâques","type":"public"},{"date":"2026-05-01 00:00:00","start":"2026-04-30T22:00:00.000Z","end":"2026-05-01T22:00:00.000Z","name":"Fête du travail","type":"public"},{"date":"2026-05-08 00:00:00","start":"2026-05-07T22:00:00.000Z","end":"2026-05-08T22:00:00.000Z","name":"Fête de la Victoire 1945","type":"public"},{"date":"2026-05-14 00:00:00","start":"2026-05-13T22:00:00.000Z","end":"2026-05-14T22:00:00.000Z","name":"Ascension","type":"public"},{"date":"2026-05-24 00:00:00","start":"2026-05-23T22:00:00.000Z","end":"2026-05-24T22:00:00.000Z","name":"Pentecôte","type":"public"},{"date":"2026-05-25 00:00:00","start":"2026-05-24T22:00:00.000Z","end":"2026-05-25T22:00:00.000Z","name":"Lundi de Pentecôte","type":"public"},{"date":"2026-07-14 00:00:00","start":"2026-07-13T22:00:00.000Z","end":"2026-07-14T22:00:00.000Z","name":"Fête Nationale de la France","type":"public"},{"date":"2026-08-15 00:00:00","start":"2026-08-14T22:00:00.000Z","end":"2026-08-15T22:00:00.000Z","name":"Assomption","type":"public"},{"date":"2026-11-01 00:00:00","start":"2026-10-31T23:00:00.000Z","end":"2026-11-01T23:00:00.000Z","name":"Toussaint","type":"public"},{"date":"2026-11-11 00:00:00","start":"2026-11-10T23:00:00.000Z","end":"2026-11-11T23:00:00.000Z","name":"Armistice 1918","type":"public"},{"date":"2026-12-25 00:00:00","start":"2026-12-24T23:00:00.000Z","end":"2026-12-25T23:00:00.000Z","name":"Noël","type":"public"}]

/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const { PACK_PRICES } = __webpack_require__(0);

module.exports = function (city, level) {
  // make this method artificially asynchronous, as it is likely to read from
  // the DB in the future.
  return Promise.resolve(PACK_PRICES[city][level]);
};

/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const D = __webpack_require__(4);
const Promise = __webpack_require__(1);
const { RENT_COEFS } = __webpack_require__(0);

module.exports = function (date) {
  // make this method artificially asynchronous, as it is likely to read from
  // the DB in the future.
  return Promise.resolve(RENT_COEFS[D.format(date, 'MM-DD')]);
};

/***/ }),
/* 119 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const roundBy100 = __webpack_require__(57);

const Utils = { roundBy100 };

// We want room prices to be rounded down to psychological prices:
// prices between X98 and (X+1)10 are rounded to 98
// and this should also be true when servces fees are added
module.exports = function (basePrice, periodCoef, serviceFees) {
    // The logic is clearer if we convert all prices to euros
    let euroPrice = Math.round(basePrice * periodCoef / 100);
    const euroFees = serviceFees / 100;
    const priceRemainder = euroPrice % 100;
    const totalPriceRemainder = (euroPrice + euroFees) % 100;

    if (priceRemainder > 98 || priceRemainder < 10) {
        euroPrice = Utils.roundBy100(euroPrice) - 2;
    } else if (totalPriceRemainder > 98 || totalPriceRemainder < 10) {
        euroPrice = Utils.roundBy100(euroPrice) - 2 - euroFees;
    }

    return euroPrice * 100;
};

/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const { SERVICE_FEES } = __webpack_require__(0);

module.exports = function (roomCount) {
  // make this method artificially asynchronous, as it is likely to read from
  // the DB in the future.
  return Promise.resolve(roomCount != null && roomCount in SERVICE_FEES ? SERVICE_FEES[roomCount] : SERVICE_FEES.default);
};

/***/ }),
/* 121 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const D = __webpack_require__(4);
const {
  CHECKIN_DURATION,
  CHECKOUT_DURATION
} = __webpack_require__(0);

module.exports.getCheckinEndDate = function (startDate) {
  return Promise.resolve(D.addMinutes(startDate, CHECKIN_DURATION));
};

module.exports.getCheckoutEndDate = function (startDate) {
  return Promise.resolve(D.addMinutes(startDate, CHECKOUT_DURATION));
};

/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const D = __webpack_require__(4);
const { LATE_NOTICE_FEES } = __webpack_require__(0);

module.exports = function (type, date) {
  const differenceDays = D.differenceInDays(date, new Date());

  // there are no late-notice fees for a checkin
  if (type === 'checkin') {
    return Promise.resolve(0);
  }
  if (differenceDays <= 9) {
    return Promise.resolve(LATE_NOTICE_FEES['0-9days']);
  }
  if (differenceDays >= 10 && differenceDays <= 19) {
    return Promise.resolve(LATE_NOTICE_FEES['10-19days']);
  }
  if (differenceDays >= 20 && differenceDays <= 29) {
    return Promise.resolve(LATE_NOTICE_FEES['20-29days']);
  }

  return Promise.resolve(0);
};

/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const D = __webpack_require__(4);
const { LEASE_DURATION } = __webpack_require__(0);

module.exports = function (startDate) {
  return D.addMonths(D.subDays(startDate, 1), LEASE_DURATION);
};

/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const { ROOM_SWITCH_PRICES } = __webpack_require__(0);

module.exports = function (switchCount, level) {
  if (switchCount > 0) {
    return Promise.resolve(ROOM_SWITCH_PRICES.basic);
  }

  return Promise.resolve(ROOM_SWITCH_PRICES[level]);
};

/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const rValidPhoneNumber = /^(\+|0{2})\d{5,}$/;

module.exports = function (phoneNumber) {
  return rValidPhoneNumber.test(phoneNumber);
};

module.exports.rValidPhoneNumber = rValidPhoneNumber;

/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const D = __webpack_require__(4);

module.exports = function (sDate) {
  return D.parse(sDate.replace(/ ([Z+-])/, '$1'));
};

/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (promise) {
  return promise.thenReturn(true).tapCatch(console.error);
};

/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);

module.exports = function (houseMates, value) {
  const data = JSON.parse(value);
  const { day, month, year } = data.checkinDate;
  const common = {
    FIRSTNAME: data.fullName.first,
    CITY: houseMates[0].Rentings[0].Room.Apartment.addressCity,
    ARRIVAL: `${day}/${month}/${year}`,
    EMAIL: data.email
  };
  const fr = {
    COUNTRY: data.nationalityFr,
    WORK: data.isStudent ? 'étudier' : 'travailler'
  };
  const en = {
    COUNTRY: data.nationalityEn,
    WORK: data.isStudent ? 'study' : 'work'
  };
  const emailFr = [];
  const emailEn = [];

  houseMates.filter(houseMate => {
    return houseMate.preferredLanguage === 'fr';
  }).map(houseMate => {
    return emailFr.push(houseMate.email);
  });

  houseMates.filter(houseMate => {
    return houseMate.preferredLanguage === 'en';
  }).map(houseMate => {
    return emailEn.push(houseMate.email);
  });

  return Promise.all([Object.assign({}, common, fr), Object.assign({}, common, en), emailFr, emailEn]);
};

/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (models, Apartment) {
  Apartment.hook('beforeCreate', apartment => {
    if (apartment.latLng != null) {
      return apartment;
    }

    return apartment.calculateLatLng();
  });

  Apartment.hook('beforeUpdate', apartment => {
    // if no address field has been updated…
    if (Object.keys(apartment.changed).every(name => {
      return !/^address/.test(name);
    })) {
      return apartment;
    }

    // We need to reload the existing apartment to make sure we have all address fields
    return Apartment.findById(apartment.id).then(previousApartment => {
      return apartment.calculateLatLng(Object.assign({}, previousApartment.dataValues, apartment.dataValues));
    });
  });

  Apartment.hook('beforeDelete', apartment => {
    return models.Client.scope('currentApartment').findAll({
      where: {
        '$Rentings->Room.ApartmentId$': apartment.id,
        '$Rentings.bookingDate$': { $lte: new Date() }
      }
    }).then(clients => {
      if (clients.length > 0) {
        throw new Error('Cannot delete Apartment: it\'s not empty.');
      }
      return true;
    });
  });
};

/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const mapKeys = __webpack_require__(59);
const capitalize = __webpack_require__(10);
const D = __webpack_require__(4);
const Payline = __webpack_require__(75);
const Country = __webpack_require__(198);
const GoogleTranslate = __webpack_require__(199);
const Ninja = __webpack_require__(41);
const payline = __webpack_require__(27);
const Utils = __webpack_require__(3);
const {
  TRASH_SCOPES,
  LATE_FEES,
  UNCASHED_DEPOSIT_FEE,
  DATETIME_FORMAT
} = __webpack_require__(0);
const config = __webpack_require__(2);
const collection = __webpack_require__(204);
const routes = __webpack_require__(216);
const hooks = __webpack_require__(235);

const _ = { mapKeys, capitalize };
const Translate = Promise.promisify(GoogleTranslate(config.GOOGLE_TRANSLATE_API_KEY).translate);

module.exports = (sequelize, DataTypes) => {
  const Client = sequelize.define('Client', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    firstName: {
      type: DataTypes.STRING,
      required: true,
      allowNull: false
    },
    lastName: {
      type: DataTypes.STRING,
      required: true,
      allowNull: false,
      set(val) {
        this.setDataValue('lastName', val.split(' ').map(_.capitalize).join(' '));
      }
    },
    email: {
      type: DataTypes.STRING,
      required: true,
      unique: true,
      allowNull: false
    },
    secondaryEmail: DataTypes.STRING,
    phoneNumber: {
      type: DataTypes.STRING,
      required: true,
      validate: { is: Utils.isValidPhoneNumber.rValidPhoneNumber }
    },
    preferredLanguage: {
      type: DataTypes.ENUM('fr', 'en'),
      defaultValue: 'en'
    },
    ninjaId: DataTypes.INTEGER,
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      required: true,
      defaultValue: 'active',
      allowNull: false
    }
  }, {
    paranoid: true,
    scopes: TRASH_SCOPES
  });
  const { models } = sequelize;

  /*
   * Associations
   */
  Client.associate = () => {
    const { fn, col } = sequelize;

    Client.hasMany(models.Renting);
    Client.hasMany(models.Order);
    Client.hasMany(models.Metadata, {
      foreignKey: 'MetadatableId',
      constraints: false,
      scope: { metadatable: 'Client' }
    });

    Client.addScope('rentOrders', {
      include: [{
        model: models.Order,
        include: [{
          model: models.OrderItem,
          where: { ProductId: 'rent' }
        }]
      }]
    });
    // TODO: one of the following two scopes is useless. Get rid of it
    Client.addScope('ordersFor', (date = new Date()) => {
      return {
        where: {
          '$Order.type$': 'debit',
          '$Order.dueDate$': { $gte: D.startOfMonth(date), $lte: D.endOfMonth(date) }
        }
      };
    });
    Client.addScope('rentOrdersFor', (date = new Date()) => {
      return {
        include: [{
          model: models.Order,
          required: false,
          where: {
            type: 'debit',
            dueDate: { $gte: D.startOfMonth(date), $lte: D.endOfMonth(date) }
          },
          include: [{
            model: models.OrderItem,
            where: { ProductId: 'rent' }
          }]
        }]
      };
    });
    Client.addScope('roomSwitchCount', {
      attributes: { include: [[fn('count', col('Orders.id')), 'roomSwitchCount']] },
      include: [{
        model: models.Order,
        attributes: ['id'],
        include: [{
          model: models.OrderItem,
          where: { ProductId: 'room-switch' },
          attributes: []
        }]
      }],
      group: ['Client.id']
    });
    Client.addScope('uncashedDepositCount', {
      attributes: { include: [[fn('count', col('Rentings.id')), 'uncashedDepositCount']] },
      include: [{
        model: models.Renting,
        include: [{
          model: models.Term,
          where: {
            taxonomy: 'deposit-option',
            name: 'do-not-cash'
          }
        }]
      }],
      group: ['Client.id']
    });

    Client.addScope('currentApartment', function (date = new Date()) {
      return {
        where: { $or: [{ '$Rentings.Events.id$': null }, { '$Rentings.Events.startDate$': { $gte: D.format(date) } }] },
        include: [{
          model: models.Renting,
          required: false,
          where: {
            status: 'active'
          },
          include: [{
            model: models.Event,
            attributes: ['id', 'startDate'],
            required: false,
            include: [{
              model: models.Term,
              attributes: [],
              where: {
                taxonomy: 'event-category',
                name: 'checkout'
              }
            }]
          }, {
            model: models.Room,
            attributes: ['id', 'ApartmentId'],
            include: [{
              model: models.Apartment,
              attributes: ['addressCity']
            }]
          }]
        }]
      };
    });

    Client.addScope('latestClientRenting', {
      attributes: { include: [[fn('max', col('Rentings.bookingDate')), 'latestBookingDate']] },
      include: [{
        model: models.Renting,
        include: [{
          model: models.Room,
          include: [{
            model: models.Apartment,
            attributes: ['addressCity']
          }]
        }]
      }],
      group: ['Client.id']
    });

    Client.addScope('paymentDelay', {
      include: [{
        required: false,
        model: models.Metadata,
        where: { name: 'payment-delay' }
      }]
    });
  };

  // This was the reliable method used by generateInvoice
  // TODO: get rid of it once we're certain that script still works
  // Client.prototype.getRentingOrdersFor = function(date = new Date()) {
  //   return this.getOrders({
  //       where: {
  //         type: 'debit',
  //         dueDate: { $gte: D.startOfMonth(date), $lte: D.endOfMonth(date) },
  //       },
  //       include: [{
  //         model: models.OrderItem,
  //         where: {
  //           RentingId: { $not: null },
  //           ProductId: 'rent',
  //         },
  //       }],
  //     });
  // };

  // TODO: this can probably be improved to use a Client scope
  Client.prototype.getRentingsFor = function (date = new Date()) {
    const startOfMonth = D.format(D.startOfMonth(date), DATETIME_FORMAT);

    return models.Renting.scope('room+apartment', 'checkoutDate').findAll({
      where: {
        status: 'active',
        ClientId: this.id,
        bookingDate: { $lte: D.endOfMonth(date) },
        $and: sequelize.literal(
        // /!\ startOfMonth must be formatted using DATETIME_FORMAT
        `(Events.id IS NULL OR Events.startDate >= '${startOfMonth}')`)
      }
    });
  };

  Client.prototype.findOrCreateRentOrder = function (rentings, date = new Date(), number) {
    return models.Order.findItemOrCreate({
      where: { ProductId: 'rent' },
      include: [{
        model: models.Order,
        where: {
          ClientId: this.id,
          dueDate: this.Metadata.length ? D.addDays(D.startOfMonth(date), this.Metadata[0].value) : D.startOfMonth(date)
        }
      }],
      defaults: {
        label: `${D.format(date, 'MMMM')} Invoice`,
        type: 'debit',
        ClientId: this.id,
        dueDate: this.Metadata.length ? D.addDays(D.startOfMonth(date), this.Metadata[0].value) : D.startOfMonth(date),
        OrderItems: rentings.reduce((all, renting) => {
          return all.concat(renting.toOrderItems({ date }));
        }, []).concat(this.get('uncashedDepositCount') > 0 && {
          label: 'Option Liberté',
          unitPrice: UNCASHED_DEPOSIT_FEE,
          ProductId: 'uncashed-deposit'
        }).filter(Boolean),
        number
      }
    }).tap(([order]) => {
      return models.Renting.findOrphanOrderItems(rentings, order);
    });
  };

  Client.createRentOrders = function (clients, date = new Date()) {
    return Promise.mapSeries(clients, client => {
      return Promise.all([client, client.getRentingsFor(date)]);
    }).filter(([, rentings]) => {
      return rentings.length !== 0;
    }).map(([client, rentings]) => {
      return client.findOrCreateRentOrder(rentings, date);
    });
  };

  Client.prototype.ninjaSerialize = function () {
    return Promise.resolve({
      'name': `${this.firstName} ${this.lastName}`,
      'contact': {
        'first_name': this.firstName,
        'last_name': this.lastName,
        'email': this.email
      }
    });
  };

  Client.prototype.ninjaCreate = function () {
    return this.ninjaSerialize().then(ninjaClient => {
      return Ninja.client.createClient({
        'client': ninjaClient
      });
    }).then(response => {
      this.set('ninjaId', response.obj.data.id).save({ hooks: false });
      return response.obj.data;
    });
  };

  Client.prototype.ninjaUpdate = function () {
    return this.ninjaSerialize().then(ninjaClient => {
      return Ninja.client.updateClient({
        'client_id': this.ninjaId,
        'client': ninjaClient
      });
    }).then(response => {
      return response.obj.data;
    });
  };

  Client.prototype.ninjaUpsert = function () {
    if (this.ninjaId != null && this.ninjaId !== -1) {
      return this.ninjaUpdate();
    }

    return Ninja.client.listClients({
      'email': this.email,
      'per_page': 1
    }).then(response => {
      if (response.obj.data.length) {
        this.set('ninjaId', response.obj.data[0].id).save({ hooks: false });
        return this.ninjaUpdate();
      }

      return this.ninjaCreate();
    });
  };

  Client.paylineCredit = (clientId, values, idCredit) => {
    const { Order, OrderItem, Credit } = models;
    const card = {
      number: values.cardNumber,
      type: values.cardType,
      expirationDate: values.expirationMonth + values.expirationYear.slice(-2),
      cvx: values.cvv,
      holder: values.cardHolder
    };

    return payline.doCredit(idCredit, card, values.amount, Payline.CURRENCIES.EUR).then(result => {
      return Order.create({
        id: idCredit,
        type: 'credit',
        label: values.orderLabel,
        ClientId: clientId,
        OrderItems: [{
          label: values.reason,
          unitPrice: values.amount * -1
        }],
        Credits: [{
          amount: values.amount,
          reason: values.orderLabel,
          paylineId: result.transactionId
        }]
      }, {
        include: [OrderItem, Credit]
      });
    });
  };

  Client.prototype.findUnpaidOrders = function () {
    const { Order } = models;

    return Order.scope('rentOrders').findAll({
      where: {
        ClientId: this.id,
        dueDate: { $lt: new Date() }
      }
    }).filter(order => {
      return order.getCalculatedProps().then(({ balance }) => {
        return balance < 0;
      });
    });
  };

  Client.prototype.applyLateFees = function (now = new Date()) {
    return this.findUnpaidOrders().map(order => {
      const lateFees = D.differenceInDays(now, order.dueDate);

      return order.getOrderItems({
        where: { ProductId: 'late-fees' }
      }).then(orderItem => {
        return models.OrderItem.upsert({
          id: orderItem[0] && orderItem[0].id,
          OrderId: order.id,
          ProductId: 'late-fees',
          quantity: lateFees,
          unitPrice: LATE_FEES,
          label: 'Late fees'
        });
      }).thenReturn(order);
    });
  };

  // the last argument is only used for testing purpose
  Client.getIdentity = function (client, Metadata = models.Metadata, now = new Date()) {
    return Metadata.findOne({
      where: {
        MetadatableId: client.id,
        name: 'clientIdentity'
      }
    }).then(metadata => {
      if (metadata == null) {
        return null;
      }

      const identity = JSON.parse(metadata.value.replace(/\r?\n|\r/g, ''));
      const { day, month, year } = identity.birthDate;

      identity.age = D.differenceInYears(now, `${year}-${month}-${day} Z`);

      return identity;
    });
  };

  Client.getIdentityRecordUrl = function (identity) {
    const passport = identity && identity.passport.match(/uploads\/cheznestor\/(.+?)\/(.+?)\//);

    return passport && `
      https://eu.jotform.com/server.php?action=getSubmissionPDF\
      &formID=${passport[1]}&sid=${passport[2]}
    `.replace(/\s+/g, '');
  };

  Client.getDescriptionEn = function (client) {
    return client && client.identity && Utils.toSingleLine(`
      ${client.firstName},
      ${client.identity.age} years old ${client.identity.nationalityEn}
      ${client.identity.isStudent ? 'student' : 'young worker'}
    `);
  };

  Client.getDescriptionFr = function (client) {
    return client && client.identity && Utils.toSingleLine(`
      ${client.firstName},
      ${client.identity.isStudent ? 'étudiant(e)' : 'jeune actif(ve)'}
      ${client.identity.nationalityFr} de ${client.identity.age} ans
    `);
  };

  Client.normalizeIdentityRecord = function (raw) {
    const values = _.mapKeys(raw, (value, key) => {
      return key.replace(/(q[\d]*_)/g, '');
    });
    const phoneNumber = values.phoneNumber.phone.replace(/^0/, '');

    values.phoneNumber = `${values.phoneNumber.area}${phoneNumber}`;
    values.countryEn = values.nationality;
    values.nationalityEn = Country.demonym(values.countryEn, 'name');
    values.countryFr = Country.translations(values.countryEn, 'name').fr;
    values.birthCountryEn = values.birthPlace.last;
    values.isStudent = /^(Student|Intern)$/.test(values.frenchStatus);

    return Promise.all([Translate(values.birthCountryEn, 'en', 'fr'), Translate(values.nationalityEn, 'en', 'fr')]).then(([{ translatedText: birthCountryFr }, { translatedText: nationalityFr }]) => {
      return Object.assign(values, { birthCountryFr, nationalityFr });
    });
  };

  Client.collection = collection;
  Client.routes = routes;
  Client.hooks = hooks;

  return Client;
};

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

var isFunction = __webpack_require__(51),
    isMasked = __webpack_require__(132),
    isObject = __webpack_require__(11),
    toSource = __webpack_require__(62);

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Used for built-in method references. */
var funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

module.exports = baseIsNative;


/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

var coreJsData = __webpack_require__(133);

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

module.exports = isMasked;


/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(7);

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

module.exports = coreJsData;


/***/ }),
/* 134 */
/***/ (function(module, exports) {

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

module.exports = getValue;


/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

var createBaseFor = __webpack_require__(136);

/**
 * The base implementation of `baseForOwn` which iterates over `object`
 * properties returned by `keysFunc` and invokes `iteratee` for each property.
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @returns {Object} Returns `object`.
 */
var baseFor = createBaseFor();

module.exports = baseFor;


/***/ }),
/* 136 */
/***/ (function(module, exports) {

/**
 * Creates a base function for methods like `_.forIn` and `_.forOwn`.
 *
 * @private
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new base function.
 */
function createBaseFor(fromRight) {
  return function(object, iteratee, keysFunc) {
    var index = -1,
        iterable = Object(object),
        props = keysFunc(object),
        length = props.length;

    while (length--) {
      var key = props[fromRight ? length : ++index];
      if (iteratee(iterable[key], key, iterable) === false) {
        break;
      }
    }
    return object;
  };
}

module.exports = createBaseFor;


/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsMatch = __webpack_require__(138),
    getMatchData = __webpack_require__(179),
    matchesStrictComparable = __webpack_require__(71);

/**
 * The base implementation of `_.matches` which doesn't clone `source`.
 *
 * @private
 * @param {Object} source The object of property values to match.
 * @returns {Function} Returns the new spec function.
 */
function baseMatches(source) {
  var matchData = getMatchData(source);
  if (matchData.length == 1 && matchData[0][2]) {
    return matchesStrictComparable(matchData[0][0], matchData[0][1]);
  }
  return function(object) {
    return object === source || baseIsMatch(object, source, matchData);
  };
}

module.exports = baseMatches;


/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

var Stack = __webpack_require__(64),
    baseIsEqual = __webpack_require__(65);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/**
 * The base implementation of `_.isMatch` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The object to inspect.
 * @param {Object} source The object of property values to match.
 * @param {Array} matchData The property names, values, and compare flags to match.
 * @param {Function} [customizer] The function to customize comparisons.
 * @returns {boolean} Returns `true` if `object` is a match, else `false`.
 */
function baseIsMatch(object, source, matchData, customizer) {
  var index = matchData.length,
      length = index,
      noCustomizer = !customizer;

  if (object == null) {
    return !length;
  }
  object = Object(object);
  while (index--) {
    var data = matchData[index];
    if ((noCustomizer && data[2])
          ? data[1] !== object[data[0]]
          : !(data[0] in object)
        ) {
      return false;
    }
  }
  while (++index < length) {
    data = matchData[index];
    var key = data[0],
        objValue = object[key],
        srcValue = data[1];

    if (noCustomizer && data[2]) {
      if (objValue === undefined && !(key in object)) {
        return false;
      }
    } else {
      var stack = new Stack;
      if (customizer) {
        var result = customizer(objValue, srcValue, key, object, source, stack);
      }
      if (!(result === undefined
            ? baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG, customizer, stack)
            : result
          )) {
        return false;
      }
    }
  }
  return true;
}

module.exports = baseIsMatch;


/***/ }),
/* 139 */
/***/ (function(module, exports) {

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
  this.size = 0;
}

module.exports = listCacheClear;


/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(22);

/** Used for built-in method references. */
var arrayProto = Array.prototype;

/** Built-in value references. */
var splice = arrayProto.splice;

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  --this.size;
  return true;
}

module.exports = listCacheDelete;


/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(22);

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

module.exports = listCacheGet;


/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(22);

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

module.exports = listCacheHas;


/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(22);

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    ++this.size;
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

module.exports = listCacheSet;


/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

var ListCache = __webpack_require__(21);

/**
 * Removes all key-value entries from the stack.
 *
 * @private
 * @name clear
 * @memberOf Stack
 */
function stackClear() {
  this.__data__ = new ListCache;
  this.size = 0;
}

module.exports = stackClear;


/***/ }),
/* 145 */
/***/ (function(module, exports) {

/**
 * Removes `key` and its value from the stack.
 *
 * @private
 * @name delete
 * @memberOf Stack
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function stackDelete(key) {
  var data = this.__data__,
      result = data['delete'](key);

  this.size = data.size;
  return result;
}

module.exports = stackDelete;


/***/ }),
/* 146 */
/***/ (function(module, exports) {

/**
 * Gets the stack value for `key`.
 *
 * @private
 * @name get
 * @memberOf Stack
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function stackGet(key) {
  return this.__data__.get(key);
}

module.exports = stackGet;


/***/ }),
/* 147 */
/***/ (function(module, exports) {

/**
 * Checks if a stack value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Stack
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function stackHas(key) {
  return this.__data__.has(key);
}

module.exports = stackHas;


/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

var ListCache = __webpack_require__(21),
    Map = __webpack_require__(35),
    MapCache = __webpack_require__(36);

/** Used as the size to enable large array optimizations. */
var LARGE_ARRAY_SIZE = 200;

/**
 * Sets the stack `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Stack
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the stack cache instance.
 */
function stackSet(key, value) {
  var data = this.__data__;
  if (data instanceof ListCache) {
    var pairs = data.__data__;
    if (!Map || (pairs.length < LARGE_ARRAY_SIZE - 1)) {
      pairs.push([key, value]);
      this.size = ++data.size;
      return this;
    }
    data = this.__data__ = new MapCache(pairs);
  }
  data.set(key, value);
  this.size = data.size;
  return this;
}

module.exports = stackSet;


/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

var Hash = __webpack_require__(150),
    ListCache = __webpack_require__(21),
    Map = __webpack_require__(35);

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.size = 0;
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

module.exports = mapCacheClear;


/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

var hashClear = __webpack_require__(151),
    hashDelete = __webpack_require__(152),
    hashGet = __webpack_require__(153),
    hashHas = __webpack_require__(154),
    hashSet = __webpack_require__(155);

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

module.exports = Hash;


/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(23);

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
  this.size = 0;
}

module.exports = hashClear;


/***/ }),
/* 152 */
/***/ (function(module, exports) {

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  var result = this.has(key) && delete this.__data__[key];
  this.size -= result ? 1 : 0;
  return result;
}

module.exports = hashDelete;


/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(23);

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : undefined;
}

module.exports = hashGet;


/***/ }),
/* 154 */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(23);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? (data[key] !== undefined) : hasOwnProperty.call(data, key);
}

module.exports = hashHas;


/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(23);

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  this.size += this.has(key) ? 0 : 1;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

module.exports = hashSet;


/***/ }),
/* 156 */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(24);

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  var result = getMapData(this, key)['delete'](key);
  this.size -= result ? 1 : 0;
  return result;
}

module.exports = mapCacheDelete;


/***/ }),
/* 157 */
/***/ (function(module, exports) {

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

module.exports = isKeyable;


/***/ }),
/* 158 */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(24);

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

module.exports = mapCacheGet;


/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(24);

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

module.exports = mapCacheHas;


/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(24);

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  var data = getMapData(this, key),
      size = data.size;

  data.set(key, value);
  this.size += data.size == size ? 0 : 1;
  return this;
}

module.exports = mapCacheSet;


/***/ }),
/* 161 */
/***/ (function(module, exports, __webpack_require__) {

var Stack = __webpack_require__(64),
    equalArrays = __webpack_require__(66),
    equalByTag = __webpack_require__(167),
    equalObjects = __webpack_require__(171),
    getTag = __webpack_require__(174),
    isArray = __webpack_require__(6),
    isBuffer = __webpack_require__(46),
    isTypedArray = __webpack_require__(48);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1;

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
    arrayTag = '[object Array]',
    objectTag = '[object Object]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * A specialized version of `baseIsEqual` for arrays and objects which performs
 * deep comparisons and tracks traversed objects enabling objects with circular
 * references to be compared.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} [stack] Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
  var objIsArr = isArray(object),
      othIsArr = isArray(other),
      objTag = objIsArr ? arrayTag : getTag(object),
      othTag = othIsArr ? arrayTag : getTag(other);

  objTag = objTag == argsTag ? objectTag : objTag;
  othTag = othTag == argsTag ? objectTag : othTag;

  var objIsObj = objTag == objectTag,
      othIsObj = othTag == objectTag,
      isSameTag = objTag == othTag;

  if (isSameTag && isBuffer(object)) {
    if (!isBuffer(other)) {
      return false;
    }
    objIsArr = true;
    objIsObj = false;
  }
  if (isSameTag && !objIsObj) {
    stack || (stack = new Stack);
    return (objIsArr || isTypedArray(object))
      ? equalArrays(object, other, bitmask, customizer, equalFunc, stack)
      : equalByTag(object, other, objTag, bitmask, customizer, equalFunc, stack);
  }
  if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
    var objIsWrapped = objIsObj && hasOwnProperty.call(object, '__wrapped__'),
        othIsWrapped = othIsObj && hasOwnProperty.call(other, '__wrapped__');

    if (objIsWrapped || othIsWrapped) {
      var objUnwrapped = objIsWrapped ? object.value() : object,
          othUnwrapped = othIsWrapped ? other.value() : other;

      stack || (stack = new Stack);
      return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
    }
  }
  if (!isSameTag) {
    return false;
  }
  stack || (stack = new Stack);
  return equalObjects(object, other, bitmask, customizer, equalFunc, stack);
}

module.exports = baseIsEqualDeep;


/***/ }),
/* 162 */
/***/ (function(module, exports, __webpack_require__) {

var MapCache = __webpack_require__(36),
    setCacheAdd = __webpack_require__(163),
    setCacheHas = __webpack_require__(164);

/**
 *
 * Creates an array cache object to store unique values.
 *
 * @private
 * @constructor
 * @param {Array} [values] The values to cache.
 */
function SetCache(values) {
  var index = -1,
      length = values == null ? 0 : values.length;

  this.__data__ = new MapCache;
  while (++index < length) {
    this.add(values[index]);
  }
}

// Add methods to `SetCache`.
SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
SetCache.prototype.has = setCacheHas;

module.exports = SetCache;


/***/ }),
/* 163 */
/***/ (function(module, exports) {

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/**
 * Adds `value` to the array cache.
 *
 * @private
 * @name add
 * @memberOf SetCache
 * @alias push
 * @param {*} value The value to cache.
 * @returns {Object} Returns the cache instance.
 */
function setCacheAdd(value) {
  this.__data__.set(value, HASH_UNDEFINED);
  return this;
}

module.exports = setCacheAdd;


/***/ }),
/* 164 */
/***/ (function(module, exports) {

/**
 * Checks if `value` is in the array cache.
 *
 * @private
 * @name has
 * @memberOf SetCache
 * @param {*} value The value to search for.
 * @returns {number} Returns `true` if `value` is found, else `false`.
 */
function setCacheHas(value) {
  return this.__data__.has(value);
}

module.exports = setCacheHas;


/***/ }),
/* 165 */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.some` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {boolean} Returns `true` if any element passes the predicate check,
 *  else `false`.
 */
function arraySome(array, predicate) {
  var index = -1,
      length = array == null ? 0 : array.length;

  while (++index < length) {
    if (predicate(array[index], index, array)) {
      return true;
    }
  }
  return false;
}

module.exports = arraySome;


/***/ }),
/* 166 */
/***/ (function(module, exports) {

/**
 * Checks if a `cache` value for `key` exists.
 *
 * @private
 * @param {Object} cache The cache to query.
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function cacheHas(cache, key) {
  return cache.has(key);
}

module.exports = cacheHas;


/***/ }),
/* 167 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(14),
    Uint8Array = __webpack_require__(168),
    eq = __webpack_require__(34),
    equalArrays = __webpack_require__(66),
    mapToArray = __webpack_require__(169),
    setToArray = __webpack_require__(170);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/** `Object#toString` result references. */
var boolTag = '[object Boolean]',
    dateTag = '[object Date]',
    errorTag = '[object Error]',
    mapTag = '[object Map]',
    numberTag = '[object Number]',
    regexpTag = '[object RegExp]',
    setTag = '[object Set]',
    stringTag = '[object String]',
    symbolTag = '[object Symbol]';

var arrayBufferTag = '[object ArrayBuffer]',
    dataViewTag = '[object DataView]';

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

/**
 * A specialized version of `baseIsEqualDeep` for comparing objects of
 * the same `toStringTag`.
 *
 * **Note:** This function only supports comparing values with tags of
 * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {string} tag The `toStringTag` of the objects to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
  switch (tag) {
    case dataViewTag:
      if ((object.byteLength != other.byteLength) ||
          (object.byteOffset != other.byteOffset)) {
        return false;
      }
      object = object.buffer;
      other = other.buffer;

    case arrayBufferTag:
      if ((object.byteLength != other.byteLength) ||
          !equalFunc(new Uint8Array(object), new Uint8Array(other))) {
        return false;
      }
      return true;

    case boolTag:
    case dateTag:
    case numberTag:
      // Coerce booleans to `1` or `0` and dates to milliseconds.
      // Invalid dates are coerced to `NaN`.
      return eq(+object, +other);

    case errorTag:
      return object.name == other.name && object.message == other.message;

    case regexpTag:
    case stringTag:
      // Coerce regexes to strings and treat strings, primitives and objects,
      // as equal. See http://www.ecma-international.org/ecma-262/7.0/#sec-regexp.prototype.tostring
      // for more details.
      return object == (other + '');

    case mapTag:
      var convert = mapToArray;

    case setTag:
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
      convert || (convert = setToArray);

      if (object.size != other.size && !isPartial) {
        return false;
      }
      // Assume cyclic values are equal.
      var stacked = stack.get(object);
      if (stacked) {
        return stacked == other;
      }
      bitmask |= COMPARE_UNORDERED_FLAG;

      // Recursively compare objects (susceptible to call stack limits).
      stack.set(object, other);
      var result = equalArrays(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
      stack['delete'](object);
      return result;

    case symbolTag:
      if (symbolValueOf) {
        return symbolValueOf.call(object) == symbolValueOf.call(other);
      }
  }
  return false;
}

module.exports = equalByTag;


/***/ }),
/* 168 */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(7);

/** Built-in value references. */
var Uint8Array = root.Uint8Array;

module.exports = Uint8Array;


/***/ }),
/* 169 */
/***/ (function(module, exports) {

/**
 * Converts `map` to its key-value pairs.
 *
 * @private
 * @param {Object} map The map to convert.
 * @returns {Array} Returns the key-value pairs.
 */
function mapToArray(map) {
  var index = -1,
      result = Array(map.size);

  map.forEach(function(value, key) {
    result[++index] = [key, value];
  });
  return result;
}

module.exports = mapToArray;


/***/ }),
/* 170 */
/***/ (function(module, exports) {

/**
 * Converts `set` to an array of its values.
 *
 * @private
 * @param {Object} set The set to convert.
 * @returns {Array} Returns the values.
 */
function setToArray(set) {
  var index = -1,
      result = Array(set.size);

  set.forEach(function(value) {
    result[++index] = value;
  });
  return result;
}

module.exports = setToArray;


/***/ }),
/* 171 */
/***/ (function(module, exports, __webpack_require__) {

var getAllKeys = __webpack_require__(172);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1;

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * A specialized version of `baseIsEqualDeep` for objects with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
      objProps = getAllKeys(object),
      objLength = objProps.length,
      othProps = getAllKeys(other),
      othLength = othProps.length;

  if (objLength != othLength && !isPartial) {
    return false;
  }
  var index = objLength;
  while (index--) {
    var key = objProps[index];
    if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
      return false;
    }
  }
  // Assume cyclic values are equal.
  var stacked = stack.get(object);
  if (stacked && stack.get(other)) {
    return stacked == other;
  }
  var result = true;
  stack.set(object, other);
  stack.set(other, object);

  var skipCtor = isPartial;
  while (++index < objLength) {
    key = objProps[index];
    var objValue = object[key],
        othValue = other[key];

    if (customizer) {
      var compared = isPartial
        ? customizer(othValue, objValue, key, other, object, stack)
        : customizer(objValue, othValue, key, object, other, stack);
    }
    // Recursively compare objects (susceptible to call stack limits).
    if (!(compared === undefined
          ? (objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack))
          : compared
        )) {
      result = false;
      break;
    }
    skipCtor || (skipCtor = key == 'constructor');
  }
  if (result && !skipCtor) {
    var objCtor = object.constructor,
        othCtor = other.constructor;

    // Non `Object` object instances with different constructors are not equal.
    if (objCtor != othCtor &&
        ('constructor' in object && 'constructor' in other) &&
        !(typeof objCtor == 'function' && objCtor instanceof objCtor &&
          typeof othCtor == 'function' && othCtor instanceof othCtor)) {
      result = false;
    }
  }
  stack['delete'](object);
  stack['delete'](other);
  return result;
}

module.exports = equalObjects;


/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetAllKeys = __webpack_require__(67),
    getSymbols = __webpack_require__(68),
    keys = __webpack_require__(12);

/**
 * Creates an array of own enumerable property names and symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names and symbols.
 */
function getAllKeys(object) {
  return baseGetAllKeys(object, keys, getSymbols);
}

module.exports = getAllKeys;


/***/ }),
/* 173 */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.filter` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {Array} Returns the new filtered array.
 */
function arrayFilter(array, predicate) {
  var index = -1,
      length = array == null ? 0 : array.length,
      resIndex = 0,
      result = [];

  while (++index < length) {
    var value = array[index];
    if (predicate(value, index, array)) {
      result[resIndex++] = value;
    }
  }
  return result;
}

module.exports = arrayFilter;


/***/ }),
/* 174 */
/***/ (function(module, exports, __webpack_require__) {

var DataView = __webpack_require__(175),
    Map = __webpack_require__(35),
    Promise = __webpack_require__(176),
    Set = __webpack_require__(177),
    WeakMap = __webpack_require__(178),
    baseGetTag = __webpack_require__(13),
    toSource = __webpack_require__(62);

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    objectTag = '[object Object]',
    promiseTag = '[object Promise]',
    setTag = '[object Set]',
    weakMapTag = '[object WeakMap]';

var dataViewTag = '[object DataView]';

/** Used to detect maps, sets, and weakmaps. */
var dataViewCtorString = toSource(DataView),
    mapCtorString = toSource(Map),
    promiseCtorString = toSource(Promise),
    setCtorString = toSource(Set),
    weakMapCtorString = toSource(WeakMap);

/**
 * Gets the `toStringTag` of `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
var getTag = baseGetTag;

// Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
if ((DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag) ||
    (Map && getTag(new Map) != mapTag) ||
    (Promise && getTag(Promise.resolve()) != promiseTag) ||
    (Set && getTag(new Set) != setTag) ||
    (WeakMap && getTag(new WeakMap) != weakMapTag)) {
  getTag = function(value) {
    var result = baseGetTag(value),
        Ctor = result == objectTag ? value.constructor : undefined,
        ctorString = Ctor ? toSource(Ctor) : '';

    if (ctorString) {
      switch (ctorString) {
        case dataViewCtorString: return dataViewTag;
        case mapCtorString: return mapTag;
        case promiseCtorString: return promiseTag;
        case setCtorString: return setTag;
        case weakMapCtorString: return weakMapTag;
      }
    }
    return result;
  };
}

module.exports = getTag;


/***/ }),
/* 175 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9),
    root = __webpack_require__(7);

/* Built-in method references that are verified to be native. */
var DataView = getNative(root, 'DataView');

module.exports = DataView;


/***/ }),
/* 176 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9),
    root = __webpack_require__(7);

/* Built-in method references that are verified to be native. */
var Promise = getNative(root, 'Promise');

module.exports = Promise;


/***/ }),
/* 177 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9),
    root = __webpack_require__(7);

/* Built-in method references that are verified to be native. */
var Set = getNative(root, 'Set');

module.exports = Set;


/***/ }),
/* 178 */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(9),
    root = __webpack_require__(7);

/* Built-in method references that are verified to be native. */
var WeakMap = getNative(root, 'WeakMap');

module.exports = WeakMap;


/***/ }),
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

var isStrictComparable = __webpack_require__(70),
    keys = __webpack_require__(12);

/**
 * Gets the property names, values, and compare flags of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the match data of `object`.
 */
function getMatchData(object) {
  var result = keys(object),
      length = result.length;

  while (length--) {
    var key = result[length],
        value = object[key];

    result[length] = [key, value, isStrictComparable(value)];
  }
  return result;
}

module.exports = getMatchData;


/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsEqual = __webpack_require__(65),
    get = __webpack_require__(181),
    hasIn = __webpack_require__(72),
    isKey = __webpack_require__(39),
    isStrictComparable = __webpack_require__(70),
    matchesStrictComparable = __webpack_require__(71),
    toKey = __webpack_require__(18);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/**
 * The base implementation of `_.matchesProperty` which doesn't clone `srcValue`.
 *
 * @private
 * @param {string} path The path of the property to get.
 * @param {*} srcValue The value to match.
 * @returns {Function} Returns the new spec function.
 */
function baseMatchesProperty(path, srcValue) {
  if (isKey(path) && isStrictComparable(srcValue)) {
    return matchesStrictComparable(toKey(path), srcValue);
  }
  return function(object) {
    var objValue = get(object, path);
    return (objValue === undefined && objValue === srcValue)
      ? hasIn(object, path)
      : baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG);
  };
}

module.exports = baseMatchesProperty;


/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(38);

/**
 * Gets the value at `path` of `object`. If the resolved value is
 * `undefined`, the `defaultValue` is returned in its place.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @param {*} [defaultValue] The value returned for `undefined` resolved values.
 * @returns {*} Returns the resolved value.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.get(object, 'a[0].b.c');
 * // => 3
 *
 * _.get(object, ['a', '0', 'b', 'c']);
 * // => 3
 *
 * _.get(object, 'a.b.c', 'default');
 * // => 'default'
 */
function get(object, path, defaultValue) {
  var result = object == null ? undefined : baseGet(object, path);
  return result === undefined ? defaultValue : result;
}

module.exports = get;


/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

var memoizeCapped = __webpack_require__(183);

/** Used to match property names within property paths. */
var reLeadingDot = /^\./,
    rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoizeCapped(function(string) {
  var result = [];
  if (reLeadingDot.test(string)) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, string) {
    result.push(quote ? string.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

module.exports = stringToPath;


/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

var memoize = __webpack_require__(184);

/** Used as the maximum memoize cache size. */
var MAX_MEMOIZE_SIZE = 500;

/**
 * A specialized version of `_.memoize` which clears the memoized function's
 * cache when it exceeds `MAX_MEMOIZE_SIZE`.
 *
 * @private
 * @param {Function} func The function to have its output memoized.
 * @returns {Function} Returns the new memoized function.
 */
function memoizeCapped(func) {
  var result = memoize(func, function(key) {
    if (cache.size === MAX_MEMOIZE_SIZE) {
      cache.clear();
    }
    return key;
  });

  var cache = result.cache;
  return result;
}

module.exports = memoizeCapped;


/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

var MapCache = __webpack_require__(36);

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `clear`, `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver != null && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result) || cache;
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Expose `MapCache`.
memoize.Cache = MapCache;

module.exports = memoize;


/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(14),
    arrayMap = __webpack_require__(19),
    isArray = __webpack_require__(6),
    isSymbol = __webpack_require__(26);

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;

/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }
  if (isArray(value)) {
    // Recursively convert values (susceptible to call stack limits).
    return arrayMap(value, baseToString) + '';
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

module.exports = baseToString;


/***/ }),
/* 186 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.hasIn` without support for deep paths.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {Array|string} key The key to check.
 * @returns {boolean} Returns `true` if `key` exists, else `false`.
 */
function baseHasIn(object, key) {
  return object != null && key in Object(object);
}

module.exports = baseHasIn;


/***/ }),
/* 187 */
/***/ (function(module, exports, __webpack_require__) {

var castPath = __webpack_require__(25),
    isArguments = __webpack_require__(29),
    isArray = __webpack_require__(6),
    isIndex = __webpack_require__(30),
    isLength = __webpack_require__(31),
    toKey = __webpack_require__(18);

/**
 * Checks if `path` exists on `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @param {Function} hasFunc The function to check properties.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 */
function hasPath(object, path, hasFunc) {
  path = castPath(path, object);

  var index = -1,
      length = path.length,
      result = false;

  while (++index < length) {
    var key = toKey(path[index]);
    if (!(result = object != null && hasFunc(object, key))) {
      break;
    }
    object = object[key];
  }
  if (result || ++index != length) {
    return result;
  }
  length = object == null ? 0 : object.length;
  return !!length && isLength(length) && isIndex(key, length) &&
    (isArray(object) || isArguments(object));
}

module.exports = hasPath;


/***/ }),
/* 188 */
/***/ (function(module, exports, __webpack_require__) {

var baseProperty = __webpack_require__(189),
    basePropertyDeep = __webpack_require__(190),
    isKey = __webpack_require__(39),
    toKey = __webpack_require__(18);

/**
 * Creates a function that returns the value at `path` of a given object.
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Util
 * @param {Array|string} path The path of the property to get.
 * @returns {Function} Returns the new accessor function.
 * @example
 *
 * var objects = [
 *   { 'a': { 'b': 2 } },
 *   { 'a': { 'b': 1 } }
 * ];
 *
 * _.map(objects, _.property('a.b'));
 * // => [2, 1]
 *
 * _.map(_.sortBy(objects, _.property(['a', 'b'])), 'a.b');
 * // => [1, 2]
 */
function property(path) {
  return isKey(path) ? baseProperty(toKey(path)) : basePropertyDeep(path);
}

module.exports = property;


/***/ }),
/* 189 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.property` without support for deep paths.
 *
 * @private
 * @param {string} key The key of the property to get.
 * @returns {Function} Returns the new accessor function.
 */
function baseProperty(key) {
  return function(object) {
    return object == null ? undefined : object[key];
  };
}

module.exports = baseProperty;


/***/ }),
/* 190 */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(38);

/**
 * A specialized version of `baseProperty` which supports deep paths.
 *
 * @private
 * @param {Array|string} path The path of the property to get.
 * @returns {Function} Returns the new accessor function.
 */
function basePropertyDeep(path) {
  return function(object) {
    return baseGet(object, path);
  };
}

module.exports = basePropertyDeep;


/***/ }),
/* 191 */
/***/ (function(module, exports, __webpack_require__) {

var createCaseFirst = __webpack_require__(192);

/**
 * Converts the first character of `string` to upper case.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.upperFirst('fred');
 * // => 'Fred'
 *
 * _.upperFirst('FRED');
 * // => 'FRED'
 */
var upperFirst = createCaseFirst('toUpperCase');

module.exports = upperFirst;


/***/ }),
/* 192 */
/***/ (function(module, exports, __webpack_require__) {

var castSlice = __webpack_require__(193),
    hasUnicode = __webpack_require__(74),
    stringToArray = __webpack_require__(195),
    toString = __webpack_require__(40);

/**
 * Creates a function like `_.lowerFirst`.
 *
 * @private
 * @param {string} methodName The name of the `String` case method to use.
 * @returns {Function} Returns the new case function.
 */
function createCaseFirst(methodName) {
  return function(string) {
    string = toString(string);

    var strSymbols = hasUnicode(string)
      ? stringToArray(string)
      : undefined;

    var chr = strSymbols
      ? strSymbols[0]
      : string.charAt(0);

    var trailing = strSymbols
      ? castSlice(strSymbols, 1).join('')
      : string.slice(1);

    return chr[methodName]() + trailing;
  };
}

module.exports = createCaseFirst;


/***/ }),
/* 193 */
/***/ (function(module, exports, __webpack_require__) {

var baseSlice = __webpack_require__(194);

/**
 * Casts `array` to a slice if it's needed.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {number} start The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the cast slice.
 */
function castSlice(array, start, end) {
  var length = array.length;
  end = end === undefined ? length : end;
  return (!start && end >= length) ? array : baseSlice(array, start, end);
}

module.exports = castSlice;


/***/ }),
/* 194 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.slice` without an iteratee call guard.
 *
 * @private
 * @param {Array} array The array to slice.
 * @param {number} [start=0] The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the slice of `array`.
 */
function baseSlice(array, start, end) {
  var index = -1,
      length = array.length;

  if (start < 0) {
    start = -start > length ? 0 : (length + start);
  }
  end = end > length ? length : end;
  if (end < 0) {
    end += length;
  }
  length = start > end ? 0 : ((end - start) >>> 0);
  start >>>= 0;

  var result = Array(length);
  while (++index < length) {
    result[index] = array[index + start];
  }
  return result;
}

module.exports = baseSlice;


/***/ }),
/* 195 */
/***/ (function(module, exports, __webpack_require__) {

var asciiToArray = __webpack_require__(196),
    hasUnicode = __webpack_require__(74),
    unicodeToArray = __webpack_require__(197);

/**
 * Converts `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */
function stringToArray(string) {
  return hasUnicode(string)
    ? unicodeToArray(string)
    : asciiToArray(string);
}

module.exports = stringToArray;


/***/ }),
/* 196 */
/***/ (function(module, exports) {

/**
 * Converts an ASCII `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */
function asciiToArray(string) {
  return string.split('');
}

module.exports = asciiToArray;


/***/ }),
/* 197 */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsVarRange = '\\ufe0e\\ufe0f';

/** Used to compose unicode capture groups. */
var rsAstral = '[' + rsAstralRange + ']',
    rsCombo = '[' + rsComboRange + ']',
    rsFitz = '\\ud83c[\\udffb-\\udfff]',
    rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')',
    rsNonAstral = '[^' + rsAstralRange + ']',
    rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}',
    rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]',
    rsZWJ = '\\u200d';

/** Used to compose unicode regexes. */
var reOptMod = rsModifier + '?',
    rsOptVar = '[' + rsVarRange + ']?',
    rsOptJoin = '(?:' + rsZWJ + '(?:' + [rsNonAstral, rsRegional, rsSurrPair].join('|') + ')' + rsOptVar + reOptMod + ')*',
    rsSeq = rsOptVar + reOptMod + rsOptJoin,
    rsSymbol = '(?:' + [rsNonAstral + rsCombo + '?', rsCombo, rsRegional, rsSurrPair, rsAstral].join('|') + ')';

/** Used to match [string symbols](https://mathiasbynens.be/notes/javascript-unicode). */
var reUnicode = RegExp(rsFitz + '(?=' + rsFitz + ')|' + rsSymbol + rsSeq, 'g');

/**
 * Converts a Unicode `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */
function unicodeToArray(string) {
  return string.match(reUnicode) || [];
}

module.exports = unicodeToArray;


/***/ }),
/* 198 */
/***/ (function(module, exports) {

module.exports = require("countryjs");

/***/ }),
/* 199 */
/***/ (function(module, exports) {

module.exports = require("google-translate");

/***/ }),
/* 200 */
/***/ (function(module, exports) {

module.exports = require("swagger-client");

/***/ }),
/* 201 */
/***/ (function(module, exports) {

module.exports = require("deasync");

/***/ }),
/* 202 */
/***/ (function(module, exports) {

module.exports = {"swagger":"2.0","info":{"title":"Invoice Ninja API","description":"An open-source invoicing and time-tracking app built with Laravel","termsOfService":"","contact":{"email":"contact@invoiceninja.com"},"license":{"name":"Attribution Assurance License","url":"https://raw.githubusercontent.com/invoiceninja/invoiceninja/master/LICENSE"},"version":"1.0.0"},"host":"ninja.dev","basePath":"/api/v1","schemes":["http","https"],"paths":{"/clients":{"get":{"tags":["client"],"summary":"List clients","operationId":"listClients","parameters":[{"name":"email","in":"query","description":"search clients by their email address","type":"string"},{"name":"per_page","in":"query","description":"number of results returned per page","type":"integer"},{"name":"page","in":"query","description":"page number of results to return when the results are paginated","type":"integer"},{"name":"updated_at","in":"query","description":"Timestamp used as a filter to only show recently updated records","type":"string"}],"responses":{"200":{"description":"A list of clients","schema":{"type":"array","items":{"$ref":"#/definitions/Client"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["client"],"summary":"Create a client","operationId":"createClient","parameters":[{"name":"client","in":"body","schema":{"$ref":"#/definitions/Client"}}],"responses":{"200":{"description":"New client","schema":{"type":"object","items":{"$ref":"#/definitions/Client"}}},"default":{"description":"an \"unexpected\" error"}}}},"/clients/{client_id}":{"get":{"tags":["client"],"summary":"Retrieve a client","operationId":"getClient","parameters":[{"name":"client_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single client","schema":{"type":"object","items":{"$ref":"#/definitions/Client"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["client"],"summary":"Update a client","operationId":"updateClient","parameters":[{"name":"client_id","in":"path","required":true,"type":"integer"},{"name":"client","in":"body","schema":{"$ref":"#/definitions/Client"}}],"responses":{"200":{"description":"Updated client","schema":{"type":"object","items":{"$ref":"#/definitions/Client"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["client"],"summary":"Delete a client","operationId":"deleteClient","parameters":[{"name":"client_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted client","schema":{"type":"object","items":{"$ref":"#/definitions/Client"}}},"default":{"description":"an \"unexpected\" error"}}}},"/contacts":{"get":{"tags":["contact"],"summary":"List contacts","responses":{"200":{"description":"A list of contacts","schema":{"type":"array","items":{"$ref":"#/definitions/Contact"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["contact"],"summary":"Create a contact","parameters":[{"name":"contact","in":"body","schema":{"$ref":"#/definitions/Contact"}}],"responses":{"200":{"description":"New contact","schema":{"type":"object","items":{"$ref":"#/definitions/Contact"}}},"default":{"description":"an \"unexpected\" error"}}}},"/contacts/{contact_id}":{"get":{"tags":["contact"],"summary":"Retrieve a contact","parameters":[{"name":"contact_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single contact","schema":{"type":"object","items":{"$ref":"#/definitions/Contact"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["contact"],"summary":"Update a contact","parameters":[{"name":"contact_id","in":"path","required":true,"type":"integer"},{"name":"contact","in":"body","schema":{"$ref":"#/definitions/Contact"}}],"responses":{"200":{"description":"Updated contact","schema":{"type":"object","items":{"$ref":"#/definitions/Contact"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["contact"],"summary":"Delete a contact","parameters":[{"name":"contact_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted contact","schema":{"type":"object","items":{"$ref":"#/definitions/Contact"}}},"default":{"description":"an \"unexpected\" error"}}}},"/documents":{"get":{"tags":["document"],"summary":"List document","operationId":"listDocuments","responses":{"200":{"description":"A list of documents","schema":{"type":"array","items":{"$ref":"#/definitions/Document"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["document"],"summary":"Create a document","operationId":"createDocument","parameters":[{"name":"document","in":"body","schema":{"$ref":"#/definitions/Document"}}],"responses":{"200":{"description":"New document","schema":{"type":"object","items":{"$ref":"#/definitions/Document"}}},"default":{"description":"an \"unexpected\" error"}}}},"/documents/{document_id}":{"get":{"tags":["document"],"summary":"Download a document","operationId":"getDocument","produces":["application/octet-stream"],"parameters":[{"name":"document_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A file","schema":{"type":"file"}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["document"],"summary":"Delete a document","operationId":"deleteDocument","parameters":[{"name":"document_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted document","schema":{"type":"object","items":{"$ref":"#/definitions/Document"}}},"default":{"description":"an \"unexpected\" error"}}}},"/expenses":{"get":{"tags":["expense"],"summary":"List expenses","operationId":"listExpenses","responses":{"200":{"description":"A list of expenses","schema":{"type":"array","items":{"$ref":"#/definitions/Expense"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["expense"],"summary":"Create an expense","operationId":"createExpense","parameters":[{"name":"expense","in":"body","schema":{"$ref":"#/definitions/Expense"}}],"responses":{"200":{"description":"New expense","schema":{"type":"object","items":{"$ref":"#/definitions/Expense"}}},"default":{"description":"an \"unexpected\" error"}}}},"/expenses/{expense_id}":{"get":{"tags":["expense"],"summary":"Retrieve an expense","operationId":"getExpense","parameters":[{"name":"expense_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single expense","schema":{"type":"object","items":{"$ref":"#/definitions/Expense"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["expense"],"summary":"Update an expense","operationId":"updateExpense","parameters":[{"name":"expense_id","in":"path","required":true,"type":"integer"},{"name":"expense","in":"body","schema":{"$ref":"#/definitions/Expense"}}],"responses":{"200":{"description":"Updated expense","schema":{"type":"object","items":{"$ref":"#/definitions/Expense"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["expense"],"summary":"Delete an expense","operationId":"deleteExpense","parameters":[{"name":"expense_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted expense","schema":{"type":"object","items":{"$ref":"#/definitions/Expense"}}},"default":{"description":"an \"unexpected\" error"}}}},"/expense_categories":{"get":{"tags":["expense_category"],"summary":"List expense categories","operationId":"listExpenseCategories","responses":{"200":{"description":"A list of expense categories","schema":{"type":"array","items":{"$ref":"#/definitions/ExpenseCategory"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["expense_category"],"summary":"Create an expense category","operationId":"createExpenseCategory","parameters":[{"name":"expense_category","in":"body","schema":{"$ref":"#/definitions/ExpenseCategory"}}],"responses":{"200":{"description":"New expense category","schema":{"type":"object","items":{"$ref":"#/definitions/ExpenseCategory"}}},"default":{"description":"an \"unexpected\" error"}}}},"/expense_categories/{expense_category_id}":{"get":{"tags":["expense_category"],"summary":"Retrieve an Expense Category","operationId":"getExpenseCategory","parameters":[{"name":"expense_category_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single expense categroy","schema":{"type":"object","items":{"$ref":"#/definitions/ExpenseCategory"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["expense_category"],"summary":"Update an expense category","operationId":"updateExpenseCategory","parameters":[{"name":"expense_category_id","in":"path","required":true,"type":"integer"},{"name":"expense_category","in":"body","schema":{"$ref":"#/definitions/ExpenseCategory"}}],"responses":{"200":{"description":"Updated expense category","schema":{"type":"object","items":{"$ref":"#/definitions/ExpenseCategory"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["expense_category"],"summary":"Delete an expense category","operationId":"deleteExpenseCategory","parameters":[{"name":"expense_category_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted expense category","schema":{"type":"object","items":{"$ref":"#/definitions/ExpenseCategory"}}},"default":{"description":"an \"unexpected\" error"}}}},"/invoices":{"get":{"tags":["invoice"],"summary":"List invoices","operationId":"listInvoices","parameters":[{"name":"invoice_number","in":"query","description":"search invoices by their invoice number","type":"string"},{"name":"client_id","in":"query","description":"search invoices by their client id","type":"string"},{"name":"per_page","in":"query","description":"number of results returned per page","type":"integer"},{"name":"page","in":"query","description":"page number of results to return when the results are paginated","type":"integer"},{"name":"updated_at","in":"query","description":"Timestamp used as a filter to only show recently updated records","type":"string"}],"responses":{"200":{"description":"A list of invoices","schema":{"type":"array","items":{"$ref":"#/definitions/Invoice"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["invoice"],"summary":"Create an invoice","operationId":"createInvoice","parameters":[{"name":"invoice","in":"body","schema":{"$ref":"#/definitions/Invoice"}}],"responses":{"200":{"description":"New invoice","schema":{"type":"object","items":{"$ref":"#/definitions/Invoice"}}},"default":{"description":"an \"unexpected\" error"}}}},"/invoices/{invoice_id}":{"get":{"tags":["invoice"],"summary":"Retrieve an Invoice","operationId":"getInvoice","parameters":[{"name":"invoice_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single invoice","schema":{"type":"object","items":{"$ref":"#/definitions/Invoice"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["invoice"],"summary":"Update an invoice","operationId":"updateInvoice","parameters":[{"name":"invoice_id","in":"path","required":true,"type":"integer"},{"name":"invoice","in":"body","schema":{"$ref":"#/definitions/Invoice"}}],"responses":{"200":{"description":"Updated invoice","schema":{"type":"object","items":{"$ref":"#/definitions/Invoice"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["invoice"],"summary":"Delete an invoice","operationId":"deleteInvoice","parameters":[{"name":"invoice_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted invoice","schema":{"type":"object","items":{"$ref":"#/definitions/Invoice"}}},"default":{"description":"an \"unexpected\" error"}}}},"/payments":{"get":{"tags":["payment"],"summary":"List payments","operationId":"listPayments","responses":{"200":{"description":"A list of payments","schema":{"type":"array","items":{"$ref":"#/definitions/Payment"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["payment"],"summary":"Create a payment","operationId":"createPayment","parameters":[{"name":"payment","in":"body","schema":{"$ref":"#/definitions/Payment"}}],"responses":{"200":{"description":"New payment","schema":{"type":"object","items":{"$ref":"#/definitions/Payment"}}},"default":{"description":"an \"unexpected\" error"}}}},"/payments/{payment_id}":{"get":{"tags":["payment"],"summary":"Retrieve a payment","operationId":"getPayment","parameters":[{"name":"payment_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single payment","schema":{"type":"object","items":{"$ref":"#/definitions/Payment"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["payment"],"summary":"Update a payment","operationId":"updatePayment","parameters":[{"name":"payment_id","in":"path","required":true,"type":"integer"},{"name":"payment","in":"body","schema":{"$ref":"#/definitions/Payment"}}],"responses":{"200":{"description":"Updated payment","schema":{"type":"object","items":{"$ref":"#/definitions/Payment"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["payment"],"summary":"Delete a payment","operationId":"deletePayment","parameters":[{"name":"payment_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted payment","schema":{"type":"object","items":{"$ref":"#/definitions/Payment"}}},"default":{"description":"an \"unexpected\" error"}}}},"/products":{"get":{"tags":["product"],"summary":"List products","operationId":"listProducts","responses":{"200":{"description":"A list of products","schema":{"type":"array","items":{"$ref":"#/definitions/Product"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["product"],"summary":"Create a product","operationId":"createProduct","parameters":[{"name":"body","in":"body","schema":{"$ref":"#/definitions/Product"}}],"responses":{"200":{"description":"New product","schema":{"type":"object","items":{"$ref":"#/definitions/Product"}}},"default":{"description":"an \"unexpected\" error"}}}},"/products/{product_id}":{"get":{"tags":["product"],"summary":"Retrieve a product","operationId":"getProduct","parameters":[{"name":"product_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single product","schema":{"type":"object","items":{"$ref":"#/definitions/Product"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["product"],"summary":"Update a product","operationId":"updateProduct","parameters":[{"name":"product_id","in":"path","required":true,"type":"integer"},{"name":"product","in":"body","schema":{"$ref":"#/definitions/Product"}}],"responses":{"200":{"description":"Updated product","schema":{"type":"object","items":{"$ref":"#/definitions/Product"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["product"],"summary":"Delete a product","operationId":"deleteProduct","parameters":[{"name":"product_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted product","schema":{"type":"object","items":{"$ref":"#/definitions/Product"}}},"default":{"description":"an \"unexpected\" error"}}}},"/quotes":{"get":{"tags":["quote"],"summary":"List quotes","operationId":"listQuotes","responses":{"200":{"description":"A list of quotes","schema":{"type":"array","items":{"$ref":"#/definitions/Invoice"}}},"default":{"description":"an \"unexpected\" error"}}}},"/tasks":{"get":{"tags":["task"],"summary":"List tasks","operationId":"listTasks","responses":{"200":{"description":"A list of tasks","schema":{"type":"array","items":{"$ref":"#/definitions/Task"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["task"],"summary":"Create a task","operationId":"createTask","parameters":[{"name":"task","in":"body","schema":{"$ref":"#/definitions/Task"}}],"responses":{"200":{"description":"New task","schema":{"type":"object","items":{"$ref":"#/definitions/Task"}}},"default":{"description":"an \"unexpected\" error"}}}},"/tasks/{task_id}":{"get":{"tags":["task"],"summary":"Retrieve a task","operationId":"getTask","parameters":[{"name":"task_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single task","schema":{"type":"object","items":{"$ref":"#/definitions/Task"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["task"],"summary":"Update a task","operationId":"updateTask","parameters":[{"name":"task_id","in":"path","required":true,"type":"integer"},{"name":"body","in":"body","schema":{"$ref":"#/definitions/Task"}}],"responses":{"200":{"description":"Update task","schema":{"type":"object","items":{"$ref":"#/definitions/Task"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["task"],"summary":"Delete a task","operationId":"deleteTask","parameters":[{"name":"task_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted task","schema":{"type":"object","items":{"$ref":"#/definitions/Task"}}},"default":{"description":"an \"unexpected\" error"}}}},"/tax_rates":{"get":{"tags":["tax_rate"],"summary":"List tax rates","operationId":"listTaxRates","responses":{"200":{"description":"A list of tax rates","schema":{"type":"array","items":{"$ref":"#/definitions/TaxRate"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["tax_rate"],"summary":"Create a tax rate","operationId":"createTaxRate","parameters":[{"name":"tax_rate","in":"body","schema":{"$ref":"#/definitions/TaxRate"}}],"responses":{"200":{"description":"New tax rate","schema":{"type":"object","items":{"$ref":"#/definitions/TaxRate"}}},"default":{"description":"an \"unexpected\" error"}}}},"/tax_rates/{tax_rate_id}":{"get":{"tags":["tax_rate"],"summary":"Retrieve a tax rate","operationId":"getTaxRate","parameters":[{"name":"tax_rate_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single tax rate","schema":{"type":"object","items":{"$ref":"#/definitions/TaxRate"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["tax_rate"],"summary":"Update a tax rate","operationId":"updateTaxRate","parameters":[{"name":"tax_rate_id","in":"path","required":true,"type":"integer"},{"name":"tax_rate","in":"body","schema":{"$ref":"#/definitions/TaxRate"}}],"responses":{"200":{"description":"Updated tax rate","schema":{"type":"object","items":{"$ref":"#/definitions/TaxRate"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["tax_rate"],"summary":"Delete a tax rate","operationId":"deleteTaxRate","parameters":[{"name":"tax_rate_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted tax rate","schema":{"type":"object","items":{"$ref":"#/definitions/TaxRate"}}},"default":{"description":"an \"unexpected\" error"}}}},"/users":{"get":{"tags":["user"],"summary":"List users","operationId":"listUsers","responses":{"200":{"description":"A list of users","schema":{"type":"array","items":{"$ref":"#/definitions/User"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["user"],"summary":"Create a user","operationId":"createUser","parameters":[{"name":"user","in":"body","schema":{"$ref":"#/definitions/User"}}],"responses":{"200":{"description":"New user","schema":{"type":"object","items":{"$ref":"#/definitions/User"}}},"default":{"description":"an \"unexpected\" error"}}}},"/users/{user_id}":{"get":{"tags":["client"],"summary":"Retrieve a user","operationId":"getUser","parameters":[{"name":"user_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single user","schema":{"type":"object","items":{"$ref":"#/definitions/User"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["user"],"summary":"Update a user","operationId":"updateUser","parameters":[{"name":"user_id","in":"path","required":true,"type":"integer"},{"name":"user","in":"body","schema":{"$ref":"#/definitions/User"}}],"responses":{"200":{"description":"Updated user","schema":{"type":"object","items":{"$ref":"#/definitions/User"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["user"],"summary":"Delete a user","operationId":"deleteUser","parameters":[{"name":"user_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted user","schema":{"type":"object","items":{"$ref":"#/definitions/User"}}},"default":{"description":"an \"unexpected\" error"}}}},"/vendors":{"get":{"tags":["vendor"],"summary":"List vendors","operationId":"listVendors","responses":{"200":{"description":"A list of vendors","schema":{"type":"array","items":{"$ref":"#/definitions/Vendor"}}},"default":{"description":"an \"unexpected\" error"}}},"post":{"tags":["vendor"],"summary":"Create a vendor","operationId":"createVendor","parameters":[{"name":"vendor","in":"body","schema":{"$ref":"#/definitions/Vendor"}}],"responses":{"200":{"description":"New vendor","schema":{"type":"object","items":{"$ref":"#/definitions/Vendor"}}},"default":{"description":"an \"unexpected\" error"}}}},"/vendors/{vendor_id}":{"get":{"tags":["client"],"summary":"Retrieve a vendor","operationId":"getVendor","parameters":[{"name":"vendor_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"A single vendor","schema":{"type":"object","items":{"$ref":"#/definitions/Vendor"}}},"default":{"description":"an \"unexpected\" error"}}},"put":{"tags":["vendor"],"summary":"Update a vendor","operationId":"updateVendor","parameters":[{"name":"vendor_id","in":"path","required":true,"type":"integer"},{"name":"vendor","in":"body","schema":{"$ref":"#/definitions/Vendor"}}],"responses":{"200":{"description":"Updated vendor","schema":{"type":"object","items":{"$ref":"#/definitions/Vendor"}}},"default":{"description":"an \"unexpected\" error"}}},"delete":{"tags":["vendor"],"summary":"Delete a vendor","operationId":"deleteVendor","parameters":[{"name":"vendor_id","in":"path","required":true,"type":"integer"}],"responses":{"200":{"description":"Deleted vendor","schema":{"type":"object","items":{"$ref":"#/definitions/Vendor"}}},"default":{"description":"an \"unexpected\" error"}}}}},"definitions":{"Activity":{"xml":{"name":"Activity"}},"Client":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"balance":{"type":"float","readOnly":true,"example":10},"paid_to_date":{"type":"float","readOnly":true,"example":10},"user_id":{"type":"integer","example":1},"account_key":{"type":"string","example":"123456"},"updated_at":{"type":"timestamp","example":""},"archived_at":{"type":"timestamp","example":"1451160233"},"address1":{"type":"string","example":"10 Main St."},"address2":{"type":"string","example":"1st Floor"},"city":{"type":"string","example":"New York"},"state":{"type":"string","example":"NY"},"postal_code":{"type":"string","example":10010},"country_id":{"type":"integer","example":840},"work_phone":{"type":"string","example":"(212) 555-1212"},"private_notes":{"type":"string","example":"Notes..."},"last_login":{"type":"date-time","example":"2016-01-01 12:10:00"},"website":{"type":"string","example":"http://www.example.com"},"industry_id":{"type":"integer","example":1},"size_id":{"type":"integer","example":1},"is_deleted":{"type":"boolean","example":false},"payment_terms":{"type":"","example":30},"custom_value1":{"type":"string","example":"Value"},"custom_value2":{"type":"string","example":"Value"},"vat_number":{"type":"string","example":"123456"},"id_number":{"type":"string","example":"123456"},"language_id":{"type":"integer","example":1}},"xml":{"name":"Client"}},"Contact":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"first_name":{"type":"string","example":"John"},"last_name":{"type":"string","example":"Doe"},"email":{"type":"string","example":"john.doe@company.com"},"updated_at":{"type":"integer","readOnly":true,"example":1451160233},"archived_at":{"type":"integer","readOnly":true,"example":1451160233},"is_primary":{"type":"boolean","example":false},"phone":{"type":"string","example":"(212) 555-1212"},"last_login":{"type":"string","format":"date-time","example":"2016-01-01 12:10:00"},"send_invoice":{"type":"boolean","example":false}},"xml":{"name":"Contact"}},"Document":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"name":{"type":"string","example":"Test"},"type":{"type":"string","example":"CSV"},"invoice_id":{"type":"integer","example":1},"updated_at":{"type":"timestamp","readOnly":true,"example":1451160233},"archived_at":{"type":"timestamp","readOnly":true,"example":1451160233}},"xml":{"name":"Document"}},"ExpenseCategory":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"name":{"type":"string","example":"Sample"},"updated_at":{"type":"timestamp","readOnly":true,"example":1451160233},"archived_at":{"type":"timestamp","readOnly":true,"example":1451160233}},"xml":{"name":"ExpenseCategory"}},"Invoice":{"required":["invoice_number"],"properties":{"id":{"type":"integer","readOnly":true,"example":1},"amount":{"type":"float","readOnly":true,"example":10},"balance":{"type":"float","readOnly":true,"example":10},"client_id":{"type":"integer","example":1},"invoice_number":{"type":"string","example":"0001"},"invoice_status_id":{"type":"integer","example":1}},"xml":{"name":"Invoice"}},"Payment":{"required":["invoice_id"],"properties":{"id":{"type":"integer","readOnly":true,"example":1},"amount":{"type":"float","readOnly":true,"example":10},"invoice_id":{"type":"integer","example":1}},"xml":{"name":"Payment"}},"Product":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"product_key":{"type":"string","example":"Item"},"notes":{"type":"string","example":"Notes..."},"cost":{"type":"float","example":10},"qty":{"type":"float","example":1},"default_tax_rate_id":{"type":"integer","example":1},"updated_at":{"type":"timestamp","readOnly":true,"example":1451160233},"archived_at":{"type":"timestamp","readOnly":true,"example":1451160233}},"xml":{"name":"Product"}},"Project":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"name":{"type":"string","example":"Sample"},"client_id":{"type":"integer","example":1},"updated_at":{"type":"timestamp","readOnly":true,"example":1451160233},"archived_at":{"type":"timestamp","readOnly":true,"example":1451160233},"is_deleted":{"type":"boolean","readOnly":true,"example":false}},"xml":{"name":"Project"}},"Task":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"amount":{"type":"float","readOnly":true,"example":10},"invoice_id":{"type":"integer","example":1}},"xml":{"name":"Task"}},"TaxRate":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"name":{"type":"string","example":"GST"},"account_key":{"type":"string","readOnly":true,"example":"asimplestring"},"rate":{"type":"float","example":17.5},"is_inclusive":{"type":"boolean","example":false},"updated_at":{"type":"date-time","example":"2016-01-01 12:10:00"},"archived_at":{"type":"date-time","example":"2016-01-01 12:10:00"}},"xml":{"name":"TaxRate"}},"Vendor":{"properties":{"id":{"type":"integer","readOnly":true,"example":1},"balance":{"type":"float","readOnly":true,"example":10},"paid_to_date":{"type":"float","readOnly":true,"example":10},"user_id":{"type":"integer","example":1},"account_key":{"type":"string","example":"123456"},"updated_at":{"type":"timestamp","example":""},"archived_at":{"type":"timestamp","example":"1451160233"},"address1":{"type":"string","example":"10 Main St."},"address2":{"type":"string","example":"1st Floor"},"city":{"type":"string","example":"New York"},"state":{"type":"string","example":"NY"},"postal_code":{"type":"string","example":10010},"country_id":{"type":"integer","example":840},"work_phone":{"type":"string","example":"(212) 555-1212"},"private_notes":{"type":"string","example":"Notes..."},"last_login":{"type":"date-time","example":"2016-01-01 12:10:00"},"website":{"type":"string","example":"http://www.example.com"},"is_deleted":{"type":"boolean","example":false},"vat_number":{"type":"string","example":"123456"},"id_number":{"type":"string","example":"123456"}},"xml":{"name":"Vendor"}}},"securityDefinitions":{"api_key":{"type":"apiKey","name":"X-Ninja-Token","in":"header"}},"security":[{"api_key":[]}],"externalDocs":{"description":"Find out more about Invoice Ninja","url":"https://www.invoiceninja.com"}}

/***/ }),
/* 203 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 204 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const find = __webpack_require__(205);
const capitalize = __webpack_require__(10);
const map = __webpack_require__(212);

const {
  TRASH_SEGMENTS,
  INVOICENINJA_URL
} = __webpack_require__(0);

const _ = { find, capitalize, map };

module.exports = function (models) {
  const { Client } = models;
  const cache = new WeakMap();

  function getIdentyMemoized(object) {
    if (cache.has(object)) {
      return cache.get(object);
    }

    const promise = Client.getIdentity(object);

    cache.set(object, promise);

    return promise;
  }

  return {
    fields: [{
      field: 'Full Name',
      type: 'String',
      get(object) {
        return `${object.firstName} ${object.lastName.toUpperCase()}`;
      },
      search(query, search) {
        const split = search.split(' ');

        // modify the first $or of the search query
        _.find(query.where.$and, '$or').$or.push(models.sequelize.and({ firstName: { $like: `%${split[0]}%` } }, { lastName: { $like: `%${split[1]}%` } }));
      }
    }, {
      field: 'ninja',
      type: 'String',
      get(object) {
        if (object.ninjaId !== null) {
          return `${INVOICENINJA_URL}/clients/${object.ninjaId}`;
        }

        return null;
      }
    }, {
      field: 'Identity Record Form',
      type: 'String',
      get(object) {
        return `https://forms.chez-nestor.com/50392735671964?clientId=${object.id}`;
      }
    }, {
      field: 'Download Identity Record',
      type: 'String',
      get(object) {
        return getIdentyMemoized(object).then(identity => {
          return Client.getIdentityRecordUrl(identity);
        }).catch(e => {
          handleDescriptionError(e, object);
        });
      }
    }, {
      field: 'Description En',
      type: 'String',
      get(object) {
        return getIdentyMemoized(object).then(identity => {
          return Client.getDescriptionEn(Object.assign({ identity }, object));
        }).catch(e => {
          handleDescriptionError(e, object);
        });
      }
    }, {
      field: 'Description Fr',
      type: 'String',
      get(object) {
        return getIdentyMemoized(object).then(identity => {
          return Client.getDescriptionFr(Object.assign({ identity }, object));
        }).catch(e => {
          handleDescriptionError(e, object);
        });
      }
    }, {
      field: 'Invoices',
      type: ['String'],
      reference: 'Invoice.id'
    }, {
      field: 'Notes',
      type: ['String'],
      reference: 'Metadata.id'
    }, {
      field: 'jotform-attachments',
      type: ['String'],
      reference: 'RentalAttachment.id'
    }],
    actions: [{
      name: 'Credit Client',
      fields: [{
        field: 'cardHolder',
        type: 'String',
        description: 'required'
      }, {
        field: 'cardNumber',
        type: 'Number',
        description: 'required'
      }, {
        field: 'expirationMonth',
        type: 'Enum',
        enums: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'],
        description: 'required'
      }, {
        field: 'expirationYear',
        type: 'Enum',
        enums: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
        description: 'required'
      }, {
        field: 'cvv',
        type: 'Number',
        description: 'required'
      }, {
        field: 'cardType',
        type: 'Enum',
        enums: ['MasterCard', 'Visa'],
        description: 'required'
      }, {
        field: 'amount',
        type: 'Number',
        description: 'required'
      }, {
        field: 'reason',
        type: 'String'
      }, {
        field: 'orderLabel',
        type: 'String'
      }]
    }, {
      name: 'Create Rent Order',
      fields: [{
        field: 'for',
        type: 'Enum',
        enums: ['current month', 'next month']
      }]
    }, {
      name: 'Add Note',
      fields: [{
        field: 'content',
        type: 'String'
      }]
    }, {
      name: 'Change Due Date',
      fields: [{
        field: 'addDelay',
        type: 'Enum',
        enums: [1, 2, 3, 4, 5, 6, 7, 8, 9],
        isRequired: true
      }]
    }, {
      name: 'Restore Client'
    }, {
      name: 'Destroy Client'
    }],
    segments: ['lyon', 'paris', 'montpellier'].map(city => {
      return {
        name: `Currrent Clients ${_.capitalize(city)}`,
        where: () => {
          return Client.scope('currentApartment').findAll({
            where: {
              status: 'active',
              '$Rentings->Room->Apartment.addressCity$': city
            }
          }).then(clients => {
            return { id: { $in: _.map(clients, 'id') } };
          });
        }
      };
    }).concat(TRASH_SEGMENTS)
  };
};

function handleDescriptionError(error, client) {
  console.error(client, error);
  return `An error occured while generating the description: ${error.message}`;
}

/***/ }),
/* 205 */
/***/ (function(module, exports, __webpack_require__) {

var createFind = __webpack_require__(206),
    findIndex = __webpack_require__(207);

/**
 * Iterates over elements of `collection`, returning the first element
 * `predicate` returns truthy for. The predicate is invoked with three
 * arguments: (value, index|key, collection).
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Collection
 * @param {Array|Object} collection The collection to inspect.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param {number} [fromIndex=0] The index to search from.
 * @returns {*} Returns the matched element, else `undefined`.
 * @example
 *
 * var users = [
 *   { 'user': 'barney',  'age': 36, 'active': true },
 *   { 'user': 'fred',    'age': 40, 'active': false },
 *   { 'user': 'pebbles', 'age': 1,  'active': true }
 * ];
 *
 * _.find(users, function(o) { return o.age < 40; });
 * // => object for 'barney'
 *
 * // The `_.matches` iteratee shorthand.
 * _.find(users, { 'age': 1, 'active': true });
 * // => object for 'pebbles'
 *
 * // The `_.matchesProperty` iteratee shorthand.
 * _.find(users, ['active', false]);
 * // => object for 'fred'
 *
 * // The `_.property` iteratee shorthand.
 * _.find(users, 'active');
 * // => object for 'barney'
 */
var find = createFind(findIndex);

module.exports = find;


/***/ }),
/* 206 */
/***/ (function(module, exports, __webpack_require__) {

var baseIteratee = __webpack_require__(17),
    isArrayLike = __webpack_require__(16),
    keys = __webpack_require__(12);

/**
 * Creates a `_.find` or `_.findLast` function.
 *
 * @private
 * @param {Function} findIndexFunc The function to find the collection index.
 * @returns {Function} Returns the new find function.
 */
function createFind(findIndexFunc) {
  return function(collection, predicate, fromIndex) {
    var iterable = Object(collection);
    if (!isArrayLike(collection)) {
      var iteratee = baseIteratee(predicate, 3);
      collection = keys(collection);
      predicate = function(key) { return iteratee(iterable[key], key, iterable); };
    }
    var index = findIndexFunc(collection, predicate, fromIndex);
    return index > -1 ? iterable[iteratee ? collection[index] : index] : undefined;
  };
}

module.exports = createFind;


/***/ }),
/* 207 */
/***/ (function(module, exports, __webpack_require__) {

var baseFindIndex = __webpack_require__(208),
    baseIteratee = __webpack_require__(17),
    toInteger = __webpack_require__(209);

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max;

/**
 * This method is like `_.find` except that it returns the index of the first
 * element `predicate` returns truthy for instead of the element itself.
 *
 * @static
 * @memberOf _
 * @since 1.1.0
 * @category Array
 * @param {Array} array The array to inspect.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param {number} [fromIndex=0] The index to search from.
 * @returns {number} Returns the index of the found element, else `-1`.
 * @example
 *
 * var users = [
 *   { 'user': 'barney',  'active': false },
 *   { 'user': 'fred',    'active': false },
 *   { 'user': 'pebbles', 'active': true }
 * ];
 *
 * _.findIndex(users, function(o) { return o.user == 'barney'; });
 * // => 0
 *
 * // The `_.matches` iteratee shorthand.
 * _.findIndex(users, { 'user': 'fred', 'active': false });
 * // => 1
 *
 * // The `_.matchesProperty` iteratee shorthand.
 * _.findIndex(users, ['active', false]);
 * // => 0
 *
 * // The `_.property` iteratee shorthand.
 * _.findIndex(users, 'active');
 * // => 2
 */
function findIndex(array, predicate, fromIndex) {
  var length = array == null ? 0 : array.length;
  if (!length) {
    return -1;
  }
  var index = fromIndex == null ? 0 : toInteger(fromIndex);
  if (index < 0) {
    index = nativeMax(length + index, 0);
  }
  return baseFindIndex(array, baseIteratee(predicate, 3), index);
}

module.exports = findIndex;


/***/ }),
/* 208 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.findIndex` and `_.findLastIndex` without
 * support for iteratee shorthands.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {Function} predicate The function invoked per iteration.
 * @param {number} fromIndex The index to search from.
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function baseFindIndex(array, predicate, fromIndex, fromRight) {
  var length = array.length,
      index = fromIndex + (fromRight ? 1 : -1);

  while ((fromRight ? index-- : ++index < length)) {
    if (predicate(array[index], index, array)) {
      return index;
    }
  }
  return -1;
}

module.exports = baseFindIndex;


/***/ }),
/* 209 */
/***/ (function(module, exports, __webpack_require__) {

var toFinite = __webpack_require__(210);

/**
 * Converts `value` to an integer.
 *
 * **Note:** This method is loosely based on
 * [`ToInteger`](http://www.ecma-international.org/ecma-262/7.0/#sec-tointeger).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {number} Returns the converted integer.
 * @example
 *
 * _.toInteger(3.2);
 * // => 3
 *
 * _.toInteger(Number.MIN_VALUE);
 * // => 0
 *
 * _.toInteger(Infinity);
 * // => 1.7976931348623157e+308
 *
 * _.toInteger('3.2');
 * // => 3
 */
function toInteger(value) {
  var result = toFinite(value),
      remainder = result % 1;

  return result === result ? (remainder ? result - remainder : result) : 0;
}

module.exports = toInteger;


/***/ }),
/* 210 */
/***/ (function(module, exports, __webpack_require__) {

var toNumber = __webpack_require__(211);

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0,
    MAX_INTEGER = 1.7976931348623157e+308;

/**
 * Converts `value` to a finite number.
 *
 * @static
 * @memberOf _
 * @since 4.12.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {number} Returns the converted number.
 * @example
 *
 * _.toFinite(3.2);
 * // => 3.2
 *
 * _.toFinite(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toFinite(Infinity);
 * // => 1.7976931348623157e+308
 *
 * _.toFinite('3.2');
 * // => 3.2
 */
function toFinite(value) {
  if (!value) {
    return value === 0 ? value : 0;
  }
  value = toNumber(value);
  if (value === INFINITY || value === -INFINITY) {
    var sign = (value < 0 ? -1 : 1);
    return sign * MAX_INTEGER;
  }
  return value === value ? value : 0;
}

module.exports = toFinite;


/***/ }),
/* 211 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(11),
    isSymbol = __webpack_require__(26);

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = toNumber;


/***/ }),
/* 212 */
/***/ (function(module, exports, __webpack_require__) {

var arrayMap = __webpack_require__(19),
    baseIteratee = __webpack_require__(17),
    baseMap = __webpack_require__(213),
    isArray = __webpack_require__(6);

/**
 * Creates an array of values by running each element in `collection` thru
 * `iteratee`. The iteratee is invoked with three arguments:
 * (value, index|key, collection).
 *
 * Many lodash methods are guarded to work as iteratees for methods like
 * `_.every`, `_.filter`, `_.map`, `_.mapValues`, `_.reject`, and `_.some`.
 *
 * The guarded methods are:
 * `ary`, `chunk`, `curry`, `curryRight`, `drop`, `dropRight`, `every`,
 * `fill`, `invert`, `parseInt`, `random`, `range`, `rangeRight`, `repeat`,
 * `sampleSize`, `slice`, `some`, `sortBy`, `split`, `take`, `takeRight`,
 * `template`, `trim`, `trimEnd`, `trimStart`, and `words`
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Collection
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 * @example
 *
 * function square(n) {
 *   return n * n;
 * }
 *
 * _.map([4, 8], square);
 * // => [16, 64]
 *
 * _.map({ 'a': 4, 'b': 8 }, square);
 * // => [16, 64] (iteration order is not guaranteed)
 *
 * var users = [
 *   { 'user': 'barney' },
 *   { 'user': 'fred' }
 * ];
 *
 * // The `_.property` iteratee shorthand.
 * _.map(users, 'user');
 * // => ['barney', 'fred']
 */
function map(collection, iteratee) {
  var func = isArray(collection) ? arrayMap : baseMap;
  return func(collection, baseIteratee(iteratee, 3));
}

module.exports = map;


/***/ }),
/* 213 */
/***/ (function(module, exports, __webpack_require__) {

var baseEach = __webpack_require__(214),
    isArrayLike = __webpack_require__(16);

/**
 * The base implementation of `_.map` without support for iteratee shorthands.
 *
 * @private
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */
function baseMap(collection, iteratee) {
  var index = -1,
      result = isArrayLike(collection) ? Array(collection.length) : [];

  baseEach(collection, function(value, key, collection) {
    result[++index] = iteratee(value, key, collection);
  });
  return result;
}

module.exports = baseMap;


/***/ }),
/* 214 */
/***/ (function(module, exports, __webpack_require__) {

var baseForOwn = __webpack_require__(63),
    createBaseEach = __webpack_require__(215);

/**
 * The base implementation of `_.forEach` without support for iteratee shorthands.
 *
 * @private
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array|Object} Returns `collection`.
 */
var baseEach = createBaseEach(baseForOwn);

module.exports = baseEach;


/***/ }),
/* 215 */
/***/ (function(module, exports, __webpack_require__) {

var isArrayLike = __webpack_require__(16);

/**
 * Creates a `baseEach` or `baseEachRight` function.
 *
 * @private
 * @param {Function} eachFunc The function to iterate over a collection.
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new base function.
 */
function createBaseEach(eachFunc, fromRight) {
  return function(collection, iteratee) {
    if (collection == null) {
      return collection;
    }
    if (!isArrayLike(collection)) {
      return eachFunc(collection, iteratee);
    }
    var length = collection.length,
        index = fromRight ? length : -1,
        iterable = Object(collection);

    while ((fromRight ? index-- : ++index < length)) {
      if (iteratee(iterable[index], index, iterable) === false) {
        break;
      }
    }
    return collection;
  };
}

module.exports = createBaseEach;


/***/ }),
/* 216 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const uuid = __webpack_require__(76);
const pickBy = __webpack_require__(220);
const mapKeys = __webpack_require__(59);
const D = __webpack_require__(4);
const Multer = __webpack_require__(229);
const Liana = __webpack_require__(5);
const Ninja = __webpack_require__(41);
const SendinBlue = __webpack_require__(42);
const Utils = __webpack_require__(3);
const { INVOICENINJA_URL } = __webpack_require__(0);
const {
  SENDINBLUE_LIST_IDS,
  SENDINBLUE_TEMPLATE_IDS
} = __webpack_require__(2);

const _ = { pickBy, mapKeys };

module.exports = (app, models, Client) => {
  const LEA = Liana.ensureAuthenticated;
  const multer = Multer().fields([{ name: 'passport', maxCount: 1 }]);

  app.delete('/forest/Client/:clientId/relationships/Orders', LEA, (req, res) => {
    const ids = [];

    req.body.data.filter(_data => {
      return _data.type === 'order';
    }).map(order => {
      return ids.push(order.id);
    });

    models.Order.findAll({ where: { id: { $in: ids } } }).map(order => {
      return Promise.all([order, order.getCalculatedProps()]);
    }).filter(([, { totalPaid }]) => {
      return totalPaid === null;
    }).map(([order]) => {
      return order.destroy();
    }).then(Utils.createSuccessHandler(res, 'Orders')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/create-rent-order', LEA, (req, res) => {
    const { values, ids } = req.body.data.attributes;
    const month = values.for === 'current month' ? D.startOfMonth(new Date()) : D.addMonths(new Date(), 1);

    Promise.resolve().then(() => {
      if (!values.for) {
        throw new Error('"for" field is required');
      }

      return Client.scope({ method: ['rentOrdersFor', month] }, // required by createRentOrders
      'uncashedDepositCount', // required by findOrCreateRentOrder
      'paymentDelay' // required by findOrCreateRentOrder
      ).findAll({ where: { id: { $in: ids } } });
    }).then(clients => {
      return Client.createRentOrders(clients, month);
    }).then(Utils.createSuccessHandler(res, 'Renting Order')).catch(Utils.logAndSend(res));

    return null;
  });

  app.post('/forest/actions/change-due-date', LEA, (req, res) => {
    const { values, ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (!values.addDelay) {
        throw new Error('You must specify a delay');
      }
      return Client.findAll({ where: { id: { $in: ids } } });
    }).mapSeries(client => {
      return models.Metadata.createOrUpdate({
        name: 'payment-delay',
        value: values.addDelay,
        metadatable: 'Client',
        MetadatableId: client.id
      });
    }).then(Utils.createSuccessHandler(res, 'New Due Date')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/credit-client', LEA, (req, res) => {
    const idCredit = uuid();
    const { values, ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (!values.cardNumber || !values.cardType || !values.expirationMonth || !values.expirationYear || !values.cvv || !values.cardHolder || !values.amount) {
        throw new Error('All fields are required');
      }

      if (ids.length > 1) {
        throw new Error('Can\'t credit multiple clients');
      }

      values.amount *= 100;

      return Client.paylineCredit(ids[0], values, idCredit);
    }).then(Utils.createSuccessHandler(res, 'Payline credit')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/add-note', LEA, (req, res) => {
    const { values, ids, collection_name: metadatable } = req.body.data.attributes;

    models.Metadata.bulkCreate(ids.map(MetadatableId => {
      return {
        name: 'note',
        metadatable,
        MetadatableId,
        value: values.content
      };
    })).then(Utils.createSuccessHandler(res, `${metadatable} Note`)).catch(Utils.logAndSend(res));
  });

  app.get('/forest/Client/:recordId/relationships/Invoices', LEA, (req, res) => {
    Client.findById(req.params.recordId).then(client => {
      return Ninja.invoice.listInvoices({
        'client_id': client.ninjaId
      });
    }).then(response => {
      const { data } = response.obj;

      return res.send({
        data: data.map(invoice => {
          return {
            id: invoice.id,
            type: 'Invoice',
            attributes: {
              href: `${INVOICENINJA_URL}/invoices/${invoice.id}/edit`
            }
          };
        }),
        meta: { count: data.length }
      });
    }).catch(Utils.logAndSend(res));
  });

  app.get('/forest/Client/:recordId/relationships/jotform-attachments', LEA, (req, res) => {
    models.Metadata.findAll({
      where: {
        name: 'rentalAttachments',
        MetadatableId: req.params.recordId
      },
      order: ['createdAt'],
      limit: 1
    }).then(metadata => {
      if (!metadata.length) {
        return res.send({ data: [], meta: { count: 0 } });
      }

      let rUrl = /https:\/\/www\.jotformeu\.com\/uploads\/cheznestor\//g;
      const values = _.pickBy(JSON.parse(metadata[0].value), value => {
        return rUrl.test(value);
      });

      return res.send({
        data: Object.keys(values).map(key => {
          return {
            type: 'rentalAttachment',
            id: key,
            attributes: {
              href: values[key]
            }
          };
        }),
        meta: { count: Object.keys(values).length }
      });
    }).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/rental-attachments', multer, LEA, (req, res) => {
    const values = _.mapKeys(JSON.parse(req.body.rawRequest), (value, key) => {
      return key.replace(/(q[\d]*_)/g, '');
    });
    const scoped = Client.scope('latestClientRenting');

    Promise.resolve(/@/.test(values.clientId) ? scoped.findAll({ where: { email: values.clientId } }) : scoped.findAll({ where: { id: values.clientId } })).then(([client]) => {
      return client.createMetadatum({
        name: 'rentalAttachments',
        value: JSON.stringify(values)
      });
    }).then(Utils.createSuccessHandler(res, 'Client metadata')).catch(Utils.logAndSend(res));
  });

  /*
    Handle JotForm data (Identity - New Member)
    in order to collect more information for a new client
  */
  app.post('/forest/actions/client-identity', multer, LEA, (req, res) => {
    Client.normalizeIdentityRecord(JSON.parse(req.body.rawRequest)).then(identityRecord => {
      const { fullName, phoneNumber, clientId } = identityRecord;
      const fieldsToUpdate = {
        firstName: fullName.first,
        lastName: fullName.last,
        phoneNumber: Utils.isValidPhoneNumber(phoneNumber) && phoneNumber
      };
      const scoped = Client.scope('latestClientRenting');

      return Promise.all([/@/.test(clientId) ? scoped.findAll({ where: { email: clientId } }) : scoped.findAll({ where: { id: clientId } }), fieldsToUpdate, identityRecord]);
    }).tap(([[client], fieldsToUpdate, identityRecord]) => {
      const { year, month, day, hour, min } = identityRecord.checkinDate;
      const startDate = `${year}-${month}-${day} ${hour}:${min}`;
      const { addressCity } = client.Rentings[0].Room.Apartment;
      const { preferredLanguage } = client;

      return Promise.all([client.update(_.pickBy(fieldsToUpdate, Boolean) // filter out falsy phoneNumber
      ), client.createMetadatum({ // sequelize pluralization ¯\_(ツ)_/¯
        name: 'clientIdentity',
        value: JSON.stringify(identityRecord)
      }), models.Renting.findOrCreateCheckinEvent({
        startDate,
        renting: client.Rentings[0],
        client,
        room: client.Rentings[0].Room
      }), SendinBlue.updateContact(client.email, {
        listIds: [SENDINBLUE_LIST_IDS[preferredLanguage], SENDINBLUE_LIST_IDS[addressCity].all, SENDINBLUE_LIST_IDS[addressCity][preferredLanguage]],
        unlinkListIds: [SENDINBLUE_LIST_IDS.prospects[preferredLanguage]]
      })]);
    }).then(([[client]]) => {
      return Promise.all([Client.scope('currentApartment').findAll({
        where: {
          '$Rentings->Room.ApartmentId$': client.Rentings[0].Room.ApartmentId,
          '$Rentings.bookingDate$': { $lte: new Date() },
          'id': { $ne: client.id }
        }
      }), models.Metadata.findOne({
        where: {
          name: 'clientIdentity',
          MetadatableId: client.id
        }
      })]);
    }).then(([houseMates, metadata]) => {
      // TODO: this belongs in Sendinblue.js
      // and should be merged with the code in the following then.
      // see sendWelcomeEmail for example
      return Utils.serializeHousemate(houseMates, metadata);
    }).then(([attributesFr, attributesEn, emailToFr, emailToEn]) => {
      return Promise.all([SendinBlue.sendEmail(SENDINBLUE_TEMPLATE_IDS.newHousemate.fr, { emailTo: emailToFr, attributes: attributesFr }), SendinBlue.sendEmail(SENDINBLUE_TEMPLATE_IDS.newHousemate.en, { emailTo: emailToEn, attributes: attributesEn })]);
    }).then(Utils.createSuccessHandler(res, 'Client metadata')).catch(Utils.logAndSend(res));
  });

  Utils.addInternalRelationshipRoute({
    app,
    sourceModel: Client,
    associatedModel: models.Metadata,
    routeName: 'Notes',
    where: req => {
      return { MetadatableId: req.params.recordId, name: 'note' };
    }
  });

  Utils.addRestoreAndDestroyRoutes(app, Client);
};

/***/ }),
/* 217 */
/***/ (function(module, exports, __webpack_require__) {

// Unique ID creation requires a high quality random # generator.  In node.js
// this is pretty straight-forward - we use the crypto API.

var rb = __webpack_require__(218).randomBytes;

function rng() {
  return rb(16);
}

module.exports = rng;


/***/ }),
/* 218 */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),
/* 219 */
/***/ (function(module, exports) {

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];
for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex;
  return bth[buf[i++]] + bth[buf[i++]] +
          bth[buf[i++]] + bth[buf[i++]] + '-' +
          bth[buf[i++]] + bth[buf[i++]] + '-' +
          bth[buf[i++]] + bth[buf[i++]] + '-' +
          bth[buf[i++]] + bth[buf[i++]] + '-' +
          bth[buf[i++]] + bth[buf[i++]] +
          bth[buf[i++]] + bth[buf[i++]] +
          bth[buf[i++]] + bth[buf[i++]];
}

module.exports = bytesToUuid;


/***/ }),
/* 220 */
/***/ (function(module, exports, __webpack_require__) {

var arrayMap = __webpack_require__(19),
    baseIteratee = __webpack_require__(17),
    basePickBy = __webpack_require__(77),
    getAllKeysIn = __webpack_require__(223);

/**
 * Creates an object composed of the `object` properties `predicate` returns
 * truthy for. The predicate is invoked with two arguments: (value, key).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Object
 * @param {Object} object The source object.
 * @param {Function} [predicate=_.identity] The function invoked per property.
 * @returns {Object} Returns the new object.
 * @example
 *
 * var object = { 'a': 1, 'b': '2', 'c': 3 };
 *
 * _.pickBy(object, _.isNumber);
 * // => { 'a': 1, 'c': 3 }
 */
function pickBy(object, predicate) {
  if (object == null) {
    return {};
  }
  var props = arrayMap(getAllKeysIn(object), function(prop) {
    return [prop];
  });
  predicate = baseIteratee(predicate);
  return basePickBy(object, props, function(value, path) {
    return predicate(value, path[0]);
  });
}

module.exports = pickBy;


/***/ }),
/* 221 */
/***/ (function(module, exports, __webpack_require__) {

var assignValue = __webpack_require__(222),
    castPath = __webpack_require__(25),
    isIndex = __webpack_require__(30),
    isObject = __webpack_require__(11),
    toKey = __webpack_require__(18);

/**
 * The base implementation of `_.set`.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {Array|string} path The path of the property to set.
 * @param {*} value The value to set.
 * @param {Function} [customizer] The function to customize path creation.
 * @returns {Object} Returns `object`.
 */
function baseSet(object, path, value, customizer) {
  if (!isObject(object)) {
    return object;
  }
  path = castPath(path, object);

  var index = -1,
      length = path.length,
      lastIndex = length - 1,
      nested = object;

  while (nested != null && ++index < length) {
    var key = toKey(path[index]),
        newValue = value;

    if (index != lastIndex) {
      var objValue = nested[key];
      newValue = customizer ? customizer(objValue, key, nested) : undefined;
      if (newValue === undefined) {
        newValue = isObject(objValue)
          ? objValue
          : (isIndex(path[index + 1]) ? [] : {});
      }
    }
    assignValue(nested, key, newValue);
    nested = nested[key];
  }
  return object;
}

module.exports = baseSet;


/***/ }),
/* 222 */
/***/ (function(module, exports, __webpack_require__) {

var baseAssignValue = __webpack_require__(60),
    eq = __webpack_require__(34);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Assigns `value` to `key` of `object` if the existing value is not equivalent
 * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * for equality comparisons.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function assignValue(object, key, value) {
  var objValue = object[key];
  if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) ||
      (value === undefined && !(key in object))) {
    baseAssignValue(object, key, value);
  }
}

module.exports = assignValue;


/***/ }),
/* 223 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetAllKeys = __webpack_require__(67),
    getSymbolsIn = __webpack_require__(224),
    keysIn = __webpack_require__(226);

/**
 * Creates an array of own and inherited enumerable property names and
 * symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names and symbols.
 */
function getAllKeysIn(object) {
  return baseGetAllKeys(object, keysIn, getSymbolsIn);
}

module.exports = getAllKeysIn;


/***/ }),
/* 224 */
/***/ (function(module, exports, __webpack_require__) {

var arrayPush = __webpack_require__(37),
    getPrototype = __webpack_require__(225),
    getSymbols = __webpack_require__(68),
    stubArray = __webpack_require__(69);

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeGetSymbols = Object.getOwnPropertySymbols;

/**
 * Creates an array of the own and inherited enumerable symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of symbols.
 */
var getSymbolsIn = !nativeGetSymbols ? stubArray : function(object) {
  var result = [];
  while (object) {
    arrayPush(result, getSymbols(object));
    object = getPrototype(object);
  }
  return result;
};

module.exports = getSymbolsIn;


/***/ }),
/* 225 */
/***/ (function(module, exports, __webpack_require__) {

var overArg = __webpack_require__(50);

/** Built-in value references. */
var getPrototype = overArg(Object.getPrototypeOf, Object);

module.exports = getPrototype;


/***/ }),
/* 226 */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeKeys = __webpack_require__(44),
    baseKeysIn = __webpack_require__(227),
    isArrayLike = __webpack_require__(16);

/**
 * Creates an array of the own and inherited enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keysIn(new Foo);
 * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
 */
function keysIn(object) {
  return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
}

module.exports = keysIn;


/***/ }),
/* 227 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(11),
    isPrototype = __webpack_require__(49),
    nativeKeysIn = __webpack_require__(228);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * The base implementation of `_.keysIn` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function baseKeysIn(object) {
  if (!isObject(object)) {
    return nativeKeysIn(object);
  }
  var isProto = isPrototype(object),
      result = [];

  for (var key in object) {
    if (!(key == 'constructor' && (isProto || !hasOwnProperty.call(object, key)))) {
      result.push(key);
    }
  }
  return result;
}

module.exports = baseKeysIn;


/***/ }),
/* 228 */
/***/ (function(module, exports) {

/**
 * This function is like
 * [`Object.keys`](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * except that it includes inherited enumerable properties.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function nativeKeysIn(object) {
  var result = [];
  if (object != null) {
    for (var key in Object(object)) {
      result.push(key);
    }
  }
  return result;
}

module.exports = nativeKeysIn;


/***/ }),
/* 229 */
/***/ (function(module, exports) {

module.exports = require("multer");

/***/ }),
/* 230 */
/***/ (function(module, exports) {

module.exports = require("sib-api-v3-sdk");

/***/ }),
/* 231 */
/***/ (function(module, exports, __webpack_require__) {

var buildDistanceInWordsLocale = __webpack_require__(232)
var buildFormatLocale = __webpack_require__(233)

/**
 * @category Locales
 * @summary French locale.
 * @author Jean Dupouy [@izeau]{@link https://github.com/izeau}
 * @author François B [@fbonzon]{@link https://github.com/fbonzon}
 */
module.exports = {
  distanceInWords: buildDistanceInWordsLocale(),
  format: buildFormatLocale()
}


/***/ }),
/* 232 */
/***/ (function(module, exports) {

function buildDistanceInWordsLocale () {
  var distanceInWordsLocale = {
    lessThanXSeconds: {
      one: 'moins d’une seconde',
      other: 'moins de {{count}} secondes'
    },

    xSeconds: {
      one: '1 seconde',
      other: '{{count}} secondes'
    },

    halfAMinute: '30 secondes',

    lessThanXMinutes: {
      one: 'moins d’une minute',
      other: 'moins de {{count}} minutes'
    },

    xMinutes: {
      one: '1 minute',
      other: '{{count}} minutes'
    },

    aboutXHours: {
      one: 'environ 1 heure',
      other: 'environ {{count}} heures'
    },

    xHours: {
      one: '1 heure',
      other: '{{count}} heures'
    },

    xDays: {
      one: '1 jour',
      other: '{{count}} jours'
    },

    aboutXMonths: {
      one: 'environ 1 mois',
      other: 'environ {{count}} mois'
    },

    xMonths: {
      one: '1 mois',
      other: '{{count}} mois'
    },

    aboutXYears: {
      one: 'environ 1 an',
      other: 'environ {{count}} ans'
    },

    xYears: {
      one: '1 an',
      other: '{{count}} ans'
    },

    overXYears: {
      one: 'plus d’un an',
      other: 'plus de {{count}} ans'
    },

    almostXYears: {
      one: 'presqu’un an',
      other: 'presque {{count}} ans'
    }
  }

  function localize (token, count, options) {
    options = options || {}

    var result
    if (typeof distanceInWordsLocale[token] === 'string') {
      result = distanceInWordsLocale[token]
    } else if (count === 1) {
      result = distanceInWordsLocale[token].one
    } else {
      result = distanceInWordsLocale[token].other.replace('{{count}}', count)
    }

    if (options.addSuffix) {
      if (options.comparison > 0) {
        return 'dans ' + result
      } else {
        return 'il y a ' + result
      }
    }

    return result
  }

  return {
    localize: localize
  }
}

module.exports = buildDistanceInWordsLocale


/***/ }),
/* 233 */
/***/ (function(module, exports, __webpack_require__) {

var buildFormattingTokensRegExp = __webpack_require__(234)

function buildFormatLocale () {
  var months3char = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juill.', 'août', 'sept.', 'oct.', 'nov.', 'déc.']
  var monthsFull = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre']
  var weekdays2char = ['di', 'lu', 'ma', 'me', 'je', 've', 'sa']
  var weekdays3char = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.']
  var weekdaysFull = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi']
  var meridiemUppercase = ['AM', 'PM']
  var meridiemLowercase = ['am', 'pm']
  var meridiemFull = ['du matin', 'de l’après-midi', 'du soir']

  var formatters = {
    // Month: Jan, Feb, …, Dec
    'MMM': function (date) {
      return months3char[date.getMonth()]
    },

    // Month: January, February, …, December
    'MMMM': function (date) {
      return monthsFull[date.getMonth()]
    },

    // Day of week: Su, Mo, …, Sa
    'dd': function (date) {
      return weekdays2char[date.getDay()]
    },

    // Day of week: Sun, Mon, …, Sat
    'ddd': function (date) {
      return weekdays3char[date.getDay()]
    },

    // Day of week: Sunday, Monday, …, Saturday
    'dddd': function (date) {
      return weekdaysFull[date.getDay()]
    },

    // AM, PM
    'A': function (date) {
      return (date.getHours() / 12) >= 1 ? meridiemUppercase[1] : meridiemUppercase[0]
    },

    // am, pm
    'a': function (date) {
      return (date.getHours() / 12) >= 1 ? meridiemLowercase[1] : meridiemLowercase[0]
    },

    // a.m., p.m.
    'aa': function (date) {
      var hours = date.getHours()

      if (hours <= 12) {
        return meridiemFull[0]
      }

      if (hours <= 16) {
        return meridiemFull[1]
      }

      return meridiemFull[2]
    },

    // ISO week, ordinal version: 1st, 2nd, …, 53rd
    // NOTE: Week has feminine grammatical gender in French: semaine
    'Wo': function (date, formatters) {
      return feminineOrdinal(formatters.W(date))
    }
  }

  // Generate ordinal version of formatters: M → Mo, D → Do, etc.
  // NOTE: For words with masculine grammatical gender in French: mois, jour, trimestre
  var formatterTokens = ['M', 'D', 'DDD', 'd', 'Q']
  formatterTokens.forEach(function (formatterToken) {
    formatters[formatterToken + 'o'] = function (date, formatters) {
      return masculineOrdinal(formatters[formatterToken](date))
    }
  })

  // Special case for day of month ordinals in long date format context:
  // 1er mars, 2 mars, 3 mars, …
  // See https://github.com/date-fns/date-fns/issues/437
  //
  // NOTE: The below implementation works because parsing of tokens inside a
  // format string is done by a greedy regular expression, i.e. longer tokens
  // have priority. E.g. formatter for "Do MMMM" has priority over individual
  // formatters for "Do" and "MMMM".
  var monthsTokens = ['MMM', 'MMMM']
  monthsTokens.forEach(function (monthToken) {
    formatters['Do ' + monthToken] = function (date, commonFormatters) {
      var dayOfMonthToken = date.getDate() === 1
        ? 'Do'
        : 'D'
      var dayOfMonthFormatter = formatters[dayOfMonthToken] || commonFormatters[dayOfMonthToken]

      return dayOfMonthFormatter(date, commonFormatters) + ' ' + formatters[monthToken](date)
    }
  })

  return {
    formatters: formatters,
    formattingTokensRegExp: buildFormattingTokensRegExp(formatters)
  }
}

function masculineOrdinal (number) {
  if (number === 1) {
    return '1er'
  }

  return number + 'e'
}

function feminineOrdinal (number) {
  if (number === 1) {
    return '1re'
  }

  return number + 'e'
}

module.exports = buildFormatLocale


/***/ }),
/* 234 */
/***/ (function(module, exports) {

var commonFormatterKeys = [
  'M', 'MM', 'Q', 'D', 'DD', 'DDD', 'DDDD', 'd',
  'E', 'W', 'WW', 'YY', 'YYYY', 'GG', 'GGGG',
  'H', 'HH', 'h', 'hh', 'm', 'mm',
  's', 'ss', 'S', 'SS', 'SSS',
  'Z', 'ZZ', 'X', 'x'
]

function buildFormattingTokensRegExp (formatters) {
  var formatterKeys = []
  for (var key in formatters) {
    if (formatters.hasOwnProperty(key)) {
      formatterKeys.push(key)
    }
  }

  var formattingTokens = commonFormatterKeys
    .concat(formatterKeys)
    .sort()
    .reverse()
  var formattingTokensRegExp = new RegExp(
    '(\\[[^\\[]*\\])|(\\\\)?' + '(' + formattingTokens.join('|') + '|.)', 'g'
  )

  return formattingTokensRegExp
}

module.exports = buildFormattingTokensRegExp


/***/ }),
/* 235 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const SendinBlue = __webpack_require__(42);
const Utils = __webpack_require__(3);
const {
  NODE_ENV,
  SENDINBLUE_LIST_IDS
} = __webpack_require__(2);

module.exports = function (models, Client) {
  /*
   * Those hooks are used to update Invoiceninja records when clients are updated
   * in Forest.
   */
  Client.hook('afterCreate', client => {
    if (NODE_ENV === 'test' || client.id === 'maintenance') {
      return client;
    }

    const promises = [SendinBlue.createContact(client.email, { client })];

    if (!client.ninjaId) {
      promises.push(client.ninjaCreate());
    }

    return Utils.wrapHookPromise(Promise.all(promises));
  });

  Client.hook('afterUpdate', client => {
    if (NODE_ENV === 'test') {
      return client;
    }

    if (client.changed('email')) {
      SendinBlue.getContact(client._previousDataValues.email).then(_client => {
        return Promise.all([SendinBlue.updateContact(_client.email, {
          listIds: [SENDINBLUE_LIST_IDS.archived],
          unlinkListIds: _client.listIds
        }), SendinBlue.createContact(client.email, {
          client,
          listIds: _client.listIds
        })]);
      }).catch(err => {
        if (err.response.body.code === 'document_not_found') {
          return SendinBlue.createContact(client.email, { client });
        }

        throw err;
      });
    } else {
      SendinBlue.updateContact(client.email, { client });
    }
    if (client.ninjaId && (client.changed('firstName') || client.changed('lastName') || client.changed('email'))) {
      return Utils.wrapHookPromise(client.ninjaUpdate());
    }

    return true;
  });
};

/***/ }),
/* 236 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SCOPES } = __webpack_require__(0);
const Utils = __webpack_require__(3);
const collection = __webpack_require__(237);

module.exports = (sequelize, DataTypes) => {
  const Credit = sequelize.define('Credit', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    amount: {
      type: DataTypes.INTEGER,
      required: true,
      allowNull: false
    },
    reason: {
      type: DataTypes.STRING,
      require: false
    },
    paylineId: {
      type: DataTypes.STRING
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      required: true,
      defaultValue: 'active',
      allowNull: false
    }
  }, {
    paranoid: true,
    scopes: TRASH_SCOPES
  });
  const { models } = sequelize;

  Credit.associate = () => {
    Credit.belongsTo(models.Payment, {
      constraints: false
    });
    Credit.belongsTo(models.Order, {
      constraints: false
    });

    Credit.addScope('order', {
      include: [{
        model: models.Payment
      }]
    });
  };

  Credit.collection = collection;
  Credit.routes = app => {
    Utils.addRestoreAndDestroyRoutes(app, Credit);
  };

  return Credit;
};

/***/ }),
/* 237 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SEGMENTS } = __webpack_require__(0);

module.exports = function () {
  return {
    actions: [{
      name: 'Restore Credit'
    }, {
      name: 'Destroy Credit'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 238 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Calendar = __webpack_require__(78).calendar('v3');
const Promise = __webpack_require__(1);
const jwtClient = __webpack_require__(239);
const { TRASH_SCOPES } = __webpack_require__(0);
const Utils = __webpack_require__(3);
const collection = __webpack_require__(240);
const hooks = __webpack_require__(241);

const eventsInsert = Promise.promisify(Calendar.events.insert);
const eventsUpdate = Promise.promisify(Calendar.events.update);
const eventsDelete = Promise.promisify(Calendar.events.delete);

module.exports = (sequelize, DataTypes) => {
  const { models } = sequelize;
  const Event = sequelize.define('Event', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    startDate: {
      type: DataTypes.DATE,
      required: true,
      allowNull: false
    },
    endDate: {
      type: DataTypes.DATE,
      required: true,
      allowNull: false
    },
    summary: {
      type: DataTypes.STRING,
      required: false
    },
    description: {
      type: DataTypes.STRING,
      required: false
    },
    googleEventId: {
      type: DataTypes.STRING,
      required: false
    },
    eventable: {
      type: DataTypes.STRING,
      required: true
    },
    EventableId: {
      type: DataTypes.STRING,
      required: true
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      required: true,
      allowNull: false,
      defaultValue: 'active'
    }
  }, {
    paranoid: true,
    scopes: TRASH_SCOPES
  });

  Event.associate = () => {
    Event.belongsTo(models.Renting, {
      foreignKey: 'EventableId',
      constraints: false,
      as: 'Renting'
    });
    Event.hasMany(models.Term, {
      foreignKey: 'TermableId',
      constraints: false,
      scope: { termable: 'Event' }
    });

    Event.addScope('event-category', {
      attributes: { include: [[sequelize.col('Terms.name'), 'category']] },
      include: [{
        required: false,
        model: models.Term,
        where: { taxonomy: 'event-category' }
      }]
    });
  };

  Event.prototype.googleSerialize = function () {
    const { eventable } = this;

    return models[eventable].scope(`eventable${eventable}`).findById(this.EventableId).then(eventableInstance => {
      return eventableInstance.googleSerialize(this);
    }).then(({ calendarId, resource }) => {
      return {
        auth: jwtClient,
        eventId: this.googleEventId,
        calendarId,
        resource: Object.assign({
          summary: this.summary,
          start: { dateTime: this.startDate },
          end: { dateTime: this.endDate },
          description: this.description
        }, resource)
      };
    });
  };

  Event.prototype.googleCreate = function (options) {
    return this.googleSerialize(options).then(serialized => {
      return eventsInsert(serialized);
    }).tap(googleEvent => {
      return this.set('googleEventId', googleEvent.id).save(Object.assign({}, options, { hooks: false }));
    });
  };

  Event.prototype.googleUpdate = function () {
    return this.googleSerialize().then(serialized => {
      return eventsUpdate(serialized);
    });
  };

  Event.prototype.googleDelete = function () {
    return this.googleSerialize().then(serialized => {
      return eventsDelete(serialized);
    }).then(() => {
      return this.set('googleEventId', null).save({ hook: false });
    });
  };

  Event.collection = collection;
  Event.routes = app => {
    Utils.addRestoreAndDestroyRoutes(app, Event);
  };
  Event.hooks = hooks;

  return Event;
};

/***/ }),
/* 239 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const gapis = __webpack_require__(78);
const config = __webpack_require__(2);

const scopes = ['https://www.googleapis.com/auth/calendar'];

var jwtClient = new gapis.auth.JWT(config.GOOGLE_CLIENT_EMAIL, null, config.GOOGLE_PRIVATE_KEY, scopes, null);

jwtClient.authorize(function (err) {
  if (err) {
    console.error(err);
  }
});

module.exports = jwtClient;

/***/ }),
/* 240 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SEGMENTS } = __webpack_require__(0);

module.exports = function () {
  return {
    actions: [{
      name: 'Restore Event'
    }, {
      name: 'Destroy Event'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 241 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const { NODE_ENV } = __webpack_require__(2);

module.exports = function (models, Event) {
  function wrapHookHandler(event, callback) {
    /* eslint-disable promise/no-callback-in-promise */
    return Event.scope('event-category').findById(event.id).then(callback).thenReturn(true).tapCatch(console.error);
    /* eslint-enable promise/no-callback-in-promise */
  }

  Event.hook('afterCreate', (event, options) => {
    if (NODE_ENV === 'test') {
      return event;
    }

    return wrapHookHandler(event, event => {
      return event.googleCreate(options);
    });
  });

  Event.hook('afterUpdate', (event, options) => {
    const { eventable, EventableId } = event;

    if (NODE_ENV === 'test') {
      return event;
    }

    return wrapHookHandler(event, event => {
      return Promise.all([
      // TODO: remove these non-generic scopes doing here??
      models[eventable].scope(`eventable${eventable}`, 'client', 'orderItems').findById(EventableId), event.googleEventId != null && event.googleUpdate()]).then(([eventableInstance]) => {
        return eventableInstance.handleEventUpdate && eventableInstance.handleEventUpdate(event, options);
      });
    });
  });

  Event.hook('afterDelete', event => {
    if (event.googleEventId != null) {
      return wrapHookHandler(event, event => {
        return event.googleDelete();
      });
    }

    return true;
  });

  Event.hook('afterRestore', (event, options) => {
    if (event.googleEventId != null) {
      return wrapHookHandler(event, event => {
        return event.googleCreate(options);
      });
    }

    return true;
  });
};

/***/ }),
/* 242 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Liana = __webpack_require__(5);
const makePublic = __webpack_require__(8);

module.exports = (sequelize, DataTypes) => {
  const Metadata = sequelize.define('Metadata', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    name: DataTypes.STRING,
    value: DataTypes.TEXT,
    metadatable: DataTypes.STRING,
    MetadatableId: DataTypes.STRING
  });
  const { models } = sequelize;

  Metadata.associate = () => {
    Metadata.belongsTo(models.Client, {
      foreignKey: 'MetadatableId',
      constraints: false,
      as: 'Client'
    });
  };

  Metadata.createOrUpdate = function ({ name, value, metadatable, MetadatableId }) {
    return Metadata.findOrCreate({
      where: {
        name,
        MetadatableId
      },
      defaults: {
        name,
        value,
        metadatable,
        MetadatableId
      }
    }).then(([metadata, isCreated]) => {
      if (!isCreated) {
        return metadata.update({ value });
      }
      return metadata;
    });
  };

  Metadata.routes = app => {
    const LEA = Liana.ensureAuthenticated;

    app.get('/forest/Metadata', (req, res, next) => {
      console.log(req.query);
      return req.query.filterType === 'and' && req.query.filter && req.query.filter.name === 'clientIdentity' && req.query.filter.metadatable === 'Client' ? makePublic(req, res, next) : LEA(req, res, next);
    });
  };

  return Metadata;
};

/***/ }),
/* 243 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const fetch = __webpack_require__(32);
const Ninja = __webpack_require__(41);
const {
  WORDPRESS_AJAX_URL,
  REST_API_SECRET
} = __webpack_require__(2);
const Utils = __webpack_require__(3);
const {
  TRASH_SCOPES
  // UNTRASHED_SCOPE,
} = __webpack_require__(0);
const collection = __webpack_require__(244);
const routes = __webpack_require__(245);
const hooks = __webpack_require__(247);

module.exports = (sequelize, DataTypes) => {

  const { models } = sequelize;
  const Order = sequelize.define('Order', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    type: {
      type: DataTypes.ENUM('debit', 'credit', 'deposit'),
      defaultValue: 'debit'
      // required: true,
      // allowNull: false,
    },
    receiptNumber: {
      type: DataTypes.STRING,
      unique: true
    },
    label: {
      type: DataTypes.STRING
      // required: true,
      // allowNull: false,
    },
    ninjaId: {
      type: DataTypes.INTEGER
    },
    dueDate: {
      type: DataTypes.DATEONLY,
      defaultValue: new Date()
      // required: true,
      // allowNull: false,
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      defaultValue: 'active'
      // required: true,
      // allowNull: false,
    }
  }, {
    paranoid: true,
    scopes: Object.assign({}, TRASH_SCOPES /*, UNTRASHED_SCOPE*/)
  });

  Order.associate = () => {
    Order.hasMany(models.OrderItem);
    Order.belongsTo(models.Client);
    Order.hasMany(models.Payment);
    Order.hasMany(models.Credit);
    Order.hasMany(models.Term, {
      foreignKey: 'TermableId',
      constraints: false,
      scope: { termable: 'Order' }
    });

    Order.addScope('orderItems', {
      include: [{
        model: models.OrderItem
      }]
    });

    Order.addScope('rentOrders', {
      include: [{
        model: models.OrderItem,
        where: { ProductId: 'rent' }
      }]
    });

    Order.addScope('packItems', {
      include: [{
        model: models.OrderItem,
        where: { ProductId: { $like: '%-pack' } },
        include: [{
          model: models.Renting,
          include: [{
            model: models.Room
          }]
        }]
      }]
    });

    Order.addScope('draftRentOrders', {
      include: [{
        model: models.OrderItem,
        where: {
          ProductId: 'rent',
          status: 'draft'
        },
        include: [{
          model: models.Renting
        }]
      }]
      //      paranoid: false,
    });

    Order.addScope('totalPaidRefund', {
      attributes: [[sequelize.fn('sum', sequelize.literal('`Payments`.`amount`')), 'totalPaid'], [sequelize.fn('sum', sequelize.literal('`Payments->Refunds`.`amount`')), 'totalRefund']],
      include: [{
        model: models.Payment,
        attributes: [],
        include: [{
          model: models.Credit,
          as: 'Refunds',
          attributes: []
        }]
      }]
    });

    const [unitPrice, quantity, vatRate] = 'unitPrice,quantity,vatRate'.split(',').map(col => {
      return `\`OrderItems\`.\`${col}\``;
    });

    Order.addScope('amount', {
      attributes: [[sequelize.fn('sum', sequelize.literal(`${unitPrice} * ${quantity} * ( 1 + IFNULL(${vatRate}, 0) )`)), 'amount']],
      include: [{
        model: models.OrderItem,
        attributes: []
      }],
      group: ['Order.id']
    });

    Order.addScope('invoice', {
      include: [{
        model: models.Client,
        include: [{
          model: models.Metadata,
          required: false,
          where: { name: 'clientIdentity' }
        }]
      }, {
        model: models.OrderItem,
        include: [{
          model: models.Renting,
          required: false,
          include: [{
            model: models.Room,
            include: [{
              model: models.Apartment
            }]
          }]
        }]
      }]
    });
  };

  Order.prototype.getTotalPaidAndRefund = function () {
    const option = this.deletedAt != null ? { paranoid: false } : { paranoid: true };

    return Order.scope('totalPaidRefund').findById(this.id, option).then(order => {
      return {
        totalPaid: order.get('totalPaid'),
        totalRefund: order.get('totalRefund')
      };
    });
  };

  Order.prototype.getAmount = function () {
    const option = this.deletedAt != null ? { paranoid: false } : { paranoid: true };

    return Order.scope('amount').findById(this.id, option).then(order => {
      return order.get('amount');
    });
  };
  // Return all calculated props (amount, totalPaid, balance)
  Order.prototype.getCalculatedProps = function () {
    return Promise.all([this.getTotalPaidAndRefund(), this.getAmount()]).then(([{ totalPaid, totalRefund }, amount]) => {
      return {
        amount,
        totalPaid,
        totalRefund,
        balance: totalPaid - amount - totalRefund
      };
    });
  };

  Order.prototype.findOrCreateCancelOrder = function () {
    const order = {
      type: 'credit',
      // TODO: Searching existing order based on label is unreliable.
      // We should rahter have a status:cancelled of some kind
      // (and prevent cancelling an order that has already been cancelled)
      label: `Credit Order - #${this.receiptNumber}`,
      ClientId: this.ClientId
    };

    return Order.findOrCreate({
      where: order,
      defaults: Object.assign({}, order, {
        OrderItems: this.OrderItems.map(orderItem => {
          return {
            label: orderItem.label,
            quantity: orderItem.quantity,
            unitPrice: orderItem.unitPrice * -1,
            vatRate: orderItem.vatRate,
            ProductId: orderItem.ProductId,
            RentingId: orderItem.RentingId
          };
        })
      }),
      include: [{
        model: models.OrderItem
      }]
    });
  };

  Order.prototype.pickReceiptNumber = function () {
    var settingId;
    var strNumber;

    switch (this.type) {
      case 'deposit':
        settingId = 'deposit-counter';
        strNumber = num => {
          return `deposit-${num}`;
        };
        break;
      case 'credit':
      case 'debit':
      default:
        settingId = 'invoice-counter';
        strNumber = num => {
          return num.toString();
        };
        break;
    }

    return sequelize.transaction(transaction => {
      return models.Setting.findById(settingId, { transaction }).then(counter => {
        return Promise.all([counter.increment({ transaction }), this.update({ receiptNumber: strNumber(counter.value + 1) }, { transaction })]);
      });
    }).then(() => {
      return this;
    });
  };

  Order.prototype.ninjaSerialize = function (props) {
    return Promise.all([this.getClient(), this.getCalculatedProps(), this.getOrderItems().then(orderItems => {
      return Promise.map(orderItems, item => {
        return item.ninjaSerialize();
      });
    })]).then(([client, { amount, balance }, items]) => {
      return Object.assign({
        'client_id': client.ninjaId,
        amount,
        balance,
        'invoice_items': items,
        'invoice_number': this.receiptNumber
      }, props);
    });
  };

  Order.prototype.ninjaCreate = function () {
    return this.ninjaSerialize({
      'invoice_status_id': Ninja.INVOICE_STATUS_DRAFT
    }).then(ninjaOrder => {
      return Ninja.invoice.createInvoice({
        'invoice': ninjaOrder
      });
    }).then(response => {
      this.update({
        'ninjaId': response.obj.data.id
      }, {
        hooks: false
      });
      return response.obj.data;
    });
  };

  Order.prototype.ninjaUpdate = function () {
    return this.ninjaSerialize().then(ninjaOrder => {
      return Ninja.invoice.updateInvoice({
        'invoice_id': this.ninjaId,
        'invoice': ninjaOrder
      });
    }).then(response => {
      return response.obj.data;
    });
  };

  Order.prototype.ninjaUpsert = function () {
    if (this.ninjaId != null) {
      return this.ninjaUpdate();
    }

    return Ninja.invoice.listInvoices({
      'invoice_number': this.receiptNumber,
      'per_page': 1
    }).then(response => {
      if (response.obj.data.length) {
        this.set('ninjaId', response.obj.data[0].id).save({ hooks: false });
        return this.ninjaUpdate();
      }

      return this.ninjaCreate();
    });
  };

  Order.ninjaCreateInvoices = orders => {
    return Promise.filter(orders, order => {
      return order.ninjaId == null && order.amount !== 0;
    }).mapSeries(order => {
      return order.receiptNumber ? order : order.pickReceiptNumber();
    }).mapSeries(order => {
      return order.ninjaCreate();
    });
  };

  // This is an alternative to Order.findOrCreate, to use when the only thing
  // we're interested in is the existence of the orderItem
  Order.findItemOrCreate = function ({ where, defaults, include }) {
    return sequelize.transaction(transaction => {
      return models.OrderItem.findAll({
        where,
        include,
        transaction
      }).then(orderItems => {
        return Promise.all(orderItems.length ? [Order.findById(orderItems[0].OrderId), false] : [Order.create(defaults, {
          include: [models.OrderItem],
          transaction
        }), true]);
      });
    });
  };

  Order.prototype.markAsPaid = function () {
    return Order.markAsPaid(this);
  };
  Order.markAsPaid = function (order) {
    return Promise.all([
    // Switch order status from draft to active
    order.update({ status: 'active', deletedAt: null }),
    // Switch renting status from draft to active
    order.OrderItems && order.OrderItems[0] && models.Renting.update({ status: 'active', deletedAt: null }, { where: { id: order.OrderItems[0].RentingId } }), models.Client.update({ status: 'active', deletedAt: null }, { where: { id: order.ClientId } }), models.Order.update({ status: 'active', deletedAt: null }, { where: { ClientId: order.ClientId } }),
    // Mark renting as unavailable in WordPress
    order.OrderItems && order.OrderItems[0] && fetch(WORDPRESS_AJAX_URL, {
      method: 'post',
      body: {
        action: 'update_availability',
        privateKey: REST_API_SECRET,
        reference: order.OrderItems[0].Renting.Room.reference,
        meta: '20300901'
      }
    })]);
  };

  Order.afterUpdate = order => {
    // No need to prevent ninja update when NODE_ENV === 'test', as ninjaId == null
    if (order.ninjaId != null) {
      return Utils.wrapHookPromise(order.ninjaUpdate());
    }

    return true;
  };

  Order.collection = collection;
  Order.routes = routes;
  Order.hooks = hooks;

  return Order;
};

/***/ }),
/* 244 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const {
  TRASH_SEGMENTS,
  INVOICENINJA_URL
} = __webpack_require__(0);
const Utils = __webpack_require__(3);

module.exports = function ({ Order }) {
  const memoizer = new Utils.calculatedPropsMemoizer(Order);

  return {
    fields: [{
      field: 'amount',
      type: 'Number',
      get(object) {
        return memoizer.getCalculatedProps(object).then(result => {
          return result.amount;
        });
      }
    }, {
      field: 'totalPaid',
      type: 'Number',
      get(object) {
        return memoizer.getCalculatedProps(object).then(result => {
          return result.totalPaid;
        });
      }
    }, {
      field: 'balance',
      type: 'Number',
      get(object) {
        return memoizer.getCalculatedProps(object).then(result => {
          return result.balance;
        });
      }
    }, {
      field: 'totalRefund',
      type: 'Number',
      get(object) {
        return memoizer.getCalculatedProps(object).then(result => {
          return result.totalRefund;
        });
      }
    }, {
      field: 'invoice',
      type: 'String',
      get(object) {
        if (object.ninjaId !== null) {
          return `${INVOICENINJA_URL}/invoices/${object.ninjaId}/edit`;
        }

        return null;
      }
    }, {
      field: 'Refunds',
      type: ['String'],
      reference: 'Credit.id'
    }],
    actions: [{
      name: 'Generate Invoice'
    }, {
      name: 'Restore Order'
    }, {
      name: 'Destroy Order'
    }, {
      name: 'Cancel Invoice'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 245 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Liana = __webpack_require__(5);
const Promise = __webpack_require__(1);
const Chromeless = __webpack_require__(79);
const makePublic = __webpack_require__(8);
const checkToken = __webpack_require__(80);
const Utils = __webpack_require__(3);
const {
  destroySuccessHandler
} = __webpack_require__(55);

const Serializer = Liana.ResourceSerializer;

module.exports = (app, models, Order) => {
  const LEA = Liana.ensureAuthenticated;
  const rInvoiceUrl = /https:\/\/payment\.chez-nestor\.com\/invoices\/(\d+)/;

  // Make this route completely public
  app.get('/forest/Order/:orderId', makePublic);

  // TODO: find out why, when throwing in that route, we get an
  // "cannot send headers" error in the console, and no error displayed in
  // Forest
  app.delete('/forest/Order/:orderId', LEA, (req, res) => {
    return Order.findById(req.params.orderId).then(order => {
      return Promise.all([order, order.getCalculatedProps()]);
    }).then(([order, { totalPaid }]) => {
      if (totalPaid != null) {
        throw new Error('This order is partially/fully paid');
      }
      return order.destroy();
    }).then(destroySuccessHandler(res, 'Order')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/generate-invoice', LEA, (req, res) => {
    return Order.findAll({ where: { id: { $in: req.body.data.attributes.ids } }
    }).then(orders => {
      return Order.ninjaCreateInvoices(orders);
    }).then(Utils.createSuccessHandler(res, 'Ninja invoice')).catch(Utils.logAndSend(res));
  });

  app.get('/forest/Invoice/:orderId', makePublic, (req, res) => {
    return Order.scope('invoice').findById(req.params.orderId).then(order => {
      return Promise.all([order.toJSON(), order.getCalculatedProps()]);
    }).then(([order, calculatedProps]) => {
      return res.send(Object.assign(order, calculatedProps));
    }).catch(Utils.logAndSend(res));
  });

  app.get('/forest/actions/pdf-invoice/:filename', makePublic, (req, res) => {
    const { lang, orderId } = req.query;

    console.log(lang, orderId);
    return Chromeless.invoiceAsPdf(orderId, lang).then(pdf => {
      return res.redirect(pdf);
    });
  });

  app.post('/forest/actions/payment-notification', checkToken, (req, res) => {
    const ninjaId = rInvoiceUrl.exec(req.body.message);

    if (!ninjaId || !ninjaId[1]) {
      return res.status(502).send('Invalid request');
    }

    return Order.scope('packItems').findOne({ where: { ninjaId: ninjaId[1] } }).then(order => {
      if (!order) {
        throw new Error(`No order found for the NinjaId ${ninjaId[1]}`);
      }

      return order.markAsPaid();
    }).then(Utils.createSuccessHandler(res, 'Payment Notification')).catch(Utils.logAndSend(res));
  });

  app.get('/forest/Order/:orderId/relationships/Refunds', LEA, (req, res) => {
    return models.Credit.scope('order').findAll({ where: { '$Payment.OrderId$': req.params.orderId } }).then(credits => {
      return new Serializer(Liana, models.Credit, credits, {}, {
        count: credits.length
      }).perform();
    }).then(result => {
      return res.send(result);
    }).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/cancel-invoice', LEA, (req, res) => {
    const { ids } = req.body.data.attributes;

    return Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t cancel multiple orders');
      }
      return Order.scope('orderItems').findById(ids[0]);
    }).then(order => {
      if (!order.receiptNumber) {
        throw new Error('This order is a draft and should be deleted instead.');
      }
      if (order.type !== 'debit') {
        throw new Error(`Only debit orders can be cancelled (found ${order.type})`);
      }
      return order.findOrCreateCancelOrder();
    }).then(Utils.findOrCreateSuccessHandler(res, 'Cancel invoice')).catch(Utils.logAndSend(res));
  });

  Utils.addRestoreAndDestroyRoutes(app, Order);
};

/***/ }),
/* 246 */
/***/ (function(module, exports) {

module.exports = require("chromeless");

/***/ }),
/* 247 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (models, Order) {
  //  Order.hook('beforeCreate', (order) => {
  //    if ( order.status !== 'active' ) {
  //      order.setDataValue('deletedAt', new Date());
  //    /}
  //  });

  Order.hook('afterUpdate', Order.afterUpdate);

  Order.hook('beforeDelete', order => {
    const isDeleted = order.deletedAt != null;

    return order.getOrderItems({ paranoid: !isDeleted }).map(orderItem => {
      return orderItem.destroy({ force: isDeleted });
    });
  });

  Order.hook('afterRestore', order => {
    return order.getOrderItems().filter(orderItem => {
      return orderItem.deletedAt != null;
    }).map(orderItem => {
      return orderItem.set('status', 'active').restore();
    });
  });
};

/***/ }),
/* 248 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const {
  TRASH_SCOPES
  // UNTRASHED_SCOPE,
} = __webpack_require__(0);
const collection = __webpack_require__(249);
const routes = __webpack_require__(250);
const hooks = __webpack_require__(251);

module.exports = (sequelize, DataTypes) => {
  const OrderItem = sequelize.define('OrderItem', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    label: {
      type: DataTypes.STRING,
      required: true,
      allowNull: false
    },
    quantity: {
      type: DataTypes.FLOAT, // can be a fraction
      defaultValue: 1,
      required: false
    },
    unitPrice: {
      type: DataTypes.INTEGER,
      required: false
    },
    vatRate: {
      type: DataTypes.ENUM('0', '0.2'),
      defaultValue: '0',
      // required: true,
      // allowNull: false,
      get() {
        return parseFloat(this.getDataValue('vatRate'));
      }
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      defaultValue: 'active'
      // required: true,
      // allowNull: false,
    }
  }, {
    paranoid: true,
    scopes: Object.assign({}, TRASH_SCOPES /*, UNTRASHED_SCOPE*/)
  });
  const { models } = sequelize;

  OrderItem.associate = () => {
    OrderItem.belongsTo(models.Order);
    OrderItem.belongsTo(models.Renting, {
      constraints: false
    });
    OrderItem.belongsTo(models.Product, {
      constraints: false
    });
    OrderItem.hasMany(models.Term, {
      foreignKey: 'TermableId',
      constraints: false,
      scope: { termable: 'OrderItem' }
    });
  };

  OrderItem.prototype.createDiscount = function (amount) {
    return OrderItem.create({
      label: 'Discount',
      unitPrice: -1 * amount,
      status: this.status,
      RentingId: this.RentingId,
      ProductId: this.ProductId,
      OrderId: this.OrderId
    });
  };

  OrderItem.prototype.ninjaSerialize = function () {
    return Promise.resolve({
      'product_key': this.label,
      'cost': this.unitPrice / 100,
      'qty': this.quantity,
      'notes': '' // Updating orders on InvoiceNinja will fail without this
    });
  };

  OrderItem.collection = collection;
  OrderItem.routes = routes;
  OrderItem.hooks = hooks;

  return OrderItem;
};

/***/ }),
/* 249 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SEGMENTS } = __webpack_require__(0);

module.exports = function () {
  return {
    actions: [{
      name: 'Add Discount',
      fields: [{
        field: 'discount',
        type: 'Number'
      }]
    }, {
      name: 'Restore OrderItem'
    }, {
      name: 'Destroy OrderItem'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 250 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const Liana = __webpack_require__(5);
const makePublic = __webpack_require__(8);
const Utils = __webpack_require__(3);

module.exports = function (app, models, OrderItem) {
  const LEA = Liana.ensureAuthenticated;

  // Make retrieving OrderItems and associated Orders by OrderId or rentingId
  // public
  app.get('/forest/OrderItem', (req, res, next) => {
    return req.query.filterType === 'and' && /(Renting|Order)Id/.test(Object.keys(req.query.filter).join('')) ? makePublic(req, res, next) : LEA(req, res, next);
  });

  app.post('/forest/actions/add-discount', LEA, (req, res) => {
    const { ids, values } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple discounts');
      }

      return OrderItem.findById(ids[0]);
    }).then(orderItem => {
      return orderItem.createDiscount(100 * values.discount);
    }).then(() => {
      return res.status(200).send({ success: 'Discount created' });
    }).catch(Utils.logAndSend(res));
  });

  Utils.addRestoreAndDestroyRoutes(app, OrderItem);
};

/***/ }),
/* 251 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (models, OrderItem) {
  //  OrderItem.hook('beforeCreate', (orderItem) => {
  //    if ( orderItem.status !== 'active' ) {
  //      orderItem.setDataValue('deletedAt', new Date());
  //    }
  //  });

  // Run Order's afterUpdate hook when an orderItem is updated
  ['afterCreate', 'afterUpdate', 'afterDelete'].forEach(hookName => {
    OrderItem.hook(hookName, (orderItem, { transaction }) => {
      if (orderItem.OrderId) {
        return orderItem.getOrder({ transaction }).then(models.Order.afterUpdate);
      }
      return null;
    });
  });
};

/***/ }),
/* 252 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const payline = __webpack_require__(27);
const { TRASH_SCOPES } = __webpack_require__(0);
const collection = __webpack_require__(253);
const routes = __webpack_require__(254);

module.exports = (sequelize, DataTypes) => {
  const Payment = sequelize.define('Payment', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    type: {
      type: DataTypes.ENUM('card', 'sepa', 'manual'),
      required: true,
      defaultValue: 'card',
      allowNull: false
    },
    amount: {
      type: DataTypes.INTEGER,
      required: true,
      allowNull: false
    },
    paylineId: {
      type: DataTypes.STRING
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      required: true,
      defaultValue: 'active',
      allowNull: false
    }
  }, {
    paranoid: true,
    scopes: TRASH_SCOPES
  });
  const { models } = sequelize;

  Payment.associate = () => {
    Payment.belongsTo(models.Order);
    Payment.hasMany(models.Credit, {
      as: 'Refunds'
    });
  };

  Payment.paylineRefund = (id, values) => {
    const { Credit } = models;

    return Payment.findById(id).then(payment => {
      if (payment.paylineId == null) {
        throw new Error('This payment can\'t be refund online');
      }
      return payline.doRefund(payment.paylineId, values.amount);
    }).then(result => {
      return Credit.create({
        amount: values.amount,
        reason: values.reason,
        paylineId: result.transactionId,
        PaymentId: id
      });
    });
  };

  Payment.collection = collection;
  Payment.routes = routes;

  return Payment;
};

/***/ }),
/* 253 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SEGMENTS } = __webpack_require__(0);

module.exports = function () {
  return {
    actions: [{
      name: 'Refund',
      fields: [{
        field: 'amount',
        type: 'Number',
        description: 'required'
      }, {
        field: 'reason',
        type: 'String'
      }]
    }, {
      name: 'Restore Payment'
    }, {
      name: 'Destroy Payment'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 254 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const uuid = __webpack_require__(76);
const Liana = __webpack_require__(5);
const Promise = __webpack_require__(1);
const payline = __webpack_require__(27);
const Utils = __webpack_require__(3);
const makePublic = __webpack_require__(8);

module.exports = function (app, models, Payment) {
  const LEA = Liana.ensureAuthenticated;

  app.post('/forest/actions/refund', LEA, (req, res) => {
    var { values, ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (!values.amount) {
        throw new Error('Please specify an amount');
      }
      if (ids.length > 1) {
        throw new Error('Can\'t refund multiple payments');
      }

      values.amount *= 100;

      return Payment.paylineRefund(ids[0], values);
    }).then(() => {
      return res.send({ success: 'Payment Successfully Refund' });
    }).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/public/create-payment', makePublic, (req, res) => {
    const {
      cardNumber: number,
      holderName: holder,
      expiryMonth,
      expiryYear,
      cvv: cvx,
      orderId
    } = req.body;

    const rVisa = /^4[0-9]{12}(?:[0-9]{3})?$/;
    const rMastercard = /^(?:5[1-5][\d]{2}|222[1-9]|22[3-9][\d]|2[3-6][\d]{2}|27[01][\d]|2720)[\d]{12}$/;
    let type;

    if (number.match(rVisa)) {
      type = 'visa';
    } else if (number.match(rMastercard)) {
      type = 'mastercard';
    }

    Promise.resolve().then(() => {
      if (!type) {
        throw new Error('Invalid Card Type');
      }

      return Promise.all([models.Order.scope('orderItems').findById(orderId), models.Order.scope('packItems').findById(orderId)]);
    }).then(([order, packOrder]) => {
      if (!order) {
        throw new Error(`Order "${orderId}" not found`);
      }

      if (packOrder) {
        /* eslint-disable promise/no-nesting */
        return models.Room.scope('availableAt').findById(packOrder.OrderItems[0].Renting.RoomId).then(isAvailable => {
          if (isAvailable && isAvailable.availableAt > Date.now()) {
            throw new Error('This room is no longer available.');
          }
          return order;
        });
        /* eslint-enable promise/no-nesting */
      }

      return order;
    }).then(order => {
      return order.getCalculatedProps();
    }).then(({ balance }) => {
      if (balance >= 0) {
        throw new Error('Order is already fully paid.');
      }

      return Promise.all([payline.doPurchase(uuid(), {
        number,
        type,
        expirationDate: expiryMonth + expiryYear,
        holder,
        cvx
      }, -balance), -balance]);
    }).then(([{ transactionId }, amount]) => {
      return Promise.all([models.Payment.create({
        type: 'card',
        amount,
        paylineId: transactionId,
        OrderId: orderId
      }), models.Order.scope('packItems').findById(orderId)]);
    }).then(([payment, packOrder]) => {
      if (packOrder) {
        packOrder.markAsPaid();
      }
      return res.send({ paymentId: payment.id });
    }).catch(e => {
      console.error(e);
    });
  });

  Utils.addRestoreAndDestroyRoutes(app, Payment);
};

/***/ }),
/* 255 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const routes = __webpack_require__(256);
const hooks = __webpack_require__(257);

module.exports = (sequelize, DataTypes) => {
  const { models } = sequelize;
  const Picture = sequelize.define('Picture', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    url: {
      type: DataTypes.STRING,
      allowNull: false
    },
    PicturableId: {
      type: DataTypes.STRING
    },
    alt: DataTypes.STRING,
    picturable: {
      type: DataTypes.STRING,
      required: true,
      allowNull: false
    },
    order: DataTypes.INTEGER
  });

  Picture.associate = () => {
    Picture.belongsTo(models.Apartment, {
      foreignKey: 'PicturableId',
      constraints: false,
      as: 'Apartment'
    });
    Picture.belongsTo(models.Room, {
      foreignKey: 'PicturableId',
      constraints: false,
      as: 'Room'
    });
  };

  Picture.routes = routes;
  Picture.hooks = hooks;

  return Picture;
};

/***/ }),
/* 256 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Liana = __webpack_require__(5);
const Aws = __webpack_require__(20);
const Utils = __webpack_require__(3);

module.exports = app => {
  const LEA = Liana.ensureAuthenticated;

  app.put('/forest/Picture/:pictureId', LEA, (req, res, next) => {
    const { url } = req.body.data.attributes;

    if (url) {
      return Aws.uploadPicture({
        id: req.params.pictureId,
        url
      }).then(AWSurl => {
        req.body.data.attributes.url = AWSurl;
        /* eslint-disable promise/no-callback-in-promise */
        return next();
        /* eslint-enable promise/no-callback-in-promise */
      }).catch(Utils.logAndSend(res));
    }

    return next();
  });
};

/***/ }),
/* 257 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Aws = __webpack_require__(20);
const config = __webpack_require__(2);

module.exports = function (models, Picture) {
  Picture.hook('beforeCreate', picture => {
    if (config.NODE_ENV === 'test') {
      return picture;
    }

    return Aws.uploadPicture(picture).then(url => {
      return picture.url = url;
    });
  });

  Picture.hook('beforeDelete', picture => {
    if (config.NODE_ENV === 'test') {
      return picture;
    }

    return Aws.deleteFile(config.AWS_BUCKET_PICTURES, {
      Key: picture.id
    });
  });
};

/***/ }),
/* 258 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SCOPES } = __webpack_require__(0);
const Utils = __webpack_require__(3);
const collection = __webpack_require__(259);

module.exports = (sequelize, DataTypes) => {
  const Product = sequelize.define('Product', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    name: {
      type: DataTypes.STRING,
      required: true,
      allowNull: false
    },
    price: {
      type: DataTypes.INTEGER,
      required: false
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      required: true,
      defaultValue: 'active',
      allowNull: false
    }
  }, {
    paranoid: true,
    scopes: TRASH_SCOPES
  });
  const { models } = sequelize;

  Product.associate = () => {
    Product.hasMany(models.OrderItem);
  };

  Product.collection = collection;
  Product.routes = app => {
    Utils.addRestoreAndDestroyRoutes(app, Product);
  };

  return Product;
};

/***/ }),
/* 259 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const { TRASH_SEGMENTS } = __webpack_require__(0);

module.exports = function () {
  return {
    actions: [{
      name: 'Restore Product'
    }, {
      name: 'Destroy Product'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 260 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const D = __webpack_require__(4);
const capitalize = __webpack_require__(10);
const values = __webpack_require__(28);
const webmerge = __webpack_require__(81);
const Utils = __webpack_require__(3);
const {
  TRASH_SCOPES,
  // UNTRASHED_SCOPE,
  DEPOSIT_PRICES,
  DEPOSIT_REFUND_DELAYS,
  TWO_OCCUPANTS_FEES
} = __webpack_require__(0);
const { GOOGLE_CALENDAR_IDS } = __webpack_require__(2);
const routes = __webpack_require__(262);
const hooks = __webpack_require__(275);
const collection = __webpack_require__(276);

const _ = { capitalize, values };

// TODO: for some reason sqlite seems to return a date in a strange format
// find out why and fix this.
function checkinoutDateGetter(type) {
  return function () {
    /* eslint-disable no-invalid-this */
    const date = this.dataValues[`${type}Date`];
    /* eslint-enable no-invalid-this */

    return date == null || typeof date == 'object' ? date : Utils.parseDBDate(date);
  };
}

module.exports = (sequelize, DataTypes) => {
  const { models } = sequelize;
  const Renting = sequelize.define('Renting', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    bookingDate: {
      type: DataTypes.DATE,
      required: false,
      validate: {
        isRoomAvailable(date) {
          return models.Room.scope('availableAt').findById(this.RoomId).then(room => {
            return room.checkAvailability(date);
          }).then(isAvailable => {
            if (!isAvailable) {
              throw new Error('The room is already booked');
            }
            return isAvailable;
          });
        }
      }
    },
    expectedCheckoutDate: {
      type: DataTypes.DATE,
      required: false
    },
    price: {
      type: DataTypes.INTEGER
      // required: true,
      // allowNull: false,
    },
    serviceFees: {
      type: DataTypes.INTEGER
      // required: true,
      // allowNull: false,
    },
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      defaultValue: 'draft'
      // required: true,
      // allowNull: false,
    },
    comfortLevel: {
      type: DataTypes.VIRTUAL
    },
    packDiscount: {
      type: DataTypes.VIRTUAL(DataTypes.INTEGER)
    },
    hasTwoOccupants: {
      type: DataTypes.VIRTUAL(DataTypes.BOOLEAN),
      defaultValue: false
    },
    checkinDate: {
      type: DataTypes.VIRTUAL(DataTypes.DATE),
      get: checkinoutDateGetter('checkin')
    },
    checkoutDate: {
      type: DataTypes.VIRTUAL(DataTypes.DATE),
      get: checkinoutDateGetter('checkout')
    }
  }, {
    paranoid: true,
    scopes: Object.assign({}, TRASH_SCOPES /*, UNTRASHED_SCOPE*/)
  });

  Renting.associate = () => {
    Renting.belongsTo(models.Client);
    Renting.belongsTo(models.Room);
    Renting.hasMany(models.OrderItem);
    Renting.hasMany(models.Event, {
      foreignKey: 'EventableId',
      constraints: false,
      scope: { eventable: 'Renting' }
    });
    Renting.hasMany(models.Term, {
      foreignKey: 'TermableId',
      constraints: false,
      scope: { termable: 'Renting' }
    });

    // checkinDate, checkoutDate, checkinEvent, checkoutEvent scopes
    ['checkin', 'checkout'].forEach(type => {
      Renting.addScope(`${type}Date`, {
        attributes: { include: [[sequelize.col('Events.startDate'), `${type}Date`]] },
        include: [{
          model: models.Event,
          required: false,
          include: [{
            model: models.Term,
            where: {
              taxonomy: 'event-category',
              name: type
            }
          }]
        }]
      });
    });

    Renting.addScope('depositOption', {
      include: [{
        required: false,
        model: models.Term,
        where: { taxonomy: 'deposit-option' }
      }]
    });

    Renting.addScope('comfortLevel', {
      attributes: { include: [[sequelize.fn('replace', sequelize.col('ProductId'), '-pack', ''), 'comfortLevel']] },
      include: [{
        model: models.OrderItem,
        required: false,
        where: { ProductId: { $like: '%-pack' } }
      }]
    });

    Renting.addScope('room+apartment', {
      include: [{
        model: models.Room,
        include: [{
          model: models.Apartment
        }]
      }]
    });

    Renting.addScope('client', {
      include: [{
        model: models.Client
      }]
    });

    Renting.addScope('room', {
      include: [{
        model: models.Room
      }]
    });

    Renting.addScope('client+identity', {
      include: [{
        model: models.Client,
        include: [{
          required: false,
          model: models.Metadata,
          where: { name: 'clientIdentity' },
          limit: 1
        }]
      }]
    });

    Renting.addScope('client+paymentDelay', {
      include: [{
        model: models.Client,
        include: [{
          required: false,
          model: models.Metadata,
          where: { name: 'payment-delay' }
        }]
      }]
    });
  };

  // Prorate the price and service fees of a renting for a given month
  Renting.prorate = function (renting, date) {
    const { bookingDate, price, serviceFees } = renting;
    const checkoutDate = renting.get('checkoutDate');
    const daysInMonth = D.getDaysInMonth(date);
    const startOfMonth = D.startOfMonth(date);
    const endOfMonth = D.endOfMonth(date);
    let daysStayed = daysInMonth;

    if (bookingDate > endOfMonth || checkoutDate != null && checkoutDate < startOfMonth) {
      daysStayed = 0;
    } else {
      if (bookingDate >= startOfMonth) {
        daysStayed -= D.getDate(bookingDate) - 1;
      }
      if (checkoutDate != null && checkoutDate < endOfMonth) {
        daysStayed -= daysInMonth - D.getDate(checkoutDate);
      }
    }

    return {
      price: Utils.roundBy100(price / daysInMonth * daysStayed),
      serviceFees: Utils.roundBy100(serviceFees / daysInMonth * daysStayed)
    };
  };
  Renting.prototype.prorate = function (date) {
    return Renting.prorate(this, date);
  };

  // Propagate the status of the renting to that of first-rent/deposit/pack orders
  // and their orderItems
  Renting.prototype.normalizeOrder = function (order) {
    if (order.OrderItems != null) {
      order.OrderItems = order.OrderItems.map(item => {
        return Object.assign({
          status: this.status,
          deletedAt: this.deletedAt
        }, item);
      });
    }

    return Object.assign({
      type: 'debit',
      ClientId: this.ClientId,
      // We want the order to be a draft if the renting is a draft
      status: this.status,
      deletedAt: this.deletedAt
    }, order);
  };

  Renting.prototype.toOrderItems = function ({ date = new Date(), room = this.Room }) {
    const prorated = this.prorate(date);
    const apartment = room.Apartment;
    const month = D.format(date, 'MMMM');

    return [{
      label: `Loyer ${month} - Chambre #${room.reference}`,
      unitPrice: prorated.price,
      RentingId: this.id,
      status: this.status,
      ProductId: 'rent'
    }, {
      label: `Charges ${month} - Apt #${apartment.reference}`,
      unitPrice: prorated.serviceFees,
      RentingId: this.id,
      status: this.status,
      ProductId: 'service-fees'
    }];
  };

  Renting.findOrphanOrderItems = function (rentings, order) {
    return Promise.map(rentings, renting => {
      return models.OrderItem.findAll({
        where: {
          RentingId: renting.id,
          status: 'draft',
          OrderId: null
        },
        include: [{
          model: models.Term,
          where: {
            name: 'Next Rent Invoice',
            taxonomy: 'orderItem-category',
            termable: 'OrderItem'
          }
        }]
      }).map(orderItem => {
        return orderItem.update({
          status: renting.status,
          OrderId: order.id
        });
      });
    });
  };

  Renting.prototype.findOrCreateRentOrder = function (args) {
    const { date = new Date(), room, number } = args;

    return models.Order.findItemOrCreate({
      where: {
        RentingId: this.id,
        ProductId: 'rent'
      },
      include: [{
        model: models.Order,
        where: { dueDate: Math.max(new Date(), this.Client.Metadata.length ? D.addDays(D.startOfMonth(date), this.Client.Metadata[0].value) : D.startOfMonth(date)) }
      }],
      defaults: this.normalizeOrder({
        label: `${D.format(date, 'MMMM')} Invoice`,
        dueDate: Math.max(new Date(), this.Client.Metadata.length ? D.addDays(D.startOfMonth(date), this.Client.Metadata[0].value) : D.startOfMonth(date)),
        OrderItems: this.toOrderItems({ date, room }),
        number
      })
    });
  };

  Renting.prototype.findOrCreatePackOrder = function (args) {
    const { comfortLevel, discount, number, room = this.Room } = args;
    const { addressCity } = room.Apartment;
    const ProductId = `${comfortLevel}-pack`;

    return Utils.getPackPrice(addressCity, comfortLevel).then(packPrice => {
      return models.Order.findItemOrCreate({
        where: {
          RentingId: this.id,
          ProductId: {
            $like: '%-pack'
          }
        },
        defaults: this.normalizeOrder({
          label: 'Housing Pack',
          dueDate: Math.max(new Date(), D.startOfMonth(this.bookingDate)),
          OrderItems: [{
            label: `Housing Pack ${addressCity} ${comfortLevel}`,
            unitPrice: packPrice,
            RentingId: this.id,
            status: this.status,
            ProductId
          }, discount != null && discount !== 0 && {
            label: 'Discount',
            unitPrice: -1 * discount,
            RentingId: this.id,
            status: this.status,
            ProductId
          }].filter(Boolean),
          number
        })
      });
    });
  };

  Renting.prototype.findOrCreateDepositOrder = function (args) {
    const { room = this.Room, number } = args;
    const { addressCity } = room.Apartment;
    const ProductId = `${addressCity}-deposit`;

    return models.Order.findItemOrCreate({
      where: {
        RentingId: this.id,
        ProductId
      },
      defaults: this.normalizeOrder({
        type: 'deposit',
        status: 'draft',
        label: 'Deposit',
        OrderItems: [{
          label: 'Deposit',
          unitPrice: DEPOSIT_PRICES[addressCity],
          RentingId: this.id,
          status: this.status,
          ProductId
        }],
        number
      })
    });
  };

  // this function finds or creates checkin and checkout Order,
  // if it's a checkout order, it also creates a refund event
  ['checkin', 'checkout'].forEach(type => {
    Renting.prototype[`findOrCreate${_.capitalize(type)}Order`] = function (number) {
      const { name } = this.Room;
      const { Apartment } = this.Room;

      return Promise.all([Utils[`get${_.capitalize(type)}Price`](this.get(`${type}Date`), this.get('comfortLevel'), Apartment.addressCity), Utils.getLateNoticeFees(type, this.get(`${type}Date`))]).then(([price, lateNoticeFees]) => {
        const ProductId = `special-${type}`;
        const items = [{
          label: `${price !== 0 ? 'Special' : 'Free'} ${type}`,
          unitPrice: price,
          RentingId: this.id,
          ProductId
        }, lateNoticeFees !== 0 && {
          label: `Late notice ${name}`,
          unitPrice: lateNoticeFees,
          RentingId: this.id,
          ProductId: 'late-notice'
        }].filter(Boolean);

        return models.Order.findItemOrCreate({
          where: {
            RentingId: this.id,
            ProductId
          },
          defaults: {
            type: 'debit',
            label: _.capitalize(type),
            ClientId: this.ClientId,
            OrderItems: items,
            number
          }
        });
      });
    };
  });

  Renting.prototype.createRoomSwitchOrder = function ({ discount }, number) {
    const comfortLevel = this.get('comfortLevel');

    return models.Client.scope('roomSwitchCount').findById(this.ClientId).then(client => {
      return Utils.getRoomSwitchPrice(client.get('roomSwitchCount'), comfortLevel);
    }).then(price => {
      const items = [price !== 0 && {
        label: `Room switch ${comfortLevel}`,
        unitPrice: price,
        ProductId: 'room-switch'
      }, discount != null && discount !== 0 && {
        label: 'Discount',
        unitPrice: -1 * discount,
        ProductId: 'room-switch'
      }].filter(Boolean);

      return models.Order.create({
        type: 'debit',
        label: items.length > 0 ? 'Room switch' : 'Free Room switch',
        ClientId: this.ClientId,
        OrderItems: items.length > 0 ? items : [{
          label: `Room switch ${comfortLevel})`,
          unitPrice: 0,
          ProductId: 'room-switch'
        }],
        number
      }, { include: [models.OrderItem] });
    });
  };

  Renting.prototype.createOrUpdateRefundEvent = function (date) {
    const { name } = this.Room;
    const { firstName, lastName } = this.Client;
    const startDate = D.addDays(date, DEPOSIT_REFUND_DELAYS[this.get('comfortLevel')]);
    const category = 'refund-deposit';

    return sequelize.transaction(transaction => {
      return models.Event.scope('event-category').findOne({
        where: {
          EventableId: this.id,
          category
        },
        transaction
      }).then(event => {
        if (event) {
          return event.update({ startDate, endDate: startDate }, transaction);
        }

        return models.Event.create({
          startDate,
          endDate: startDate,
          summary: `Refund deposit ${firstName} ${lastName}`,
          description: `${name}`,
          eventable: 'Renting',
          EventableId: this.id,
          Terms: [{
            name: 'refund-deposit',
            taxonomy: 'event-category',
            termable: 'Event'
          }]
        }, { transaction });
      });
    });
  };

  // #findOrCreateCheckinEvent and #findOrCreateCheckoutEvent
  ['checkin', 'checkout'].forEach(type => {
    Renting[`findOrCreate${_.capitalize(type)}Event`] = function (args) {
      const { startDate, renting, client, room, transaction, hooks } = args;
      const { firstName, lastName, phoneNumber } = client;
      const term = {
        name: type,
        taxonomy: 'event-category',
        termable: 'Event'
      };

      return Utils[`get${_.capitalize(type)}EndDate`](startDate).then(endDate => {
        return models.Event.findOrCreate({
          where: {
            EventableId: renting.id
          },
          include: [{
            model: models.Term,
            where: term
          }],
          defaults: {
            startDate,
            endDate,
            summary: `${type} ${firstName} ${lastName}`,
            description: Utils.stripIndent(`\
                ${firstName} ${lastName},
                ${room.name},
                tel: ${phoneNumber || 'N/A'}\
              `),
            eventable: 'Renting',
            EventableId: renting.id,
            Terms: [term]
          },
          transaction,
          hooks
        });
      });
    };

    Renting.prototype[`findOrCreate${_.capitalize(type)}Event`] = function (startDate, { transaction, hooks }) {
      return Renting[`findOrCreate${_.capitalize(type)}Event`]({
        renting: this,
        client: this.Client,
        room: this.Room,
        startDate,
        transaction,
        hooks
      });
    };
  });

  Renting.prototype.changeDepositOption = function (option) {
    return models.Term.build({
      taxonomy: 'deposit-option',
      termable: 'Renting',
      TermableId: this.id
    }, { isNewRecord: false }).createOrUpdate(option === 'cash deposit' ? 'cash' : 'do-not-cash');
  };

  Renting.prototype.googleSerialize = function (event) {
    const { Apartment } = this.Room;
    const isRefundDeposit = event.get('category') === 'refund-deposit';

    return {
      calendarId: GOOGLE_CALENDAR_IDS[isRefundDeposit ? 'refund-deposit' : Apartment.addressCity],
      resource: isRefundDeposit && {
        location: Utils.toSingleLine(`
          ${Apartment.addressStreet},
          ${Apartment.addressZip} ${Apartment.addressCity},
          ${Apartment.addressCountry}
        `)
      }
    };
  };

  /*  handle update of an event, check if an Order
      is related to this event and create/update it
      Also update/create Refund Event if it's a 'Checkout' Event
  */
  // TODO: this can probably be improved as well
  Renting.prototype.handleEventUpdate = function (event, options) {
    const type = event.get('category');

    return Renting.scope(type === 'refund-deposit' ? 'client' : [`${type}Order`, 'room+apartment']).findById(this.id).then(renting => {
      if (!renting) {
        throw new Error('Client doesn\'t have a pack order yet');
      }
      const { Orders } = renting.Client === undefined || null ? null : renting.Client;

      return Promise.all([type !== 'refund-deposit' ? Utils[`getC${type.substr(1)}Price`](event.startDate, this.getComfortLevel(), this.Room.Apartment.addressCity) : 0, Orders && Orders.length ? Orders[0].id : null, Utils.getLateNoticeFees(type, event.startDate)]);
    }).then(([price, OrderId, lateFees]) => {
      if (!price && !lateFees) {
        return models.Order.destroy({
          where: {
            id: OrderId
          }
        });
      }
      const items = [];

      if (price) {
        items.push({
          label: `Special C${type.substr(1)}`,
          unitPrice: price,
          ProductId: 'special-checkinout'
        });
      } else {
        models.OrderItem.destroy({
          where: {
            OrderId,
            ProductId: 'special-checkinout'
          }
        });
      }
      if (lateFees) {
        items.push({
          label: `Late notice ${this.Room.name}`,
          unitPrice: lateFees,
          ProductId: 'late-notice'
        });
      } else {
        models.OrderItem.destroy({
          where: {
            OrderId,
            ProductId: 'late-notice'
          }
        });
      }

      return models.Order.findOrCreate({
        where: {
          ClientId: this.ClientId,
          label: `C${type.substr(1)}`
        },
        defaults: {
          type: 'debit',
          label: `C${type.substr(1)}`,
          ClientId: this.ClientId,
          OrderItems: items
        },
        include: [models.OrderItem]
      });
    }).then(() => {
      if (type === 'checkout') {
        return this.createOrUpdateRefundEvent(event.startDate, options);
      }
      return true;
    });
  };

  Renting.prototype.generateLease = function () {
    return webmerge.serializeLease(this).then(serialized => {
      return webmerge.mergeLease(serialized);
    });
  };

  Renting.prototype.createQuoteOrders = function (args) {
    const { comfortLevel, packDiscount, room } = args;

    return Promise.mapSeries([{ suffix: 'RentOrder', args: { date: this.bookingDate, room } }, { suffix: 'DepositOrder', args: { room } }, { suffix: 'PackOrder', args: { comfortLevel, packDiscount, room } }], def => {
      return this[`findOrCreate${def.suffix}`](def.args);
    }).then(([[rentOrder], [depositOrder], [packOrder]]) => {
      return models.Order.ninjaCreateInvoices([rentOrder, depositOrder, packOrder]);
    });
  };

  Renting.prototype.futureCredit = function (args) {
    const { discount, label } = args;

    return models.OrderItem.create({
      label,
      quantity: 1,
      unitPrice: discount,
      status: 'draft',
      RentingId: this.id,
      ProductId: 'discount',
      Terms: [{
        name: 'Next Rent Invoice',
        taxonomy: 'orderItem-category',
        termable: 'OrderItem'
      }]
    }, {
      include: models.Term
    });
  };

  Renting.prototype.futureDebit = function (args) {
    const { amount, reason, label, invoiceWith } = args;

    return models.Product.find({
      where: {
        name: reason
      },
      attributes: ['id']
    }).then(product => {
      return models.OrderItem.create({
        label,
        quantity: 1,
        unitPrice: amount,
        status: 'draft',
        RentingId: this.id,
        ProductId: product.id,
        Terms: [{
          name: invoiceWith,
          taxonomy: 'orderItem-category',
          termable: 'OrderItem'
        }]
      }, {
        include: models.Term
      });
    });
  };

  Renting.getPeriod = function (renting, date = new Date()) {
    const checkoutDate = renting.get('checkoutDate');
    const { bookingDate } = renting;

    if (checkoutDate && checkoutDate < date) {
      return 'past';
    } else if (bookingDate > date) {
      return 'future';
    }

    return 'current';
  };

  Renting.getLatest = function (rentings) {
    return rentings.reduce((acc, curr) => {
      return curr.bookingDate > acc.bookingDate ? curr : acc;
    }, rentings[0]);
  };

  Renting.calculatePriceAndFees = function ({ room, bookingDate, hasTwoOccupants }) {
    return models.Room.getCalculatedProps(room.basePrice, room.Apartment && room.Apartment.roomCount, bookingDate).then(({ periodPrice, serviceFees }) => {
      return {
        serviceFees,
        price: periodPrice + (hasTwoOccupants ? TWO_OCCUPANTS_FEES : 0)
      };
    });
  };
  Renting.prototype.calculatePriceAndFees = function (room) {
    return Renting.calculatePriceAndFees({
      room,
      bookingDate: this.bookingDate,
      hasTwoOccupants: this.hasTwoOccupants
    }).then(({ price, serviceFees }) => {
      this.setDataValue('price', price);
      this.setDataValue('serviceFees', serviceFees);
      return this;
    });
  };

  Renting.collection = collection;
  Renting.routes = routes;
  Renting.hooks = hooks;

  return Renting;
};

/***/ }),
/* 261 */
/***/ (function(module, exports) {

module.exports = require("webmerge");

/***/ }),
/* 262 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const Liana = __webpack_require__(5);
const capitalize = __webpack_require__(10);
const pick = __webpack_require__(263);
const D = __webpack_require__(4);
const Utils = __webpack_require__(3);
const makePublic = __webpack_require__(8);

const _ = { capitalize, pick };

module.exports = function (app, models, Renting) {
  const LEA = Liana.ensureAuthenticated;

  // Make this route completely public
  app.get('/forest/Renting/:rentingId', makePublic);

  app.post('/forest/actions/create-pack-order', LEA, (req, res) => {
    const { values, ids } = req.body.data.attributes;

    if (values.discount != null) {
      values.discount *= 100;
    }

    Promise.resolve().then(() => {
      if (!values.comfortLevel) {
        throw new Error('Please select a comfort level');
      }
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple housing-pack orders');
      }

      return Renting.scope('room+apartment').findById(ids[0]);
    }).then(renting => {
      return renting.findOrCreatePackOrder(values.comfortLevel, values.discount);
    }).then(Utils.findOrCreateSuccessHandler(res, 'Housing pack order')).catch(Utils.logAndSend(res));

    return null;
  });

  app.post('/forest/actions/generate-lease', LEA, (req, res) => {
    const { ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple leases');
      }

      return Renting.scope('comfortLevel', // required by #generateLease
      'client+identity', // required by #generateLease
      'room+apartment', // required by #generateLease
      'depositOption' // required by #generateLease
      ).findById(ids[0]);
    }).then(renting => {
      if (!renting.Client.Metadata.length) {
        throw new Error('Identity record is missing for this client');
      }
      if (!renting.get('comfortLevel')) {
        throw new Error('Housing pack is required to generate lease');
      }
      return renting.generateLease();
    }).then(Utils.createSuccessHandler(res, 'Lease')).catch(Utils.logAndSend(res));
  });
  app.post('/forest/actions/create-deposit-order', LEA, (req, res) => {
    const { ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple deposit orders');
      }

      return Renting.scope('room+apartment').findById(ids[0]);
    }).then(renting => {
      return renting.findOrCreateDepositOrder();
    }).then(Utils.findOrCreateSuccessHandler(res, 'Deposit order')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/create-first-rent-order', LEA, (req, res) => {
    const { ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple rent orders');
      }

      return Renting.scope('room+apartment', 'client+paymentDelay').findById(ids[0]);
    }).then(renting => {
      return renting.findOrCreateRentOrder({ date: renting.bookingDate });
    }).then(Utils.findOrCreateSuccessHandler(res, 'Rent order')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/create-quote-orders', LEA, (req, res) => {
    const { values: { comfortLevel, discount }, ids } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (!comfortLevel) {
        throw new Error('Please select a comfort level');
      }
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple housing-pack orders');
      }

      return Renting.scope('room+apartment', 'client+paymentDelay').findById(ids[0]);
    }).then(renting => {
      return renting.createQuoteOrders({
        comfortLevel,
        discount: discount * 100
      });
    }).then(Utils.createSuccessHandler(res, 'Quote order')).catch(Utils.logAndSend(res));
  });

  // add-checkin-date, add-checkout-date, create-checkin-order and
  // create-checkout-order routes
  ['checkin', 'checkout'].forEach(type => {
    app.post(`/forest/actions/add-${type}-date`, LEA, (req, res) => {
      const { values, ids } = req.body.data.attributes;

      Promise.resolve().then(() => {
        if (!values.dateAndTime) {
          throw new Error('Please select a planned date');
        }
        if (ids.length > 1) {
          throw new Error(`Can't create multiple ${type} events`);
        }

        return Renting.scope('room+apartment', // required to create the event
        'client' // required to create the event
        ).findById(ids[0]);
      }).then(renting => {
        return renting[`findOrCreate${_.capitalize(type)}Event`](values.dateAndTime, {});
      }).then(Utils.findOrCreateSuccessHandler(res, `${_.capitalize(type)} event`)).catch(Utils.logAndSend(res));

      return null;
    });

    app.post(`/forest/actions/create-${type}-order`, LEA, (req, res) => {
      const { ids } = req.body.data.attributes;

      Promise.resolve().then(() => {
        if (ids.length > 1) {
          throw new Error(`Can't create multiple ${type} orders`);
        }

        return Renting.scope('room+apartment', // required to create checkin/out order
        'client', // required to create the refund event,
        `${type}Date`, // required below
        'comfortLevel' // required below
        ).findById(ids[0]);
      }).then(renting => {
        if (!renting.get(`${type}Date`) || !renting.get('comfortLevel')) {
          throw new Error(Utils.toSingleLine(`
              ${_.capitalize(type)} event and housing pack are required to
              create ${_.capitalize(type)} order
            `));
        }

        return renting[`findOrCreate${_.capitalize(type)}Order`]();
      }).tap(([order, isCreated]) => {
        // We create the refund event once the checkout order is created,
        // as the checkout date is more reliable at this point
        return Promise.all([type === 'checkout' && isCreated && this.createOrUpdateRefundEvent(this.get('checkoutDate')), isCreated && models.Order.ninjaCreateInvoices([order])]);
      }).then(Utils.findOrCreateSuccessHandler(res, `${_.capitalize(type)} order`)).catch(Utils.logAndSend(res));
    });
  });

  app.post('/forest/actions/public/create-client-and-renting', makePublic, (req, res) => {
    const { roomId, pack: comfortLevel, client, currentPrice, bookingDate } = req.body;

    models.Room.scope('apartment', 'availableAt').findById(roomId).then(room => {
      if (!room) {
        throw new Error(`Room "${roomId}" not found`);
      }

      if (D.compareAsc(room.availableAt, new Date(bookingDate)) > -1) {
        throw new Error(`Room "${roomId}" unavailable on ${bookingDate}`);
      }

      return Promise.all([room.getCalculatedProps(Math.max(room.availableAt, new Date())), models.Client.findOrCreate({
        where: { email: client.email },
        defaults: _.pick(client, ['firstName', 'lastName', 'email'])
      }), room]);
    }).then(([{ periodPrice, serviceFees }, [client], room]) => {
      if (periodPrice !== currentPrice) {
        throw new Error(`Room "${roomId}"'s price has changed and is now ${periodPrice}`);
      }

      return Promise.all([Renting.findOrCreate({
        where: { ClientId: client.id, RoomId: roomId },
        defaults: {
          ClientId: client.id,
          RoomId: roomId,
          price: periodPrice,
          serviceFees,
          bookingDate
        }
      }), room]);
    }).tap(([[renting, isCreated], room]) => {
      return isCreated && renting.createQuoteOrders({ comfortLevel, room });
    }).then(([[renting]]) => {
      return res.send({ rentingId: renting.id });
    }).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/update-do-not-cash-deposit-option', LEA, (req, res) => {
    const { ids, values } = req.body.data.attributes;

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple deposit order');
      }
      if (values.option == null) {
        throw new Error('"Option" field is required');
      }

      return Renting.build({ id: ids[0] }, { isNewRecord: false }).changeDepositOption(values.option);
    }).then(() => {
      return res.send({ success: 'Deposit option successfuly updated' });
    }).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/create-room-switch-order', LEA, (req, res) => {
    const { ids, values } = req.body.data.attributes;

    if (values.discount != null) {
      values.discount *= 100;
    }

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t create multiple room switch orders');
      }

      return Renting.scope('comfortLevel' // required below
      ).findById(ids[0]);
    }).then(renting => {
      if (renting.get('comfortLevel') == null) {
        throw new Error('Housing pack is required to create room switch order');
      }

      return renting.createRoomSwitchOrder(values);
    }).then(Utils.createSuccessHandler(res, 'Room switch order')).catch(Utils.logAndSend(res));

    return null;
  });

  app.post('/forest/actions/future-credit', LEA, (req, res) => {
    const { ids, values } = req.body.data.attributes;

    if (values.discount != null) {
      values.discount *= -100;
    }

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t credit multiple rentings');
      }

      return Renting.findById(ids[0]);
    }).then(renting => {
      return renting.futureCredit(values);
    }).then(Utils.createSuccessHandler(res, 'Future credit')).catch(Utils.logAndSend(res));
  });

  app.post('/forest/actions/future-debit', LEA, (req, res) => {
    const { ids, values } = req.body.data.attributes;

    if (values.amount != null) {
      values.amount *= 100;
    }

    Promise.resolve().then(() => {
      if (ids.length > 1) {
        throw new Error('Can\'t debit multiple rentings');
      }

      return Renting.findById(ids[0]);
    }).then(renting => {
      return renting.futureDebit(values);
    }).then(Utils.createSuccessHandler(res, 'Future debit')).catch(Utils.logAndSend(res));
  });

  Utils.addRestoreAndDestroyRoutes(app, Renting);
};

/***/ }),
/* 263 */
/***/ (function(module, exports, __webpack_require__) {

var basePick = __webpack_require__(264),
    flatRest = __webpack_require__(265);

/**
 * Creates an object composed of the picked `object` properties.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The source object.
 * @param {...(string|string[])} [paths] The property paths to pick.
 * @returns {Object} Returns the new object.
 * @example
 *
 * var object = { 'a': 1, 'b': '2', 'c': 3 };
 *
 * _.pick(object, ['a', 'c']);
 * // => { 'a': 1, 'c': 3 }
 */
var pick = flatRest(function(object, paths) {
  return object == null ? {} : basePick(object, paths);
});

module.exports = pick;


/***/ }),
/* 264 */
/***/ (function(module, exports, __webpack_require__) {

var basePickBy = __webpack_require__(77),
    hasIn = __webpack_require__(72);

/**
 * The base implementation of `_.pick` without support for individual
 * property identifiers.
 *
 * @private
 * @param {Object} object The source object.
 * @param {string[]} paths The property paths to pick.
 * @returns {Object} Returns the new object.
 */
function basePick(object, paths) {
  return basePickBy(object, paths, function(value, path) {
    return hasIn(object, path);
  });
}

module.exports = basePick;


/***/ }),
/* 265 */
/***/ (function(module, exports, __webpack_require__) {

var flatten = __webpack_require__(266),
    overRest = __webpack_require__(269),
    setToString = __webpack_require__(271);

/**
 * A specialized version of `baseRest` which flattens the rest array.
 *
 * @private
 * @param {Function} func The function to apply a rest parameter to.
 * @returns {Function} Returns the new function.
 */
function flatRest(func) {
  return setToString(overRest(func, undefined, flatten), func + '');
}

module.exports = flatRest;


/***/ }),
/* 266 */
/***/ (function(module, exports, __webpack_require__) {

var baseFlatten = __webpack_require__(267);

/**
 * Flattens `array` a single level deep.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Array
 * @param {Array} array The array to flatten.
 * @returns {Array} Returns the new flattened array.
 * @example
 *
 * _.flatten([1, [2, [3, [4]], 5]]);
 * // => [1, 2, [3, [4]], 5]
 */
function flatten(array) {
  var length = array == null ? 0 : array.length;
  return length ? baseFlatten(array, 1) : [];
}

module.exports = flatten;


/***/ }),
/* 267 */
/***/ (function(module, exports, __webpack_require__) {

var arrayPush = __webpack_require__(37),
    isFlattenable = __webpack_require__(268);

/**
 * The base implementation of `_.flatten` with support for restricting flattening.
 *
 * @private
 * @param {Array} array The array to flatten.
 * @param {number} depth The maximum recursion depth.
 * @param {boolean} [predicate=isFlattenable] The function invoked per iteration.
 * @param {boolean} [isStrict] Restrict to values that pass `predicate` checks.
 * @param {Array} [result=[]] The initial result value.
 * @returns {Array} Returns the new flattened array.
 */
function baseFlatten(array, depth, predicate, isStrict, result) {
  var index = -1,
      length = array.length;

  predicate || (predicate = isFlattenable);
  result || (result = []);

  while (++index < length) {
    var value = array[index];
    if (depth > 0 && predicate(value)) {
      if (depth > 1) {
        // Recursively flatten arrays (susceptible to call stack limits).
        baseFlatten(value, depth - 1, predicate, isStrict, result);
      } else {
        arrayPush(result, value);
      }
    } else if (!isStrict) {
      result[result.length] = value;
    }
  }
  return result;
}

module.exports = baseFlatten;


/***/ }),
/* 268 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(14),
    isArguments = __webpack_require__(29),
    isArray = __webpack_require__(6);

/** Built-in value references. */
var spreadableSymbol = Symbol ? Symbol.isConcatSpreadable : undefined;

/**
 * Checks if `value` is a flattenable `arguments` object or array.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is flattenable, else `false`.
 */
function isFlattenable(value) {
  return isArray(value) || isArguments(value) ||
    !!(spreadableSymbol && value && value[spreadableSymbol]);
}

module.exports = isFlattenable;


/***/ }),
/* 269 */
/***/ (function(module, exports, __webpack_require__) {

var apply = __webpack_require__(270);

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max;

/**
 * A specialized version of `baseRest` which transforms the rest array.
 *
 * @private
 * @param {Function} func The function to apply a rest parameter to.
 * @param {number} [start=func.length-1] The start position of the rest parameter.
 * @param {Function} transform The rest array transform.
 * @returns {Function} Returns the new function.
 */
function overRest(func, start, transform) {
  start = nativeMax(start === undefined ? (func.length - 1) : start, 0);
  return function() {
    var args = arguments,
        index = -1,
        length = nativeMax(args.length - start, 0),
        array = Array(length);

    while (++index < length) {
      array[index] = args[start + index];
    }
    index = -1;
    var otherArgs = Array(start + 1);
    while (++index < start) {
      otherArgs[index] = args[index];
    }
    otherArgs[start] = transform(array);
    return apply(func, this, otherArgs);
  };
}

module.exports = overRest;


/***/ }),
/* 270 */
/***/ (function(module, exports) {

/**
 * A faster alternative to `Function#apply`, this function invokes `func`
 * with the `this` binding of `thisArg` and the arguments of `args`.
 *
 * @private
 * @param {Function} func The function to invoke.
 * @param {*} thisArg The `this` binding of `func`.
 * @param {Array} args The arguments to invoke `func` with.
 * @returns {*} Returns the result of `func`.
 */
function apply(func, thisArg, args) {
  switch (args.length) {
    case 0: return func.call(thisArg);
    case 1: return func.call(thisArg, args[0]);
    case 2: return func.call(thisArg, args[0], args[1]);
    case 3: return func.call(thisArg, args[0], args[1], args[2]);
  }
  return func.apply(thisArg, args);
}

module.exports = apply;


/***/ }),
/* 271 */
/***/ (function(module, exports, __webpack_require__) {

var baseSetToString = __webpack_require__(272),
    shortOut = __webpack_require__(274);

/**
 * Sets the `toString` method of `func` to return `string`.
 *
 * @private
 * @param {Function} func The function to modify.
 * @param {Function} string The `toString` result.
 * @returns {Function} Returns `func`.
 */
var setToString = shortOut(baseSetToString);

module.exports = setToString;


/***/ }),
/* 272 */
/***/ (function(module, exports, __webpack_require__) {

var constant = __webpack_require__(273),
    defineProperty = __webpack_require__(61),
    identity = __webpack_require__(73);

/**
 * The base implementation of `setToString` without support for hot loop shorting.
 *
 * @private
 * @param {Function} func The function to modify.
 * @param {Function} string The `toString` result.
 * @returns {Function} Returns `func`.
 */
var baseSetToString = !defineProperty ? identity : function(func, string) {
  return defineProperty(func, 'toString', {
    'configurable': true,
    'enumerable': false,
    'value': constant(string),
    'writable': true
  });
};

module.exports = baseSetToString;


/***/ }),
/* 273 */
/***/ (function(module, exports) {

/**
 * Creates a function that returns `value`.
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Util
 * @param {*} value The value to return from the new function.
 * @returns {Function} Returns the new constant function.
 * @example
 *
 * var objects = _.times(2, _.constant({ 'a': 1 }));
 *
 * console.log(objects);
 * // => [{ 'a': 1 }, { 'a': 1 }]
 *
 * console.log(objects[0] === objects[1]);
 * // => true
 */
function constant(value) {
  return function() {
    return value;
  };
}

module.exports = constant;


/***/ }),
/* 274 */
/***/ (function(module, exports) {

/** Used to detect hot functions by number of calls within a span of milliseconds. */
var HOT_COUNT = 800,
    HOT_SPAN = 16;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeNow = Date.now;

/**
 * Creates a function that'll short out and invoke `identity` instead
 * of `func` when it's called `HOT_COUNT` or more times in `HOT_SPAN`
 * milliseconds.
 *
 * @private
 * @param {Function} func The function to restrict.
 * @returns {Function} Returns the new shortable function.
 */
function shortOut(func) {
  var count = 0,
      lastCalled = 0;

  return function() {
    var stamp = nativeNow(),
        remaining = HOT_SPAN - (stamp - lastCalled);

    lastCalled = stamp;
    if (remaining > 0) {
      if (++count >= HOT_COUNT) {
        return arguments[0];
      }
    } else {
      count = 0;
    }
    return func.apply(undefined, arguments);
  };
}

module.exports = shortOut;


/***/ }),
/* 275 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Utils = __webpack_require__(3);
//const Sendinblue                 = require('../../vendor/sendinblue');

module.exports = function (models, Renting) {
  Renting.hook('beforeValidate', renting => {
    // Only calculate the price and fees on creation
    if (!('RoomId' in renting.dataValues) || !('bookingDate' in renting.dataValues) || renting.price != null && renting.price > 0 && !isNaN(renting.price)) {
      return renting;
    }

    return models.Room.scope('apartment').findById(renting.RoomId).then(room => {
      return renting.calculatePriceAndFees(room);
    });
  });

  // We want rentings to be draft by default, but users shouldn't have
  // to set the deletedAt value themselves
  //  Renting.hook('beforeCreate', (renting) => {
  //    if ( renting.status !== 'active' ) {
  //      renting.setDataValue('deletedAt', new Date());
  //    }
  //
  //    return renting;
  //  });

  // Create quote orders if the housing pack has been set when creating the renting
  Renting.hook('afterCreate', (_renting, { transaction }) => {
    if (_renting.comfortLevel) {
      const promise = Renting.scope('room+apartment', 'client+paymentDelay').findById(_renting.id, { transaction }).then(renting => {
        return renting.createQuoteOrders(_renting);
      });

      return Utils.wrapHookPromise(promise);
    }

    return null;
  });

  //  Renting.hook('beforeUpdate', (_renting) => {
  //    if ( _renting.dataValues.status === 'active' &&
  //        _renting._previousDataValues.status !== _renting.dataValues.status) {
  //      return Renting.scope(['room+apartment', 'client'])
  //        .findById(_renting.id)
  //        .then((renting) => {
  //          return Sendinblue.sendWelcomeEmail(renting);
  //        });
  //    }
  //
  //    return true;
  //  });
};

/***/ }),
/* 276 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const {
  BASIC_PACK,
  COMFORT_PACK,
  PRIVILEGE_PACK,
  TRASH_SEGMENTS
} = __webpack_require__(0);
const Utils = __webpack_require__(3);
const Products = __webpack_require__(277);

module.exports = function (models) {
  return {
    fields: [{
      field: 'booking date coef',
      type: 'Number',
      get(object) {
        return Utils.getPeriodCoef(object.bookingDate);
      }
    }, {
      field: 'period',
      type: 'Enum',
      enums: ['current', 'past', 'future'],
      get(object) {
        return models.Renting.scope('checkoutDate').findById(object.id).then(models.Renting.getPeriod);
      }
    }, {
      field: 'Housing Pack',
      type: 'Enum',
      enums: [BASIC_PACK, COMFORT_PACK, PRIVILEGE_PACK],
      set(object, value) {
        object.comfortLevel = value;
        return object;
      }
    }, {
      field: 'Pack Discount',
      type: 'Number',
      set(object, value) {
        object.packDiscount = value;
        return object;
      }
    }, {
      field: '2 occupants ?',
      type: 'Boolean',
      set(object, value) {
        object.hasTwoOccupants = value;
        return object;
      }
    }],
    actions: [{
      name: 'Create First Rent Order'
    }, {
      name: 'Create Pack Order',
      fields: [{
        field: 'comfortLevel',
        type: 'Enum',
        enums: [BASIC_PACK, COMFORT_PACK, PRIVILEGE_PACK]
      }, {
        field: 'discount',
        type: 'Number'
      }]
    }, {
      name: 'Create Deposit Order'
    }, {
      name: 'Create Quote Orders',
      fields: [{
        field: 'comfortLevel',
        type: 'Enum',
        enums: [BASIC_PACK, COMFORT_PACK, PRIVILEGE_PACK]
      }, {
        field: 'packDiscount',
        type: 'Number'
      }]
    }, {
      name: 'Update "do not cash deposit" Option',
      fields: [{
        field: 'option',
        description: 'required',
        type: 'Enum',
        enums: ['cash deposit', 'do not cash deposit']
      }]
    }, {
      name: 'Add Checkin Date',
      fields: [{
        field: 'dateAndTime',
        type: 'Date'
      }]
    }, {
      name: 'Add Checkout Date',
      fields: [{
        field: 'dateAndTime',
        type: 'Date'
      }]
    }, {
      name: 'Generate Lease'
    }, {
      name: 'Create Checkin Order'
    }, {
      name: 'Create Checkout Order'
    }, {
      name: 'Create Room Switch Order',
      fields: [{
        field: 'discount',
        type: 'Number'
      }]
    }, {
      name: 'Future Credit',
      fields: [{
        field: 'discount',
        type: 'Number'
      }, {
        field: 'label',
        type: 'String'
      }]
    }, {
      name: 'Future Debit',
      fields: [{
        field: 'amount',
        isRequired: true,
        type: 'Number'
      }, {
        field: 'reason',
        type: 'Enum',
        isRequired: true,
        enums: Products.Product.map(product => {
          return product.name;
        })
      }, {
        field: 'invoiceWith',
        isRequired: true,
        type: 'Enum',
        enums: ['Next Rent Invoice', 'Account Balance Invoice']
      }, {
        field: 'label',
        type: 'String'
      }]
    }, {
      name: 'Restore Renting'
    }, {
      name: 'Destroy Renting'
    }],
    segments: TRASH_SEGMENTS
  };
};

/***/ }),
/* 277 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// /!\ Values in this file will be <findOrCreate>d on each deploy
// All records in this file need an `id`
module.exports = {
  Setting: [{
    id: 'invoice-counter',
    type: 'int',
    value: 3773
  }],
  Product: [{
    id: 'service-fees',
    name: 'Service Fees'
  }, {
    id: 'rent',
    name: 'Rent'
  }, {
    id: 'basic-pack',
    name: 'Basic Pack'
  }, {
    id: 'comfort-pack',
    name: 'Comfort Pack'
  }, {
    id: 'privilege-pack',
    name: 'Privilege Pack'
  }, {
    id: 'special-checkin',
    name: 'Special Checkin'
  }, {
    id: 'special-checkout',
    name: 'Special Checkout'
  }, {
    id: 'late-notice',
    name: 'Late Notice'
  }, {
    id: 'room-switch',
    name: 'Room Switch'
  }, {
    id: 'late-fees',
    name: 'Late fees'
  }, {
    id: 'lyon-deposit',
    name: 'Lyon deposit'
  }, {
    id: 'montpellier-deposit',
    name: 'Montpellier deposit'
  }, {
    id: 'paris-deposit',
    name: 'Paris deposit'
  }, {
    id: 'uncashed-deposit',
    name: 'Uncashed Deposit'
  }, {
    id: 'service-overcharging-fees',
    name: 'Service Overcharging Fees'
  }, {
    id: 'discount',
    name: 'Discount'
  }, {
    id: 'other',
    name: 'Other'
  }],
  Client: [{
    id: 'maintenance',
    firstName: 'Chez',
    lastName: 'Nestor',
    email: 'support@chez-nestor.com',
    status: 'draft',
    phoneNumber: '0000000'
  }]
};

/***/ }),
/* 278 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const Utils = __webpack_require__(3);
const {
  TRASH_SCOPES,
  UNAVAILABLE_DATE
} = __webpack_require__(0);
const collection = __webpack_require__(279);
const routes = __webpack_require__(280);
const hooks = __webpack_require__(281);

module.exports = (sequelize, DataTypes) => {
  const { models } = sequelize;
  const Room = sequelize.define('Room', {
    id: {
      primaryKey: true,
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4
    },
    reference: {
      type: DataTypes.STRING,
      unique: true
    },
    name: DataTypes.STRING,
    floorArea: DataTypes.FLOAT,
    basePrice: DataTypes.FLOAT,
    beds: DataTypes.ENUM('double', 'simple', 'sofa', 'double+sofa', 'simple+sofa', 'simple+simple'),
    status: {
      type: DataTypes.ENUM('draft', 'active'),
      defaultValue: 'active'
      // required: true,
      // allowNull: false,
    },
    availableAt: {
      type: DataTypes.VIRTUAL(DataTypes.DATE),
      get() {
        return this.Rentings && (this.Rentings.length === 0 ? new Date(0) : models.Renting.getLatest(this.Rentings).get('checkoutDate') || UNAVAILABLE_DATE);
      }
    }
  }, {
    paranoid: true,
    scopes: TRASH_SCOPES
  });

  Room.associate = () => {
    const availableAt = {
      model: models.Renting.scope('checkoutDate'),
      required: false,
      attributes: { include: [[sequelize.literal('`Rentings->Events`.`startDate`'), 'checkoutDate']] },
      where: { status: 'active' }
    };
    const apartment = {
      model: models.Apartment
    };

    Room.belongsTo(models.Apartment);
    Room.hasMany(models.Renting);
    Room.hasMany(models.Picture, {
      foreignKey: 'PicturableId',
      constraints: false,
      scope: { picturable: 'Room' }
    });
    Room.hasMany(models.Term, {
      foreignKey: 'TermableId',
      constraints: false,
      scope: { termable: 'Room' }
    });
    Room.addScope('apartment', {
      include: [apartment]
    });

    Room.addScope('availableAt', {
      include: [availableAt]
    });

    Room.addScope('apartment+availableAt', {
      include: [apartment, availableAt]
    });
  };

  Room.getCalculatedProps = function (basePrice, roomCount, now = new Date()) {
    return Promise.all([Utils.getPeriodCoef(now), Utils.getServiceFees(roomCount)]).then(([periodCoef, serviceFees]) => {
      return {
        periodPrice: Utils.getPeriodPrice(basePrice, periodCoef, serviceFees),
        serviceFees
      };
    });
  };
  // calculate periodPrice and serviceFees for the room
  Room.prototype.getCalculatedProps = function (now = new Date()) {
    return Room.getCalculatedProps(this.basePrice, this.Apartment && this.Apartment.roomCount, now);
  };

  Room.prototype.checkAvailability = function (date = new Date()) {
    return Room.checkAvailability(this, date);
  };
  Room.checkAvailability = function (room, date = new Date()) {
    if (room.Rentings.length === 0) {
      return Promise.resolve(true);
    }

    const checkoutDate = models.Renting.getLatest(room.Rentings).get('checkoutDate');

    return Promise.resolve(checkoutDate && checkoutDate <= date ? true : false);
  };

  Room.prototype.createMaintenancePeriod = function (args) {
    const { from, to } = args;

    return models.Renting.create({
      bookingDate: from,
      status: 'active',
      ClientId: 'maintenance',
      RoomId: this.id,
      Events: [].concat(to && {
        startDate: to,
        endDate: to,
        eventable: 'Renting',
        summary: 'End of maintenance',
        description: `${this.name}`,
        Terms: [{
          name: 'Checkout',
          taxonomy: 'event-category',
          termable: 'Event'
        }]
      }).filter(Boolean)
    }, {
      include: [models.Event, models.Term]
    });
  };

  Room.collection = collection;
  Room.routes = routes;
  Room.hooks = hooks;

  return Room;
};

/***/ }),
/* 279 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const capitalize = __webpack_require__(10);
const { WEBSITE_URL } = __webpack_require__(2);
const { TRASH_SEGMENTS } = __webpack_require__(0);
const Utils = __webpack_require__(3);

const _ = { capitalize };

module.exports = function ({ Room, Picture }) {
  const memoizer = new Utils.calculatedPropsMemoizer(Room.scope('availableAt', 'apartment'));

  return {
    fields: [{
      field: 'current price',
      type: 'Number',
      get(object) {
        return memoizer.getCalculatedProps(object).then(result => {
          return result.periodPrice;
        }).tapCatch(console.error);
      }
    }, {
      field: 'service fees',
      type: 'Number',
      get(object) {
        return memoizer.getCalculatedProps(object).then(result => {
          return result.serviceFees;
        }).tapCatch(console.error);
      }
    }, {
      field: 'current-client',
      type: ['String'],
      reference: 'Client.id'
    }, {
      field: 'cover picture',
      type: 'String',
      get(object) {
        return Picture.findOne({
          where: {
            PicturableId: object.id
          }
        }).then(picture => {
          return picture ? picture.url : null;
        });
      }
    }, {
      field: 'preview',
      description: 'frontend preview url',
      type: 'String',
      get(object) {
        return `${WEBSITE_URL}/en-US/room/${object.id}`;
      }
    }],
    actions: [{
      name: 'Restore Room'
    }, {
      name: 'Destroy Room'
    }, {
      name: 'Maintenance Period',
      fields: [{
        field: 'from',
        type: 'Date',
        isRequired: true
      }, {
        field: 'to',
        type: 'Date'
      }]
    }],
    segments: TRASH_SEGMENTS.concat({
      name: 'Availability',
      scope: 'availableAt'
    }, ['lyon', 'montpellier', 'paris'].map(city => {
      return {
        name: `Available Rooms ${_.capitalize(city)}`,
        scope: 'apartment+availableAt',
        where: () => {
          // TODO: this query is awfull. We join on all rentings that ever
          // existed when we know only the one with the latest bookingDate
          // are valuable. For now, the performances are acceptable though.
          // Here are the alternatives we considered and rejected:
          //   - Using a Renting scope, as this would exclude any Room that has
          //     never had an active renting.
          //   - Same, + searching for Rooms that never had an active Renting,
          //     as this is probably even less efficient
          //   - Using include.separate = true, as we've never been able to get
          //     it to work :-/
          // Here are the alternatives we have yet to investigate:
          //   - Add a hook to Room to create a fake Renting with a
          //     bookingDate and checkoutDate at epoch, so we can sort our
          //     problem with a Renting scope
          //   - Switch to TypeORM and see if that makes things simpler for us
          //     using subrequest probably
          return Room.scope('availableAt', 'apartment').findAll({
            where: { '$Apartment.addressCity$': `${city}` }
          }).filter(room => {
            return room.checkAvailability();
          }).reduce((acc, curr) => {
            acc.id.push(curr.id);
            return acc;
          }, { id: [] });
        }
      };
    }))
  };
};

/***/ }),
/* 280 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const makePublic = __webpack_require__(8);
const Utils = __webpack_require__(3);

module.exports = function (app, models, Room) {
  // Make the room listing and details endpoint public, for chez-nestor.com
  app.get('/forest/Room', makePublic);
  app.get('/forest/Room/:recordId', makePublic);

  Utils.addInternalRelationshipRoute({
    app,
    sourceModel: Room,
    associatedModel: models.Client,
    routeName: 'current-client',
    scope: 'currentApartment',
    where: req => {
      return {
        '$Rentings.RoomId$': req.params.recordId,
        '$Rentings.bookingDate$': { $lte: new Date() }
      };
    }
  });

  Utils.addRestoreAndDestroyRoutes(app, Room);
};

/***/ }),
/* 281 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (models, Room) {
  Room.hook('beforeDelete', room => {
    return models.Client.scope('currentApartment').findAll({
      where: {
        '$Rentings.RoomId$': room.id,
        '$Rentings.bookingDate$': { $lte: new Date() }
      }
    }).then(clients => {
      if (clients.length > 0) {
        throw new Error('Cannot delete Room: it\'s not empty.');
      }
      return true;
    });
  });
};

/***/ }),
/* 282 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const collection = __webpack_require__(283);

module.exports = (sequelize, DataTypes) => {
  const Setting = sequelize.define('Setting', {
    id: {
      primaryKey: true,
      type: DataTypes.STRING,
      required: true
    },
    type: {
      type: DataTypes.ENUM('str', 'int'),
      required: true,
      defaultValue: 'str',
      allowNull: false
    },
    value: {
      type: DataTypes.VIRTUAL,
      get() {
        switch (this.type) {
          case 'int':
            return this.intVal;
          case 'str':
          default:
            return this.strVal;
        }
      },
      set(val) {
        switch (this.type) {
          case 'int':
            return this.intVal = val;
          case 'str':
          default:
            return this.strVal = val;
        }
      }
    },
    strVal: DataTypes.STRING,
    intVal: DataTypes.INTEGER
  });

  Setting.prototype._increment = Setting.prototype.increment;

  Setting.prototype.increment = function (options) {
    if (!this.type === 'int') {
      return Promise.reject(new Error(`Increment only works on 'int' settings, found: ${this.type}`));
    }

    return this._increment('intVal', options);
  };

  Setting.collection = collection;

  return Setting;
};

/***/ }),
/* 283 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function () {
  return {
    fields: [{
      field: '_value',
      type: 'String',
      get(setting) {
        return setting.value;
      },
      set(setting, value) {
        setting.intVal = value;
        setting.strVal = value;
        return setting;
      }
    }]
  };
};

/***/ }),
/* 284 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const routes = __webpack_require__(285);

module.exports = (sequelize, DataTypes) => {
  const Term = sequelize.define('Term', {
    name: {
      primaryKey: true,
      type: DataTypes.STRING
    },
    taxonomy: {
      primaryKey: true,
      type: DataTypes.STRING
    },
    TermableId: {
      primaryKey: true,
      type: DataTypes.STRING
    },
    termable: {
      type: DataTypes.STRING,
      required: true,
      allowNull: false
    }
  });
  const { models } = sequelize;
  // const taxonomies = {};

  Term.associate = () => {
    Term.belongsTo(models.Room, {
      foreignKey: 'TermableId',
      constraints: false,
      as: 'Room'
    });
    Term.belongsTo(models.Apartment, {
      foreignKey: 'TermableId',
      constraints: false,
      as: 'Apartment'
    });
    Term.belongsTo(models.OrderItem, {
      foreignKey: 'TermableId',
      constraints: false,
      as: 'OrderItem'
    });
    Term.belongsTo(models.Order, {
      foreignKey: 'TermableId',
      constraints: false,
      as: 'Order'
    });
    Term.belongsTo(models.Event, {
      foreignKey: 'TermableId',
      constraints: false,
      as: 'Event'
    });
    Term.belongsTo(models.Renting, {
      foreignKey: 'TermableId',
      constraints: false,
      as: 'Renting'
    });
  };

  // Term.addTaxonomy = function(options) {
  //   const {name} = options;
  //
  //   Term.addScope(name, {
  //     where: { name },
  //   });
  //
  //   taxonomies[name] = options;
  // };
  //
  // Term.hook('beforeCreate', (term) => {
  //
  // });

  Term.prototype.createOrUpdate = function (name) {
    return sequelize.transaction(transaction => {
      return Promise.resolve().then(() => {
        return Term.destroy({
          where: {
            taxonomy: this.taxonomy,
            termable: this.termable,
            TermableId: this.TermableId
          },
          transaction
        });
      }).then(() => {
        return Term.create({
          name,
          taxonomy: this.taxonomy,
          TermableId: this.TermableId,
          termable: this.termable
        }, { transaction });
      });
    });
  };

  Term.routes = routes;

  return Term;
};

/***/ }),
/* 285 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Promise = __webpack_require__(1);
const Liana = __webpack_require__(5);
const makePublic = __webpack_require__(8);
const Utils = __webpack_require__(3);

module.exports = (app, models, Term) => {
  const LEA = Liana.ensureAuthenticated;

  app.get('/forest/Term', makePublic);

  app.post('/forest/actions/public/updateTerms', LEA, (req, res) => {
    const { roomId, apartmentId, ApartmentFeatures, RoomFeatures } = req.body;

    Promise.resolve().then(() => {
      return Term.destroy({
        where: {
          $or: [{
            TermableId: roomId,
            taxonomy: { $like: 'room-features-%' }
          }, {
            TermableId: apartmentId,
            taxonomy: { $like: 'apartment-features-%' }
          }]
        }
      });
    }).then(() => {
      return Promise.all([RoomFeatures.map(({ name, taxonomy, termable }) => {
        return Term.create({
          name,
          taxonomy,
          termable,
          TermableId: roomId
        });
      }), ApartmentFeatures.map(({ name, taxonomy, termable }) => {
        return Term.create({
          name,
          taxonomy,
          termable,
          TermableId: apartmentId
        });
      })]);
    }).then(Utils.createSuccessHandler(res, 'Terms')).catch(e => {
      return res.status(400).send(e);
    });
  });
};

/***/ }),
/* 286 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const Promise = __webpack_require__(1);
const D = __webpack_require__(4);
const fetch = __webpack_require__(54);
const aws = __webpack_require__(20);
const geocode = __webpack_require__(53);
const payline = __webpack_require__(27);
const sendinblue = __webpack_require__(42);
const webmerge = __webpack_require__(81);
const chromeless = __webpack_require__(79);
const config = __webpack_require__(2);
const models = __webpack_require__(52);
const makePublic = __webpack_require__(8);

module.exports = function (app) {
  // Global route used to verify that the backend is up, running and connected to
  // the DB as well as all external services
  app.get('/ping', makePublic, (() => {
    var _ref = _asyncToGenerator(function* (req, res) {
      try {
        yield Promise.all([models.Client.findOne(), aws.pingService(), geocode.pingService(), payline.pingService(), sendinblue.pingService(), webmerge.pingService(), chromeless.pingService()]);
      } catch (e) {
        return res.status(500).send(e);
      }

      return res.send('pong');
    });

    return function (_x, _x2) {
      return _ref.apply(this, arguments);
    };
  })());

  app.post('/forest/login', makePublic, (req, res) => {
    return Promise.resolve().then(() => {
      return fetch(`${config.REST_API_URL}/forest/sessions`, {
        method: 'post',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({}, req.body, { renderingId: config.FOREST_RENDERING_ID }))
      });
    }).then(response => {
      if (!response.ok) {
        /* eslint-disable promise/no-nesting */
        return response.text().then(message => {
          throw new Error(message);
        });
        /* eslint-enable promise/no-nesting */
      }
      return response.json();
    }).then(result => {
      return res.cookie('authorized', `Bearer ${result.token}`, { expires: D.addDays(Date.now(), 30) }).send(result);
    }).catch(e => {
      return res.status(400).send(e);
    });
  });
};

/***/ }),
/* 287 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const Invoice = __webpack_require__(288);
const RentalAttachment = __webpack_require__(289);

module.exports = {
  Invoice,
  RentalAttachment
};

/***/ }),
/* 288 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function () {
  return {
    name: 'Invoice',
    idField: 'id',
    fields: [{
      field: 'id',
      type: 'String'
    }, {
      field: 'href',
      type: 'String'
    }]
  };
};

/***/ }),
/* 289 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function () {
  return {
    name: 'rentalAttachment',
    idField: 'id',
    fields: [{
      field: 'id',
      type: 'String'
    }, {
      field: 'href',
      type: 'String'
    }]
  };
};

/***/ })
/******/ ]);
//# sourceMappingURL=server.js.map